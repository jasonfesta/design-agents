// Auto-generated from src/styles/theme.css — do not edit
export const themeCSS = `@import url('https://fonts.googleapis.com/css2?family=Geist+Mono:wght@100..900&display=swap');

/* Dialkit Theme - Dark glassmorphic design */
.dialkit-root {
  position: relative;

  /* Surfaces */
  --dial-surface: rgba(255, 255, 255, 0.05);
  --dial-surface-hover: rgba(255, 255, 255, 0.1);
  --dial-surface-active: rgba(255, 255, 255, 0.11);
  --dial-surface-subtle: rgba(255, 255, 255, 0.06);

  /* Text hierarchy - 3 levels */
  --dial-text-root: #FFFFFF;   /* Root title */
  --dial-text-section: rgba(255, 255, 255, 0.7); /* Section titles + carets */
  --dial-text-label: rgba(255, 255, 255, 0.7);   /* Input labels */
  --dial-text-focus: #ffffff;

  /* Legacy aliases */
  --dial-text-primary: rgba(255, 255, 255, 0.95);
  --dial-text-secondary: rgba(255, 255, 255, 0.6);
  --dial-text-tertiary: rgba(255, 255, 255, 0.4);

  /* Borders */
  --dial-border: rgba(255, 255, 255, 0.1);
  --dial-border-hover: rgba(255, 255, 255, 0.15);
  --dial-focus-ring: rgba(255, 255, 255, 0.6);

  /* Timeline clips are light by default; light themes add a dark tint so
     their shape stays distinct from the lane without replacing custom hues. */
  --dial-timeline-clip-overlay: transparent;

  /* Glassmorphic panel */
  --dial-glass-bg: #212121;
  --dial-dropdown-bg: #2a2a2a;
  --dial-backdrop-blur: 20px;
  --dial-radius: 8px;
  --dial-row-height: 36px;
  --dial-row-gap: 6px;
  --dial-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
  --dial-shadow-collapsed: 0 4px 16px rgba(0, 0, 0, 0.25);
  --dial-shadow-dropdown: 0 8px 24px rgba(0, 0, 0, 0.4);

  /* Fonts */
  font-family: system-ui, -apple-system, 'SF Pro Display', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.dialkit-panel {
  position: fixed;
  z-index: 9999;
  max-height: calc(100vh - 32px);
  overflow: visible;
}

/* Inline mode */
.dialkit-root[data-mode="inline"] {
  max-height: 100%;
}

.dialkit-panel[data-mode="inline"] {
  position: static;
  z-index: auto;
  max-height: inherit;
  height: auto;
  overflow: visible;
}

.dialkit-panel-inner {
  box-sizing: border-box;
  background: var(--dial-glass-bg);
  border: 1px solid var(--dial-border);
  border-radius: 14px;
  backdrop-filter: blur(var(--dial-backdrop-blur));
  -webkit-backdrop-filter: blur(var(--dial-backdrop-blur));
  padding: 10px 12px;
  transform: translateZ(0);
  transform-origin: var(--dial-origin-y, top) var(--dial-origin-x, right);
}

.dialkit-panel[data-origin-x="left"] {
  --dial-origin-x: left;
}

.dialkit-panel[data-origin-x="right"] {
  --dial-origin-x: right;
}

.dialkit-panel[data-origin-y="top"] {
  --dial-origin-y: top;
}

.dialkit-panel[data-origin-y="bottom"] {
  --dial-origin-y: bottom;
}

.dialkit-panel[data-position="top-left"] .dialkit-panel-inner {
  max-height: calc(100vh - 80px);
  overflow-y: auto;
}


.dialkit-panel-inner[data-collapsed="true"] {
  transform-origin: center;
  border-radius: 50%;
  padding: 12px;
  box-sizing: border-box;
}

.dialkit-panel-inner[data-collapsed="true"] .dialkit-panel-header {
  padding-bottom: 0;
  margin-bottom: 0;
  border-bottom: none;
}

.dialkit-panel-inner[data-collapsed="true"] .dialkit-folder-title-row {
  display: none;
}

.dialkit-panel-inner[data-collapsed="true"] .dialkit-folder-header-top {
  justify-content: center;
  padding: 0;
}

.dialkit-panel-inner::-webkit-scrollbar {
  display: none;
}

.dialkit-panel-inner {
  -ms-overflow-style: none;
  scrollbar-width: none;
  overflow-anchor: none;
}

.dialkit-panel-inner[data-folding="true"]:not(.dialkit-panel-inline) {
  height: var(--dial-panel-fold-height) !important;
}

/* Put the top inset inside the sticky header so it never scrolls away. */
.dialkit-panel-inner:not([data-collapsed="true"]) {
  padding-top: 0;
}

.dialkit-panel-inner:not([data-collapsed="true"]) > .dialkit-folder-root > .dialkit-panel-header {
  position: sticky;
  top: 0;
  z-index: 3;
  padding-top: 10px;
  background: var(--dial-glass-bg);
}

/* Cover the side gutters too, including when a section pushes its header up. */
.dialkit-panel-inner:not([data-collapsed="true"]) > .dialkit-folder-root > .dialkit-panel-header::before,
.dialkit-folder-section > .dialkit-folder-header::before {
  content: '';
  position: absolute;
  inset: 0 -12px;
  z-index: -1;
  background: var(--dial-glass-bg);
  pointer-events: none;
}

.dialkit-panel-inner:not([data-collapsed="true"]) > .dialkit-folder-root > .dialkit-panel-header .dialkit-panel-icon {
  right: 0;
}

.dialkit-panel-inline {
  width: 100%;
  height: auto;
  max-height: inherit;
  /* Use the host's scroll container so sticky headers also work when embedded. */
  overflow: visible;
  box-shadow: none;
  border-radius: 0;
  border: none;
  box-sizing: border-box;
}

.dialkit-panel[data-mode="inline"] .dialkit-panel-wrapper {
  display: flex;
  flex-direction: column;
  width: 100%;
  max-height: inherit;
  height: auto;
}

/* Position variants */
.dialkit-panel[data-position="top-right"] {
  top: 16px;
  right: 16px;
}

.dialkit-panel[data-position="top-left"] {
  top: 16px;
  left: 16px;
}

.dialkit-panel[data-position="bottom-right"] {
  bottom: 16px;
  right: 16px;
}

.dialkit-panel[data-position="bottom-left"] {
  bottom: 16px;
  left: 16px;
}

/* Folder */
.dialkit-folder {
  padding-bottom: 8px;
  margin-bottom: 8px;
  border-bottom: 1px solid var(--dial-surface-subtle);
}

.dialkit-folder:last-child:not(.dialkit-folder-root) {
  padding-bottom: 0;
  margin-bottom: 0;
}

.dialkit-folder-root {
  padding-bottom: 0;
  margin-bottom: 0;
  border-bottom: none;
}

.dialkit-panel-header {
  padding-bottom: 6px;
  margin-bottom: 12px;
  border-bottom: 1px solid var(--dial-surface-subtle);
}

.dialkit-panel:not([data-mode="inline"]) .dialkit-panel-inner:not([data-collapsed="true"]) > .dialkit-folder-root > .dialkit-panel-header {
  cursor: grab;
}

.dialkit-panel:not([data-mode="inline"]) .dialkit-panel-inner:not([data-collapsed="true"]) > .dialkit-folder-root > .dialkit-panel-header:active {
  cursor: grabbing;
}

.dialkit-panel:not([data-mode="inline"]) .dialkit-panel-inner:not([data-collapsed="true"]) .dialkit-panel-icon {
  color: var(--dial-text-label);
  opacity: 0.6;
}

.dialkit-panel:not([data-mode="inline"]) .dialkit-panel-icon {
  cursor: pointer;
}

.dialkit-folder-header {
  cursor: pointer;
  user-select: none;
}

.dialkit-folder-header-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 0 8px 0;
}


.dialkit-folder-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--dial-text-section);
  letter-spacing: -0.01em;
  transform: translateY(-0.5px);
  transition: color 0.15s;
}

.dialkit-folder-title-root {
  font-size: 15px;
  font-weight: 600;
  color: var(--dial-text-root);
  transform: translateZ(0);
}

.dialkit-folder-title-row {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
}

.dialkit-folder-copy {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  padding: 0;
  background: transparent;
  border: none;
  cursor: pointer;
}

.dialkit-folder-copy svg {
  width: 14px;
  height: 14px;
  color: var(--dial-text-section);
}

.dialkit-folder-icon {
  width: 20px;
  height: 20px;
  padding: 2px;
  box-sizing: border-box;
  flex-shrink: 0;
  color: var(--dial-text-label);
  opacity: 0.6;
}

.dialkit-panel-icon {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 16px;
  height: 16px;
  color: var(--dial-text-focus);
  z-index: 1;
}

.dialkit-folder-content {
  will-change: transform;
}

/* Clip layout overflow as well as paint while a folder folds. A clip-path alone
   leaves its full contents in the outer scroll range until they unmount. */
.dialkit-folder:not(.dialkit-folder-root) > .dialkit-folder-content {
  overflow-y: clip;
}

.dialkit-folder-inner {
  display: flex;
  flex-direction: column;
  gap: var(--dial-row-gap);
  padding-bottom: 10px;
}

/* Non-root folders - top & bottom HR dividers */
.dialkit-folder:not(.dialkit-folder-root) {
  border-top: 1px solid var(--dial-surface-subtle);
  border-bottom: 1px solid var(--dial-surface-subtle);
  margin-top: 4px;
  margin-bottom: 4px;
  padding-bottom: 0;
}

.dialkit-folder:not(.dialkit-folder-root):last-child {
  border-bottom: none;
  margin-bottom: 0;
}

/* Adjacent non-root folders collapse gap and share a single divider */
.dialkit-folder:not(.dialkit-folder-root) + .dialkit-folder:not(.dialkit-folder-root) {
  margin-top: -10px;
  border-top: none;
}

/* Non-root folder header - match row height */
.dialkit-folder:not(.dialkit-folder-root) > .dialkit-folder-header {
  height: var(--dial-row-height);
  padding: 0;
}

.dialkit-folder:not(.dialkit-folder-root) > .dialkit-folder-header > .dialkit-folder-header-top {
  padding: 0;
  height: 100%;
}

/* Root folder inner needs no extra bottom padding */
.dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner {
  padding-bottom: 0;
}

/* A sole group that comes first can share the panel header's divider. */
.dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner > .dialkit-folder:first-child:not(:has(~ .dialkit-folder)) {
  border-top: none;
  margin-top: 0;
}

.dialkit-panel[data-multiple="true"] .dialkit-panel-inner:not([data-collapsed="true"]) {
  padding: 0 12px;
}

.dialkit-panel[data-multiple="true"] .dialkit-panel-inner:not([data-collapsed="true"]) .dialkit-panel-icon {
  top: 14px;
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-panel-header {
  padding-top: 0;
  padding-bottom: 0;
  margin-bottom: 0;
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-panel-header > .dialkit-folder-header-top,
.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner > .dialkit-folder > .dialkit-folder-header > .dialkit-folder-header-top {
  height: 44px;
  padding: 0;
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner > .dialkit-folder > .dialkit-folder-header {
  height: auto;
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner {
  gap: 0;
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner > .dialkit-folder {
  margin: 0;
  padding-bottom: 0;
  border-top: 1px solid var(--dial-surface-subtle);
  border-bottom: none;
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner > .dialkit-folder > .dialkit-folder-header .dialkit-folder-title {
  font-size: 15px;
  font-weight: 600;
  line-height: 20px;
  color: var(--dial-text-root);
  transform: translateZ(0);
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-title-root {
  line-height: 20px;
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner > .dialkit-folder:first-child {
  border-top: none;
  margin-top: 0;
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner > .dialkit-folder + .dialkit-folder {
  margin-top: 0;
}

.dialkit-panel[data-multiple="true"] .dialkit-folder-root > .dialkit-folder-content > .dialkit-folder-inner > .dialkit-folder > .dialkit-folder-content > .dialkit-folder-inner {
  padding-top: 0;
  padding-bottom: 12px;
}

/* Only registered panels stick; ordinary folders remain part of the content. */
.dialkit-panel .dialkit-folder.dialkit-folder-section > .dialkit-folder-header {
  position: sticky;
  top: var(--dial-panel-header-height, 0px);
  z-index: 2;
  height: auto;
  background: var(--dial-glass-bg);
}

.dialkit-folder-section {
  --dial-section-header-height: calc(44px + var(--dial-row-height) + 10px);
}

/* Keyboard navigation must reveal controls below both pinned header rows. */
.dialkit-folder-inner :is(button, input, textarea, [tabindex]) {
  scroll-margin-top: calc(var(--dial-panel-header-height, 0px) + var(--dial-section-header-height, 0px) + var(--dial-row-gap));
}

.dialkit-folder.dialkit-folder-section > .dialkit-folder-header > .dialkit-folder-header-top {
  height: var(--dial-row-height);
}

.dialkit-panel-section-toolbar-clip {
  overflow-y: clip;
}

.dialkit-folder-section > .dialkit-folder-header > .dialkit-panel-section-toolbar-clip > .dialkit-panel-section-toolbar {
  padding-top: 4px;
  padding-bottom: var(--dial-row-gap);
  box-sizing: content-box;
}

.dialkit-panel-toolbar:empty,
.dialkit-panel-section-toolbar:empty {
  display: none;
}

/* Content spacing handled by folder-inner gap */


/* Slider */
.dialkit-slider-wrapper {
  position: relative;
  height: var(--dial-row-height);
}

.dialkit-slider {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  cursor: pointer;
  user-select: none;
  overflow: hidden;
  background: var(--dial-surface);
  border-radius: var(--dial-radius);
  touch-action: none;
}

.dialkit-slider-hashmarks {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

.dialkit-slider-hashmark {
  position: absolute;
  top: 50%;
  width: 1px;
  height: 8px;
  border-radius: 999px;
  transform: translateX(-50%) translateY(-50%);
  background: rgba(255, 255, 255, 0);
  transition: background 200ms;
}

.dialkit-slider-active .dialkit-slider-hashmark {
  background: var(--dial-border-hover);
}

.dialkit-slider-active .dialkit-slider-value {
  color: var(--dial-text-focus);
}

.dialkit-slider-fill {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  background: var(--dial-surface-active);
  transition: background 0.15s;
  pointer-events: none;
}

.dialkit-slider-active .dialkit-slider-fill {
  background: var(--dial-border-hover);
}

.dialkit-slider-handle {
  position: absolute;
  top: 50%;
  width: 3px;
  height: 20px;
  border-radius: 999px;
  background: var(--dial-text-primary);
  pointer-events: none;
}

.dialkit-slider-label {
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(calc(-50% - 0.5px));
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  pointer-events: none;
  transition: color 0.15s;
  display: inline-flex;
  align-items: center;
}

.dialkit-slider-value {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(calc(-50% + 0.5px));
  font-size: 13px;
  font-weight: 500;
  font-family: 'Geist Mono', monospace;
  color: var(--dial-text-label);
  pointer-events: auto;
  transition: color 0.15s, border-color 0.15s;
  border-bottom: 1px solid transparent;
  padding-bottom: 1px;
}

.dialkit-slider-value-editable {
  border-bottom-color: var(--dial-text-label);
}

.dialkit-slider-input {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  width: 4ch;
  min-width: 3ch;
  max-width: 6ch;
  font-size: 13px;
  font-weight: 500;
  font-family: 'Geist Mono', monospace;
  color: var(--dial-text-label);
  background: transparent;
  border: none;
  border-bottom: 1px solid var(--dial-text-label);
  padding: 0 0 1px 0;
  outline: none;
  text-align: right;
}

.dialkit-slider-input:focus {
  color: var(--dial-text-focus);
}

/* Segmented Control */
.dialkit-segmented {
  position: relative;
  display: flex;
  padding: 2px;
  background: transparent;
  border-radius: var(--dial-radius);
}

.dialkit-segmented-pill {
  position: absolute;
  top: 2px;
  bottom: 2px;
  background: var(--dial-surface-active);
  border-radius: 6px;
  z-index: 0;
  pointer-events: none;
}

.dialkit-segmented-button {
  position: relative;
  z-index: 1;
  flex: 0 0 auto;
  padding: 6px 8px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  background: transparent;
  border: none;
  cursor: pointer;
  transition: color 0.15s;
}

.dialkit-segmented-button[data-active="true"] {
  color: var(--dial-text-primary);
}

.dialkit-segmented-button[data-active="false"] {
  color: var(--dial-text-label);
}

/* Toggle */
.dialkit-toggle {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  background: var(--dial-surface);
  border-radius: var(--dial-radius);
  cursor: pointer;
  user-select: none;
  transition: background 0.15s;
}

.dialkit-toggle:hover {
  background: var(--dial-surface-hover);
}

.dialkit-toggle-label {
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  transition: color 0.15s;
}

.dialkit-toggle[data-checked="true"] .dialkit-toggle-label {
  color: var(--dial-text-primary);
}

.dialkit-toggle-track {
  width: 36px;
  height: 20px;
  border-radius: 10px;
  background: var(--dial-surface-active);
  transition: background 0.2s;
  position: relative;
}

.dialkit-toggle[data-checked="true"] .dialkit-toggle-track {
  background: var(--dial-border-hover);
}

.dialkit-toggle-thumb {
  position: absolute;
  top: 2px;
  width: 16px;
  height: 16px;
  border-radius: 8px;
  background: var(--dial-text-primary);
}

/* Button Group */
.dialkit-button-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.dialkit-button {
  flex: 1;
  padding: 10px 16px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-secondary);
  background: var(--dial-surface);
  border: none;
  border-radius: var(--dial-radius);
  cursor: pointer;
  transition: background 0.15s, color 0.15s;
}

.dialkit-button:hover {
  background: var(--dial-surface-hover);
  color: var(--dial-text-primary);
}

.dialkit-button:active {
  background: var(--dial-surface-active);
}

/* Labeled Control Row (label + control side by side) */
.dialkit-labeled-control {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: var(--dial-row-height);
  padding: 2px 10px 2px 12px;
  background: var(--dial-surface);
  border-radius: var(--dial-radius);
}

.dialkit-labeled-control-label {
  display: flex;
  align-items: center;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  flex-shrink: 0;
  line-height: 17px;
}

.dialkit-labeled-control .dialkit-segmented {
  flex-shrink: 0;
  margin-right: -6px;
}

.dialkit-action-button {
  width: 160px;
  flex-shrink: 0;
  padding: 10px 16px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-secondary);
  background: var(--dial-surface);
  border: none;
  border-radius: var(--dial-radius);
  cursor: pointer;
  transition: background 0.15s, color 0.15s;
}

.dialkit-action-button:hover {
  background: var(--dial-surface-hover);
  color: var(--dial-text-primary);
}

.dialkit-action-button:active {
  background: var(--dial-surface-active);
}

.dialkit-actions-group {
  align-items: flex-start;
}

.dialkit-actions-stack {
  display: flex;
  flex-direction: column;
  gap: 6px;
  width: 160px;
}

/* Spring Visualization */
.dialkit-spring-viz {
  width: 100%;
  border-radius: var(--dial-radius);
  background: var(--dial-surface);
  overflow: visible;
}

.dialkit-easing-viz {
  position: relative;
  width: 100%;
  aspect-ratio: 256 / 180;
  border-radius: var(--dial-radius);
  background: var(--dial-surface);
  overflow: hidden;
  isolation: isolate;
}

.dialkit-easing-viz svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.dialkit-easing-reference {
  stroke: var(--dial-text-tertiary);
  stroke-width: 1;
  stroke-dasharray: 3 4;
  opacity: 0.4;
}

.dialkit-easing-tangent {
  stroke: var(--dial-text-tertiary);
  stroke-width: 1;
}

.dialkit-easing-curve {
  fill: none;
  stroke: var(--dial-text-primary);
  stroke-width: 2;
  stroke-linecap: round;
}

.dialkit-easing-endpoint {
  fill: var(--dial-text-secondary);
}

.dialkit-easing-handle {
  position: absolute;
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  padding: 0;
  border: 0;
  border-radius: 50%;
  background: transparent;
  transform: translate(-50%, -50%);
  cursor: grab;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
}

.dialkit-easing-handle::after {
  content: '';
  width: 10px;
  height: 10px;
  box-sizing: border-box;
  border: 1.5px solid var(--dial-text-secondary);
  border-radius: 50%;
  background: var(--dial-surface);
}

.dialkit-easing-handle:hover::after,
.dialkit-easing-handle:focus-visible::after,
.dialkit-easing-handle[data-dragging]::after {
  border-color: var(--dial-text-primary);
  background: var(--dial-text-primary);
}

.dialkit-easing-handle[data-dragging] {
  cursor: grabbing;
  z-index: 1;
}

.dialkit-easing-handle:disabled {
  pointer-events: none;
}

.dialkit-easing-instructions {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}

/* Panel Wrapper (contains panel + toolbar) */
.dialkit-panel-wrapper {
  display: inline-flex;
  flex-direction: column;
}

/* Panel Toolbar */
.dialkit-panel-toolbar {
  display: flex;
  align-items: center;
  gap: 6px;
  height: var(--dial-row-height);
  margin-bottom: 6px;
  min-width: 0;
  overflow: hidden;
}

.dialkit-panel-section-toolbar {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  height: var(--dial-row-height);
  min-width: 0;
  overflow: hidden;
}

.dialkit-toolbar-add {
  display: flex;
  align-items: center;
  justify-content: center;
  width: var(--dial-row-height);
  height: var(--dial-row-height);
  padding: 0;
  flex-shrink: 0;
  background: var(--dial-surface);
  border: none;
  border-radius: var(--dial-radius);
  cursor: pointer;
  transition: background 0.15s;
}

.dialkit-toolbar-add:hover {
  background: var(--dial-surface-hover);
}

.dialkit-timeline-toolbar-toggle[data-active] {
  background: var(--dial-surface-active);
  color: var(--dial-text-root);
}

.dialkit-toolbar-add svg {
  width: 16px;
  height: 16px;
  color: var(--dial-text-label);
}

.dialkit-timeline-toolkit-only {
  height: var(--dial-row-height);
  display: flex;
  align-items: center;
  padding: 0 12px;
  border-radius: var(--dial-radius);
  background: var(--dial-surface-subtle);
  color: var(--dial-text-secondary);
  font-size: 12px;
}

.dialkit-toolbar-copy {
  position: relative;
  display: flex;
  align-items: center;
  gap: 6px;
  height: var(--dial-row-height);
  padding: 0 12px;
  flex-shrink: 0;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  background: var(--dial-surface);
  border: none;
  border-radius: var(--dial-radius);
  cursor: pointer;
  transition: background 0.15s;
}

.dialkit-toolbar-copy:hover {
  background: var(--dial-surface-hover);
}

.dialkit-toolbar-copy-icon-wrap {
  position: relative;
  width: 16px;
  height: 16px;
  flex-shrink: 0;
}

.dialkit-toolbar-copy-icon {
  position: absolute;
  inset: 0;
  width: 16px;
  height: 16px;
}

/* Text Control */
.dialkit-text-control {
  position: relative;
  box-sizing: border-box;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  height: var(--dial-row-height);
  min-height: var(--dial-row-height);
  /* Hidden overflow still lets caret navigation scroll this animated row. */
  overflow: clip;
  padding: calc((var(--dial-row-height) - 18px) / 2) 12px;
  background: var(--dial-surface);
  border-radius: var(--dial-radius);
}

.dialkit-text-label {
  line-height: 18px;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  flex-shrink: 0;
}

.dialkit-text-input {
  display: block;
  box-sizing: border-box;
  margin: 0;
  margin-right: calc(-1 * var(--dial-text-gutter, 0px));
  flex: 1;
  width: 0;
  min-width: 0;
  height: 18px;
  line-height: 18px;
  resize: none;
  overflow: hidden;
  overflow-wrap: anywhere;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  scrollbar-gutter: stable;
  scrollbar-color: var(--dial-text-tertiary) transparent;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  background: transparent;
  border: none;
  padding: 0;
  outline: none;
  text-align: right;
  cursor: text;
}

.dialkit-text-control[data-autosized] {
  transition: height 180ms cubic-bezier(0.2, 0, 0, 1);
}

.dialkit-text-input::-webkit-scrollbar { width: 6px; }
.dialkit-text-input::-webkit-scrollbar-track { background: transparent; }
.dialkit-text-input::-webkit-scrollbar-thumb {
  background: var(--dial-text-tertiary);
  border-radius: 3px;
}

@media (prefers-reduced-motion: reduce) {
  .dialkit-text-control[data-autosized] { transition: none; }
}

.dialkit-text-input:focus {
  color: var(--dial-text-focus);
}

.dialkit-text-input:focus-visible {
  background-image: linear-gradient(var(--dial-focus-ring), var(--dial-focus-ring));
  background-repeat: no-repeat;
  background-position: 4px bottom;
  background-size: calc(100% - var(--dial-text-gutter, 0px) - 4px) 1px;
}

.dialkit-text-input::placeholder {
  color: var(--dial-text-tertiary);
}

/* Select Control - Full-width row */
.dialkit-select-row {
}

.dialkit-select-trigger {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: var(--dial-row-height);
  padding: 0 12px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  background: var(--dial-surface);
  border: none;
  border-radius: var(--dial-radius);
  cursor: pointer;
  transition: background 0.15s;
}

.dialkit-select-trigger:hover {
  background: var(--dial-surface-hover);
}

.dialkit-select-trigger[data-open="true"] {
  background: var(--dial-surface-active);
}

.dialkit-select-label {
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  flex-shrink: 0;
  transform: translateY(-0.5px);
}

.dialkit-select-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

.dialkit-select-value {
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  transform: translateY(-0.5px);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.dialkit-select-chevron {
  width: 20px;
  height: 20px;
  padding: 2px;
  box-sizing: border-box;
  flex-shrink: 0;
  opacity: 0.6;
}

/* Select Dropdown (portaled to body) */
.dialkit-select-dropdown {
  margin: 0;
  inset: auto;
  box-sizing: border-box;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  scrollbar-color: var(--dial-border-hover) transparent;
  background: var(--dial-glass-bg);
  border: 1px solid var(--dial-border);
  border-radius: var(--dial-radius);
  padding: 4px;
  z-index: 10000;
  box-shadow: var(--dial-shadow-dropdown);
}

.dialkit-select-option {
  min-height: 36px;
  display: block;
  width: 100%;
  padding: 8px 10px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  background: transparent;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  text-align: left;
  transition: background 0.15s, color 0.15s;
}

.dialkit-select-option:hover {
  background: var(--dial-surface-hover);
}

.dialkit-select-option[data-selected="true"] {
  color: var(--dial-text-primary);
  background: var(--dial-surface-active);
}

/* Image selector: shared by React, Solid, Vue, and Svelte. */
.dialkit-image-control {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: var(--dial-row-height);
  padding: 0 6px 0 12px;
  border: 0;
  border-radius: var(--dial-radius);
  background: var(--dial-surface);
  color: var(--dial-text-label);
  font: 500 13px system-ui, -apple-system, sans-serif;
  text-align: left;
  cursor: pointer;
  transition: background 0.15s, box-shadow 0.15s;
}
.dialkit-image-control:hover { background: var(--dial-surface-hover); }
.dialkit-image-control[data-open="true"] { background: var(--dial-surface-active); box-shadow: inset 0 0 0 1px var(--dial-border-hover); color: var(--dial-text-primary); }
.dialkit-image-label { flex-shrink: 0; }
.dialkit-image-value { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: right; color: var(--dial-text-secondary); font-size: 12px; }
.dialkit-image-frame { position: relative; display: block; overflow: hidden; border-radius: var(--dial-radius); background: repeating-conic-gradient(var(--dial-surface) 0% 25%, transparent 0% 50%) 0 / 12px 12px, var(--dial-surface); }
.dialkit-image-img { display: block; width: 100%; height: 100%; object-fit: cover; }
.dialkit-image-fallback { position: absolute; inset: 0; display: grid; place-items: center; color: var(--dial-text-tertiary); }
.dialkit-image-fallback svg { width: 24px; height: 24px; }
.dialkit-image-thumbnail { flex: 0 0 38px; height: 26px; border-radius: 5px; box-shadow: inset 0 0 0 1px var(--dial-border); }
.dialkit-image-thumbnail svg { width: 16px; height: 16px; }
.dialkit-image-popover {
  display: flex;
  flex-direction: column;
  gap: 10px;
  position: fixed;
  margin: 0;
  inset: auto;
  z-index: 10002;
  box-sizing: border-box;
  padding: 12px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  scrollbar-color: var(--dial-border-hover) transparent;
  border: 1px solid var(--dial-border);
  border-radius: 14px;
  background: var(--dial-glass-bg);
  box-shadow: var(--dial-shadow);
  color: var(--dial-text-label);
  font: 500 13px system-ui, -apple-system, sans-serif;
  animation: dialkit-color-enter 0.16s ease-out;
}
.dialkit-image-popover *, .dialkit-image-popover *::before, .dialkit-image-popover *::after { box-sizing: border-box; }
.dialkit-image-popover > * { flex-shrink: 0; }
.dialkit-image-heading { display: flex; align-items: center; justify-content: space-between; gap: 12px; min-width: 0; }
.dialkit-image-title { color: var(--dial-text-primary); }
.dialkit-image-clear { margin: -4px -4px -4px 0; padding: 4px; border: 0; border-radius: 4px; background: none; color: var(--dial-text-tertiary); font: inherit; font-size: 11px; cursor: pointer; }
.dialkit-image-clear:hover { color: var(--dial-text-primary); }
.dialkit-image-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: var(--dial-row-gap); }
.dialkit-image-option { position: relative; display: block; width: 100%; padding: 3px; border: 1px solid transparent; border-radius: calc(var(--dial-radius) + 3px); background: transparent; cursor: pointer; transition: border-color 0.15s, background 0.15s; }
.dialkit-image-option-preview { width: 100%; aspect-ratio: 4 / 3; border-radius: calc(var(--dial-radius) - 1px); }
.dialkit-image-option:hover { background: var(--dial-surface-hover); border-color: var(--dial-border-hover); }
.dialkit-image-option[aria-pressed="true"] { border-color: var(--dial-text-label); background: var(--dial-surface-active); }
.dialkit-image-upload { display: flex; flex: none; align-items: center; justify-content: center; gap: 8px; width: 100%; }
.dialkit-image-upload svg { width: 15px; height: 15px; }
.dialkit-image-popover[data-dragging="true"] .dialkit-image-upload { background: var(--dial-surface-hover); color: var(--dial-text-primary); }
.dialkit-image-upload[aria-disabled="true"] { opacity: 0.6; cursor: progress; }
.dialkit-image-empty { padding: 28px 12px; border-radius: var(--dial-radius); background: var(--dial-surface); color: var(--dial-text-tertiary); font-weight: 400; text-align: center; }
.dialkit-image-status { font-size: 11px; font-weight: 400; line-height: 1.5; overflow-wrap: anywhere; }
.dialkit-image-popover [hidden], .dialkit-image-frame [hidden], .dialkit-image-file { display: none; }
@media (prefers-reduced-motion: reduce) { .dialkit-image-popover { animation: none; } }

/* DialPad: a continuous two-axis field, shared across frameworks. */
.dialkit-pad { display: grid; gap: var(--dial-row-gap); min-width: 0; }
.dialkit-pad-caption { display: flex; align-items: center; min-width: 0; height: var(--dial-row-height); padding: 0 12px; border-radius: var(--dial-radius); background: var(--dial-surface); }
.dialkit-pad-label { flex: 1; min-width: 0; color: var(--dial-text-label); font-size: 13px; font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dialkit-pad-surface { position: relative; width: 100%; aspect-ratio: 1; overflow: hidden; border-radius: var(--dial-radius); background: var(--dial-surface); cursor: crosshair; touch-action: none; user-select: none; -webkit-user-select: none; }
.dialkit-pad-plane { position: absolute; inset: 12px; pointer-events: none; }
.dialkit-pad-grid { position: absolute; inset: 0; pointer-events: none; }
.dialkit-pad-grid-line { position: absolute; background: var(--dial-border); opacity: 0.65; }
.dialkit-pad-grid-vertical { top: 0; bottom: 0; width: 1px; transform: translateX(-50%); }
.dialkit-pad-grid-horizontal { left: 0; right: 0; height: 1px; transform: translateY(-50%); }
.dialkit-pad-center { position: absolute; top: 50%; left: 50%; width: 3px; height: 3px; border-radius: 50%; background: var(--dial-text-tertiary); transform: translate(-50%, -50%); }
.dialkit-pad-point { position: absolute; width: 12px; height: 12px; border-radius: 50%; background: var(--dial-text-primary); box-shadow: 0 0 0 0 transparent, 0 2px 4px #0003; transform: translate(-50%, -50%); transition: box-shadow 0.15s; pointer-events: auto; cursor: grab; }
.dialkit-pad-surface[data-dragging="true"], .dialkit-pad-surface[data-dragging="true"] .dialkit-pad-point { cursor: grabbing; }
.dialkit-pad-surface[data-dragging="true"] .dialkit-pad-point { box-shadow: 0 0 0 6px var(--dial-border-hover), 0 2px 6px #0003; }
.dialkit-pad-fields { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: var(--dial-row-gap); }
.dialkit-pad-field { display: flex; align-items: center; gap: 4px; min-width: 0; height: var(--dial-row-height); padding: 0 12px 0 10px; border-radius: var(--dial-radius); background: var(--dial-surface); }
.dialkit-pad-axis { min-width: 0; max-width: 35%; flex-shrink: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; font-weight: 500; color: var(--dial-text-label); }
.dialkit-pad-value { min-width: 0; width: 100%; border: 0; padding: 0 0 1px; background: transparent; color: var(--dial-text-label); text-align: right; font: 500 13px 'Geist Mono', monospace; }
.dialkit-pad-field:focus-within { background: var(--dial-surface-hover); }
.dialkit-pad-value:focus-visible { box-shadow: inset 0 -1px var(--dial-focus-ring); }
.dialkit-pad-value:focus { color: var(--dial-text-focus); }
.dialkit-pad-instructions { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; border: 0; }
@media (prefers-reduced-motion: reduce) { .dialkit-pad-point { transition: none; } }

/* Color Control */
.dialkit-color-control {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: var(--dial-row-height);
  padding: 0 12px;
  background: var(--dial-surface);
  border-radius: var(--dial-radius);
  transition: background 0.15s, box-shadow 0.15s;
}

.dialkit-color-control[data-open="true"] {
  background: var(--dial-surface-active);
  box-shadow: inset 0 0 0 1px var(--dial-border-hover);
}
.dialkit-color-control[data-open="true"] .dialkit-color-label,
.dialkit-color-control[data-open="true"] .dialkit-color-value { color: var(--dial-text-primary); }

.dialkit-color-label {
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  flex-shrink: 0;
  transform: translateY(-0.5px);
}

.dialkit-color-inputs {
  display: flex;
  align-items: center;
  gap: 8px;
}

/* Color picker: shared by React, Solid, Vue, and Svelte. */
.dialkit-color-inputs { min-width: 0; flex: 1; justify-content: flex-end; }
.dialkit-color-value {
  min-width: 0;
  width: 100%;
  padding: 4px 0;
  border: 0;
  outline: none;
  background: transparent;
  color: var(--dial-text-label);
  font: 500 13px 'Geist Mono', monospace;
  text-align: right;
  text-overflow: ellipsis;
}
.dialkit-color-value:focus { color: var(--dial-text-focus); }
.dialkit-color-swatch {
  flex: 0 0 20px;
  width: 20px;
  height: 20px;
  padding: 0;
  border-radius: 5px;
  border: 1px solid var(--dial-border-hover);
  background: linear-gradient(var(--dial-color), var(--dial-color)), repeating-conic-gradient(#aaa 0% 25%, #eee 0% 50%) 0 / 8px 8px;
  box-shadow: inset 0 0 0 1px rgb(255 255 255 / 8%);
  cursor: pointer;
  transition: transform 0.15s;
}
.dialkit-color-swatch:hover { transform: scale(1.08); }
.dialkit-color-popover {
  display: grid;
  gap: var(--dial-row-gap);
  position: fixed;
  margin: 0;
  inset: auto;
  z-index: 10002;
  box-sizing: border-box;
  padding: 10px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  border: 1px solid var(--dial-border);
  border-radius: 14px;
  background: var(--dial-glass-bg);
  box-shadow: var(--dial-shadow);
  color: var(--dial-text-label);
  animation: dialkit-color-enter 0.16s ease-out;
}
.dialkit-color-popover *, .dialkit-color-popover *::before, .dialkit-color-popover *::after { box-sizing: border-box; }
.dialkit-color-plane { position: relative; height: 160px; border-radius: var(--dial-radius); touch-action: none; cursor: crosshair; user-select: none; }
.dialkit-color-canvas { display: block; width: 100%; height: 100%; border-radius: inherit; }
.dialkit-color-plane::after { content: ''; position: absolute; inset: 0; border-radius: inherit; box-shadow: inset 0 0 0 1px rgb(0 0 0 / 10%); pointer-events: none; }
.dialkit-color-marker { position: absolute; z-index: 1; width: 12px; height: 12px; margin: -6px; border: 2px solid #fff; border-radius: 50%; box-shadow: 0 2px 4px rgb(0 0 0 / 30%); pointer-events: none; }
.dialkit-color-tracks { display: grid; gap: var(--dial-row-gap); }
.dialkit-color-track-row { display: flex; align-items: center; gap: 12px; height: var(--dial-row-height); padding: 0 12px; border-radius: var(--dial-radius); background: var(--dial-surface); font-size: 13px; font-weight: 500; }
.dialkit-color-track-row > span { flex: 0 0 52px; color: var(--dial-text-label); }
.dialkit-color-track {
  -webkit-appearance: none; appearance: none; flex: 1; min-width: 0; height: 100%; padding: 0; margin: 0; border: 0; background: transparent; cursor: pointer; touch-action: none;
}
.dialkit-color-hue {
  --dial-color-thumb-bg: var(--dial-color-thumb);
}
.dialkit-color-opacity {
  --dial-color-track-bg: linear-gradient(to right, transparent, var(--dial-color-opaque)), repeating-conic-gradient(#aaa 0% 25%, #eee 0% 50%) 0 / 8px 8px;
  --dial-color-thumb-bg: linear-gradient(var(--dial-color-thumb), var(--dial-color-thumb)), repeating-conic-gradient(#aaa 0% 25%, #eee 0% 50%) 0 / 8px 8px;
}
.dialkit-color-track::-webkit-slider-runnable-track { height: 16px; border-radius: 4px; background: var(--dial-color-track-bg); }
.dialkit-color-track::-moz-range-track { height: 16px; border: 0; border-radius: 4px; background: var(--dial-color-track-bg); }
.dialkit-color-track::-webkit-slider-thumb { -webkit-appearance: none; box-sizing: border-box; width: 16px; height: 24px; margin-top: -4px; border-radius: 5px; background: var(--dial-color-thumb-bg); background-clip: padding-box; border: 2px solid white; box-shadow: 0 2px 4px rgb(0 0 0 / 30%); }
.dialkit-color-track::-moz-range-thumb { box-sizing: border-box; width: 16px; height: 24px; border-radius: 5px; background: var(--dial-color-thumb-bg); background-clip: padding-box; border: 2px solid white; box-shadow: 0 2px 4px rgb(0 0 0 / 30%); }
/* The same row, buttons, and pill as Enabled, with no label and equal segments. */
.dialkit-color-format-row { padding: 2px; }
.dialkit-color-format-row .dialkit-color-formats { flex: 1; min-width: 0; margin-right: 0; }
.dialkit-color-formats .dialkit-segmented-pill { left: 2px; width: calc((100% - 4px) / 3); transition: transform 0.2s cubic-bezier(0.25, 1, 0.5, 1); }
.dialkit-color-format { flex: 1 1 0; min-width: 0; white-space: nowrap; }
.dialkit-color-format:hover { color: var(--dial-text-primary); }
.dialkit-color-css-input { display: block; width: 100%; height: var(--dial-row-height); padding: 0 12px; border: 0; border-radius: var(--dial-radius); background: var(--dial-surface); outline: none; color: var(--dial-text-label); font: 500 13px 'Geist Mono', monospace; }
.dialkit-color-css-input:focus { color: var(--dial-text-focus); }
.dialkit-color-popover input[aria-invalid="true"], .dialkit-color-value[aria-invalid="true"] { color: #ef7777; }
@keyframes dialkit-color-enter { from { opacity: 0; transform: translateY(3px) scale(0.98); } to { opacity: 1; transform: none; } }
@media (prefers-reduced-motion: reduce) {
  .dialkit-color-popover { animation: none; }
  .dialkit-color-formats .dialkit-segmented-pill { transition: none; }
}

/* Preset Manager */
.dialkit-preset-manager {
  position: relative;
  flex: 1;
}

.dialkit-preset-trigger {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: var(--dial-row-height);
  padding: 0 12px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  background: var(--dial-surface);
  border: none;
  border-radius: var(--dial-radius);
  cursor: pointer;
  transition: background 0.15s;
}

.dialkit-preset-trigger:hover {
  background: var(--dial-surface-hover);
}

.dialkit-preset-trigger[data-disabled="true"] {
  cursor: default;
}

.dialkit-preset-trigger[data-disabled="true"]:hover {
  background: var(--dial-surface);
}

.dialkit-preset-trigger[data-open="true"] {
  background: var(--dial-surface-active);
}

.dialkit-preset-label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}


.dialkit-preset-dropdown {
  margin: 0;
  inset: auto;
  overflow-y: auto;
  overscroll-behavior: contain;
  width: max-content;
  background: var(--dial-dropdown-bg);
  border: 1px solid var(--dial-border);
  border-radius: 12px;
  padding: 4px;
  z-index: 10000;
  box-shadow: var(--dial-shadow-dropdown);
}

.dialkit-preset-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
  margin-bottom: 4px;
  padding-bottom: 4px;
  border-bottom: 1px solid var(--dial-border);
}

.dialkit-preset-item {
  box-sizing: border-box;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10px;
  gap: 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s;
}

.dialkit-preset-item + .dialkit-preset-item {
  margin-top: 2px;
}

.dialkit-preset-item:hover {
  background: var(--dial-surface-hover);
}

.dialkit-preset-item[data-active="true"] {
  background: var(--dial-surface-active);
}

.dialkit-preset-name {
  flex: 1;
  min-width: 0;
  padding: 0;
  border: 0;
  border-radius: 4px;
  background: transparent;
  font-family: inherit;
  text-align: left;
  cursor: pointer;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.dialkit-preset-item[data-active="true"] .dialkit-preset-name {
  color: var(--dial-text-primary);
}

.dialkit-preset-delete {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  padding: 0;
  background: transparent;
  border: none;
  cursor: pointer;
  opacity: 0;
  transition: opacity 0.15s;
  flex-shrink: 0;
}

.dialkit-preset-item:hover .dialkit-preset-delete {
  opacity: 0.6;
}

.dialkit-preset-item:focus-within .dialkit-preset-delete { opacity: 0.6; }
.dialkit-preset-item:focus-within { background: var(--dial-surface-hover); }

.dialkit-preset-delete:hover {
  opacity: 1 !important;
}

.dialkit-preset-delete svg {
  transition: color 150ms ease;
  width: 14px;
  height: 14px;
  color: var(--dial-text-focus);
  pointer-events: none;
}

.dialkit-preset-delete:hover svg {
  color: #ff3b30;
}

.dialkit-preset-save-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  width: 100%;
  padding: 8px 10px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  background: transparent;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.15s, color 0.15s;
}

.dialkit-preset-save-btn:hover {
  background: var(--dial-surface-hover);
  color: var(--dial-text-primary);
}

.dialkit-preset-save-btn svg {
  width: 12px;
  height: 12px;
}

.dialkit-preset-save-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px;
}

.dialkit-preset-input {
  flex: 1;
  min-width: 0;
  padding: 6px 8px;
  font-family: inherit;
  font-size: 13px;
  color: var(--dial-text-primary);
  background: var(--dial-surface);
  border: 1px solid var(--dial-border);
  border-radius: 6px;
  outline: none;
}

.dialkit-preset-input:focus {
  border-color: var(--dial-text-label);
}

.dialkit-preset-input::placeholder {
  color: var(--dial-text-tertiary);
}

.dialkit-preset-confirm {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  padding: 0;
  background: var(--dial-surface);
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.15s;
}

.dialkit-preset-confirm:hover:not(:disabled) {
  background: var(--dial-surface-hover);
}

.dialkit-preset-confirm:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.dialkit-preset-confirm svg {
  width: 14px;
  height: 14px;
  color: var(--dial-text-label);
}

/* Shortcut Pill */
.dialkit-shortcut-pill {
  display: inline-block;
  font-size: 10px;
  font-weight: 600;
  font-family: system-ui, -apple-system, sans-serif;
  color: var(--dial-text-tertiary);
  background: var(--dial-surface-subtle);
  padding: 1px 5px;
  border-radius: 4px;
  margin-left: 6px;
  letter-spacing: 0.02em;
  line-height: 16px;
  white-space: nowrap;
  vertical-align: middle;
  transition: color 0.15s, background 0.15s;
}

.dialkit-shortcut-pill-active {
  color: var(--dial-text-primary);
  background: var(--dial-border-hover);
}

/* Shortcuts Menu Trigger */
.dialkit-shortcuts-trigger {
  display: flex;
  align-items: center;
  justify-content: center;
  width: var(--dial-row-height);
  height: var(--dial-row-height);
  padding: 0;
  flex-shrink: 0;
  background: var(--dial-surface);
  border: none;
  border-radius: var(--dial-radius);
  cursor: pointer;
  transition: background 0.15s;
}

.dialkit-shortcuts-trigger:hover {
  background: var(--dial-surface-hover);
}

.dialkit-shortcuts-trigger svg {
  width: 16px;
  height: 16px;
  color: var(--dial-text-label);
}

/* Shortcuts Dropdown */
.dialkit-shortcuts-dropdown {
  background: var(--dial-dropdown-bg);
  border: 1px solid var(--dial-border);
  border-radius: 12px;
  padding: 8px;
  z-index: 10000;
  box-shadow: var(--dial-shadow-dropdown);
  min-width: 200px;
}

.dialkit-shortcuts-title {
  font-size: 11px;
  font-weight: 600;
  color: var(--dial-text-tertiary);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  padding: 4px 8px 8px;
}

.dialkit-shortcuts-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.dialkit-shortcuts-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 8px;
  border-radius: 6px;
}

.dialkit-shortcuts-row-key {
  font-size: 11px;
  font-weight: 600;
  font-family: ui-monospace, 'SF Mono', 'Courier New', monospace;
  color: var(--dial-text-secondary);
  background: var(--dial-surface-subtle);
  padding: 2px 6px;
  border-radius: 4px;
  min-width: 28px;
  text-align: center;
}

.dialkit-shortcuts-row-label {
  flex: 1;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
}

.dialkit-shortcuts-row-mode {
  font-size: 11px;
  font-weight: 500;
  color: var(--dial-text-tertiary);
  font-style: italic;
}

.dialkit-shortcuts-hint {
  font-size: 11px;
  color: var(--dial-text-tertiary);
  padding: 6px 8px 2px;
  border-top: 1px solid var(--dial-border);
  margin-top: 4px;
}

/* ── Light Theme ── */
.dialkit-root[data-theme="light"] {
  --dial-surface: rgba(0, 0, 0, 0.04);
  --dial-surface-hover: rgba(0, 0, 0, 0.08);
  --dial-surface-active: rgba(0, 0, 0, 0.1);
  --dial-surface-subtle: rgba(0, 0, 0, 0.06);

  --dial-text-root: #000000;
  --dial-text-section: rgba(0, 0, 0, 0.65);
  --dial-text-label: rgba(0, 0, 0, 0.6);
  --dial-text-focus: #000000;

  --dial-text-primary: rgba(0, 0, 0, 0.9);
  --dial-text-secondary: rgba(0, 0, 0, 0.55);
  --dial-text-tertiary: rgba(0, 0, 0, 0.35);

  --dial-border: rgba(0, 0, 0, 0.1);
  --dial-border-hover: rgba(0, 0, 0, 0.15);
  --dial-focus-ring: rgba(0, 0, 0, 0.55);

  --dial-timeline-clip-overlay: rgba(0, 0, 0, 0.28);

  --dial-glass-bg: #fafafa;
  --dial-dropdown-bg: #ffffff;
  --dial-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  --dial-shadow-collapsed: 0 2px 10px rgba(0, 0, 0, 0.06);
  --dial-shadow-dropdown: 0 4px 16px rgba(0, 0, 0, 0.08);
}

/* Light mode: SVG visualization overrides */
.dialkit-root[data-theme="light"] .dialkit-spring-viz line {
  stroke: rgba(0, 0, 0, 0.08);
}

.dialkit-root[data-theme="light"] .dialkit-spring-viz line[stroke-dasharray] {
  stroke: rgba(0, 0, 0, 0.15);
}

.dialkit-root[data-theme="light"] .dialkit-spring-viz path {
  stroke: rgba(0, 0, 0, 0.5);
}

/* Light mode: toggle thumb needs shadow for definition */
.dialkit-root[data-theme="light"] .dialkit-toggle-thumb {
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.06), 0 1px 2px rgba(0, 0, 0, 0.08);
}

/* ── System preference: light ── */
@media (prefers-color-scheme: light) {
  .dialkit-root[data-theme="system"] {
    --dial-surface: rgba(0, 0, 0, 0.04);
    --dial-surface-hover: rgba(0, 0, 0, 0.08);
    --dial-surface-active: rgba(0, 0, 0, 0.1);
    --dial-surface-subtle: rgba(0, 0, 0, 0.06);

    --dial-text-root: #000000;
    --dial-text-section: rgba(0, 0, 0, 0.65);
    --dial-text-label: rgba(0, 0, 0, 0.6);
    --dial-text-focus: #000000;

    --dial-text-primary: rgba(0, 0, 0, 0.9);
    --dial-text-secondary: rgba(0, 0, 0, 0.55);
    --dial-text-tertiary: rgba(0, 0, 0, 0.35);

    --dial-border: rgba(0, 0, 0, 0.1);
    --dial-border-hover: rgba(0, 0, 0, 0.15);
    --dial-focus-ring: rgba(0, 0, 0, 0.55);

    --dial-timeline-clip-overlay: rgba(0, 0, 0, 0.28);

    --dial-glass-bg: #fafafa;
    --dial-dropdown-bg: #ffffff;
    --dial-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    --dial-shadow-collapsed: 0 2px 10px rgba(0, 0, 0, 0.06);
    --dial-shadow-dropdown: 0 4px 16px rgba(0, 0, 0, 0.08);
  }

  .dialkit-root[data-theme="system"] .dialkit-spring-viz line {
    stroke: rgba(0, 0, 0, 0.08);
  }

  .dialkit-root[data-theme="system"] .dialkit-spring-viz line[stroke-dasharray] {
    stroke: rgba(0, 0, 0, 0.15);
  }

  .dialkit-root[data-theme="system"] .dialkit-spring-viz path {
    stroke: rgba(0, 0, 0, 0.5);
  }

  .dialkit-root[data-theme="system"] .dialkit-toggle-thumb {
    box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.06), 0 1px 2px rgba(0, 0, 0, 0.08);
  }

}

/* ── Timeline dock ── */
.dialkit-timeline {
  position: fixed;
  left: 12px;
  right: 12px;
  bottom: 12px;
  z-index: 9998;
}

.dialkit-timeline[hidden] {
  display: none;
}

.dialkit-timeline-dock {
  position: relative;
  box-sizing: border-box;
  background: var(--dial-glass-bg);
  border: 1px solid var(--dial-border);
  border-radius: 14px;
  backdrop-filter: blur(var(--dial-backdrop-blur));
  -webkit-backdrop-filter: blur(var(--dial-backdrop-blur));
  padding: 0 12px 10px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  overflow-x: hidden;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  scrollbar-color: var(--dial-text-tertiary) transparent;
}

.dialkit-timeline-resize-handle {
  position: absolute;
  top: -4px;
  left: 0;
  right: 0;
  z-index: 9;
  height: 10px;
  cursor: ns-resize;
  touch-action: none;
}

.dialkit-timeline-dock::-webkit-scrollbar {
  width: 8px;
}

.dialkit-timeline-dock::-webkit-scrollbar-track {
  background: transparent;
}

.dialkit-timeline-dock::-webkit-scrollbar-thumb {
  border-radius: 999px;
  background: var(--dial-text-tertiary);
}

.dialkit-timeline-section {
  --dial-timeline-label-w: 96px;
  --dial-timeline-actions-w: 284px;
  --dial-timeline-header-h: calc(var(--dial-row-height) + 4px);
}

.dialkit-timeline-section + .dialkit-timeline-section {
  border-top: 1px solid var(--dial-border);
  padding-top: 10px;
}

.dialkit-timeline-header {
  display: grid;
  grid-template-columns: auto minmax(100px, 1fr) auto;
  align-items: center;
  gap: 12px;
  position: sticky;
  top: 0;
  z-index: 7;
  box-sizing: border-box;
  height: var(--dial-timeline-header-h);
  padding: 4px 0 0;
  margin: 0;
  background: var(--dial-glass-bg);
  backdrop-filter: blur(var(--dial-backdrop-blur));
  -webkit-backdrop-filter: blur(var(--dial-backdrop-blur));
}

.dialkit-timeline-header[data-open] {
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 12px;
}

.dialkit-timeline-header:not([data-open]) {
  grid-template-columns: var(--dial-timeline-label-w) minmax(0, 1fr) auto;
  gap: 0;
}

.dialkit-timeline-header:not([data-open]) .dialkit-timeline-identity {
  width: var(--dial-timeline-label-w);
  box-sizing: border-box;
  padding-right: 10px;
  overflow: hidden;
}

.dialkit-timeline-header:not([data-open]) .dialkit-timeline-title {
  overflow: hidden;
  text-overflow: ellipsis;
}

.dialkit-timeline-header:not([data-open]) .dialkit-timeline-overview {
  margin-right: 12px;
}

.dialkit-timeline-identity {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 10px;
}

.dialkit-timeline-title {
  display: block;
  min-width: 0;
  font-size: 15px;
  font-weight: 600;
  color: var(--dial-text-root);
  letter-spacing: -0.01em;
  white-space: nowrap;
}

.dialkit-timeline-header[data-open] .dialkit-timeline-identity {
  width: 100%;
  overflow: hidden;
}

.dialkit-timeline-header[data-open] .dialkit-timeline-title {
  display: inline-block;
  flex: 0 1 auto;
  width: fit-content;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}

.dialkit-timeline-time {
  font-family: 'Geist Mono', ui-monospace, monospace;
  font-size: 13px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  color: var(--dial-text-label);
  white-space: nowrap;
}

.dialkit-timeline-overview {
  position: relative;
  min-width: 60px;
  height: 12px;
  border-radius: 999px;
  background: var(--dial-surface-subtle);
  overflow: hidden;
  cursor: col-resize;
  touch-action: none;
  user-select: none;
  -webkit-user-select: none;
}

.dialkit-timeline-overview-viewport {
  position: absolute;
  inset-block: 0;
  border-radius: inherit;
  pointer-events: none;
}

.dialkit-timeline-overview-viewport[data-zoomed] {
  background: color-mix(in srgb, var(--dial-text-tertiary) 18%, transparent);
  box-shadow: inset 0 0 0 1px var(--dial-border);
}

.dialkit-timeline-overview-progress {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 999px 0 0 999px;
  background: var(--dial-text-tertiary);
  opacity: 0.35;
  pointer-events: none;
}

.dialkit-timeline-overview-playhead {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 2px;
  border-radius: 2px;
  background: var(--dial-text-root);
  transform: translateX(-1px);
  pointer-events: none;
}

.dialkit-timeline-actions {
  display: flex;
  align-items: center;
  gap: 6px;
}

.dialkit-timeline-header[data-open] .dialkit-timeline-actions {
  width: auto;
  box-sizing: border-box;
  justify-content: flex-end;
  padding-left: 0;
}

.dialkit-timeline-actions .dialkit-preset-manager {
  flex: 0 0 120px;
  width: 120px;
}

.dialkit-timeline-chevron {
  background: none;
  border: none;
  width: 20px;
  height: var(--dial-row-height);
  padding: 2px;
  cursor: pointer;
  color: var(--dial-text-label);
  opacity: 0.6;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: opacity 0.15s;
}

.dialkit-timeline-chevron:hover {
  opacity: 1;
}

.dialkit-timeline-chevron svg {
  width: 16px;
  height: 16px;
  transition: transform 0.18s ease;
}

.dialkit-timeline-chevron[data-open="true"] svg {
  transform: rotate(180deg);
}

.dialkit-timeline-body {
  margin-top: 0;
  overflow: visible;
}

.dialkit-timeline-scroll-row {
  position: sticky;
  bottom: -10px;
  z-index: 6;
  display: grid;
  grid-template-columns: var(--dial-timeline-label-w) minmax(0, 1fr);
  margin-top: 6px;
  margin-bottom: -10px;
  padding: 4px 0 10px;
  background: var(--dial-glass-bg);
  backdrop-filter: blur(var(--dial-backdrop-blur));
  -webkit-backdrop-filter: blur(var(--dial-backdrop-blur));
}

.dialkit-timeline-horizontal-scroll {
  min-width: 0;
  height: 10px;
  overflow-x: auto;
  overflow-y: hidden;
  scrollbar-width: thin;
  scrollbar-color: var(--dial-text-tertiary) transparent;
  overscroll-behavior-x: contain;
}

.dialkit-timeline-horizontal-scroll > div {
  height: 1px;
}

.dialkit-timeline-horizontal-scroll::-webkit-scrollbar {
  height: 8px;
}

.dialkit-timeline-horizontal-scroll::-webkit-scrollbar-track {
  background: transparent;
}

.dialkit-timeline-horizontal-scroll::-webkit-scrollbar-thumb {
  border-radius: 999px;
  background: var(--dial-text-tertiary);
}

.dialkit-timeline-grid {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.dialkit-timeline-row {
  display: grid;
  grid-template-columns: var(--dial-timeline-label-w) minmax(0, 1fr);
  align-items: stretch;
}

.dialkit-timeline-label {
  flex: 0 0 var(--dial-timeline-label-w);
  box-sizing: border-box; /* indent padding must not widen the column — every lane starts at the same x */
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  font-weight: 500;
  color: var(--dial-text-label);
  padding-right: 10px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  user-select: none;
  -webkit-user-select: none;
}

.dialkit-timeline-ruler {
  position: relative;
  min-width: 0;
  height: 28px;
  cursor: col-resize;
  touch-action: none;
  overflow: visible;
  user-select: none;
  -webkit-user-select: none;
  z-index: 5;
}

.dialkit-timeline-ruler-row {
  position: sticky;
  top: var(--dial-timeline-header-h);
  z-index: 6;
  height: 28px;
  background: var(--dial-glass-bg);
  backdrop-filter: blur(var(--dial-backdrop-blur));
  -webkit-backdrop-filter: blur(var(--dial-backdrop-blur));
}

.dialkit-timeline-tick {
  position: absolute;
  top: 50%;
  width: 1px;
  height: 100%;
  background: var(--dial-text-tertiary);
  transform: translateY(-50%);
  pointer-events: none;
}

.dialkit-timeline-tick-medium {
  height: 16px;
  background: var(--dial-border-hover);
}

.dialkit-timeline-tick-fine {
  height: 8px;
  background: var(--dial-border);
}

.dialkit-timeline-tick-label {
  position: absolute;
  top: 50%;
  left: 4px;
  display: flex;
  align-items: center;
  height: 18px;
  transform: translateY(-50%);
  font-family: 'Geist Mono', ui-monospace, monospace;
  font-size: 9.5px;
  line-height: 18px;
  font-variant-numeric: tabular-nums;
  color: var(--dial-text-tertiary);
  white-space: nowrap;
}

.dialkit-timeline-row {
  height: 28px;
}

/* ── Layer groups ── */

.dialkit-timeline-group-row {
  height: 22px;
}

.dialkit-timeline-group-row .dialkit-timeline-label {
  gap: 4px;
  font-weight: 600;
  color: var(--dial-text-root);
}

.dialkit-timeline-group-row .dialkit-timeline-lane {
  background: none;
}

.dialkit-timeline-group-toggle {
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: none;
  padding: 0;
  margin-left: -2px;
  cursor: pointer;
  color: var(--dial-text-tertiary);
}

.dialkit-timeline-group-toggle svg {
  width: 10px;
  height: 10px;
  transform: rotate(-90deg);
  transition: transform 0.15s ease;
}

.dialkit-timeline-group-toggle[data-open="true"] svg {
  transform: rotate(0deg);
}

.dialkit-timeline-row[data-grouped] .dialkit-timeline-label {
  padding-left: 14px;
}

.dialkit-timeline-lane {
  position: relative;
  flex: 1;
  background: var(--dial-surface-subtle);
  border-radius: 8px;
  overflow: hidden;
}

.dialkit-timeline-clip {
  position: absolute;
  top: 3px;
  bottom: 3px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding: 0 9px;
  cursor: grab;
  user-select: none;
  -webkit-user-select: none;
  touch-action: none;
  box-sizing: border-box;
  overflow: hidden;
  z-index: 1;
  box-shadow: inset 0 0 0 999px var(--dial-timeline-clip-overlay);
}

.dialkit-timeline-clip-ghost {
  position: absolute;
  top: 4px;
  bottom: 4px;
  display: flex;
  border-radius: 5px;
  box-sizing: border-box;
  overflow: hidden;
  opacity: 0.18;
  pointer-events: none;
  user-select: none;
  -webkit-user-select: none;
}

.dialkit-timeline-clip-ghost-segment {
  height: 100%;
  flex-shrink: 0;
  box-sizing: border-box;
}

.dialkit-timeline-clip-ghost-segment + .dialkit-timeline-clip-ghost-segment {
  box-shadow: inset 1px 0 0 rgba(0, 0, 0, 0.5);
}

.dialkit-timeline-loop-infinity {
  position: absolute;
  top: 50%;
  right: 7px;
  z-index: 2;
  color: var(--dial-text-tertiary);
  font-family: 'Geist Mono', ui-monospace, monospace;
  font-size: 13px;
  font-weight: 600;
  line-height: 1;
  transform: translateY(-50%);
  pointer-events: none;
  user-select: none;
  -webkit-user-select: none;
}

.dialkit-timeline-clip[data-dragging] {
  cursor: grabbing;
}

.dialkit-timeline-clip[data-selected] {
  box-shadow:
    0 0 0 2px var(--dial-text-root),
    inset 0 0 0 999px var(--dial-timeline-clip-overlay);
}

.dialkit-timeline-clip-duration {
  font-family: 'Geist Mono', ui-monospace, monospace;
  font-size: 9.5px;
  font-variant-numeric: tabular-nums;
  color: rgba(0, 0, 0, 0.55);
  white-space: nowrap;
  pointer-events: none;
}

/* ── Sequence segments ──
   A steps clip is one bar sliced into legs; boundaries between legs are
   drag handles that retime the leg to their left. */

.dialkit-timeline-clip[data-steps] {
  padding: 0;
  justify-content: flex-start;
}

.dialkit-timeline-clip-segment {
  position: relative;
  height: 100%;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding: 0 8px;
  box-sizing: border-box;
  overflow: hidden;
}

.dialkit-timeline-clip-segment + .dialkit-timeline-clip-segment {
  box-shadow: inset 1.5px 0 0 rgba(0, 0, 0, 0.25);
}

.dialkit-timeline-clip-segment:hover {
  background: rgba(0, 0, 0, 0.06);
}

.dialkit-timeline-clip-segment[data-selected] {
  background: rgba(0, 0, 0, 0.12);
}

/* ── Property tracks ──
   A props clip's row is a read-only composite — click to expand. Each
   property expands into a full track row: a complete clip bar whose
   position is the track's delay. */

.dialkit-timeline-clip[data-composite] {
  cursor: pointer;
}

.dialkit-timeline-track-row .dialkit-timeline-label {
  font-size: 13px;
  color: var(--dial-text-tertiary);
  padding-left: 26px;
}

.dialkit-timeline-track-row[data-grouped] .dialkit-timeline-label {
  padding-left: 32px;
}

.dialkit-timeline-clip-handle {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 8px;
  cursor: ew-resize;
}

.dialkit-timeline-clip-handle[data-edge="start"] {
  left: 0;
}

.dialkit-timeline-clip-handle[data-edge="end"] {
  right: 0;
}

.dialkit-timeline-playhead-control {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 12px;
  margin-left: -6px;
  cursor: ew-resize;
  touch-action: none;
}

.dialkit-timeline-playhead-anchor {
  position: sticky;
  top: calc(var(--dial-timeline-header-h) + 14px);
  z-index: 8;
  width: 0;
  height: 0;
  margin-left: 6px;
}

.dialkit-timeline-playhead-anchor::before {
  content: '';
  position: absolute;
  top: 0;
  left: -1px;
  width: 2px;
  height: 15px;
  background: var(--dial-text-root);
  pointer-events: none;
}

.dialkit-timeline-playhead-flag {
  position: absolute;
  top: 0;
  left: calc(var(--dial-timeline-playhead-flag-offset, 0px) - 26px);
  z-index: 1;
  width: 52px;
  height: 18px;
  padding: 0 7px;
  box-sizing: border-box;
  border: 1px solid rgba(255, 255, 255, 0.75);
  border-radius: 6px;
  background: #f3f3f3;
  color: #414141;
  font-family: 'Geist Mono', ui-monospace, monospace;
  font-size: 9.5px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
  font-feature-settings: 'tnum' 1;
  line-height: 16px;
  text-align: center;
  white-space: nowrap;
  transform: translateY(-50%);
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.28);
  transition: top 0.12s ease;
}

.dialkit-timeline-playhead-stem {
  position: absolute;
  top: 27px;
  bottom: 0;
  left: 5px;
  z-index: 5;
  width: 2px;
  background: var(--dial-text-root);
  pointer-events: none;
}

/* ── Timeline clip popover ── */
.dialkit-timeline-popover {
  position: fixed;
  z-index: 10000;
  background: var(--dial-glass-bg);
  border: 1px solid var(--dial-border);
  border-radius: 14px;
  backdrop-filter: blur(var(--dial-backdrop-blur));
  -webkit-backdrop-filter: blur(var(--dial-backdrop-blur));
  box-shadow: var(--dial-shadow);
  padding: 10px 12px;
  box-sizing: border-box;
  max-height: 60vh;
  overflow-y: auto;
  scrollbar-width: none;
  -ms-overflow-style: none;
}

.dialkit-timeline-popover::-webkit-scrollbar {
  display: none;
}

.dialkit-timeline-popover-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 2px 2px 8px;
  margin-bottom: 6px;
  border-bottom: 1px solid var(--dial-border);
}

.dialkit-timeline-popover-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--dial-text-root);
  letter-spacing: -0.01em;
}

.dialkit-timeline-popover-close {
  width: 24px;
  height: 24px;
  margin-left: auto;
  padding: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: 6px;
  background: none;
  color: var(--dial-text-tertiary);
  cursor: pointer;
}

.dialkit-timeline-popover-close:hover {
  color: var(--dial-text-root);
  background: var(--dial-surface-hover);
}

.dialkit-timeline-popover-close svg {
  width: 14px;
  height: 14px;
}

.dialkit-timeline-popover-body {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.dialkit-timeline-popover-body > .dialkit-folder:first-child {
  margin-top: 0;
  border-top: none;
}

@media (max-width: 720px) {
  .dialkit-timeline-dock {
    padding: 0 10px 10px;
  }

  .dialkit-timeline-header {
    grid-template-columns: auto minmax(40px, 1fr) auto;
    gap: 8px;
  }

  .dialkit-timeline-section {
    --dial-timeline-label-w: 76px;
    --dial-timeline-actions-w: 270px;
  }

  .dialkit-timeline-identity {
    overflow: hidden;
    gap: 7px;
  }

  .dialkit-timeline-title {
    font-size: 13px;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .dialkit-timeline-time {
    font-size: 11px;
  }

  .dialkit-timeline-overview {
    height: 12px;
  }

  .dialkit-timeline-actions {
    min-width: 0;
  }

  .dialkit-timeline-actions .dialkit-preset-manager {
    flex-basis: 100px;
    width: 100px;
  }

  .dialkit-timeline-chevron {
    width: 26px;
    height: 28px;
    justify-content: center;
    padding: 0;
  }

  .dialkit-timeline-grid {
    min-width: 0;
  }
}

/* Keyboard focus stays inside each control so scrolling never clips its edge. */
.dialkit-root :where(button, input, textarea, [tabindex]):focus {
  outline: none;
}
.dialkit-root :where(button, [role="slider"], [role="button"], .dialkit-color-plane, .dialkit-pad-surface):focus-visible {
  outline: 2px solid var(--dial-focus-ring);
  outline-offset: -2px;
}
.dialkit-folder-header-top[role="button"] { border-radius: 5px; }
.dialkit-panel-inner[data-collapsed="true"] .dialkit-folder-header-top { border-radius: 50%; }
.dialkit-slider:focus-visible .dialkit-slider-value,
.dialkit-slider:focus-within .dialkit-slider-value { color: var(--dial-text-focus); }
.dialkit-slider:focus-visible .dialkit-slider-fill { background: var(--dial-border-hover); }
.dialkit-select-option:focus-visible { background: var(--dial-surface-hover); color: var(--dial-text-focus); }
.dialkit-root :where(.dialkit-slider-input, .dialkit-color-value, .dialkit-preset-input):focus-visible {
  box-shadow: inset 0 -1px var(--dial-focus-ring);
}
.dialkit-color-css-input:focus-visible { outline: none; }
.dialkit-shortcuts-dropdown { margin: 0; inset: auto; overflow-y: auto; }
@media (forced-colors: active) {
  .dialkit-root { --dial-focus-ring: Highlight; }
}

/* Primary panel copy action */
.dialkit-toolbar-primary {
  background: var(--dial-text-root);
  color: var(--dial-glass-bg);
}

.dialkit-toolbar-primary:hover {
  background: color-mix(in srgb, var(--dial-text-root) 88%, var(--dial-glass-bg));
}

.dialkit-toolbar-primary svg {
  color: inherit;
}

.dialkit-preset-check {
  width: 14px;
  height: 14px;
  flex-shrink: 0;
  color: var(--dial-text-focus);
}

.dialkit-preset-divider {
  height: 1px;
  margin: 4px 0;
  background: var(--dial-surface-subtle);
}

.dialkit-preset-create {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--dial-text-label);
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  text-align: left;
  cursor: pointer;
  transition: background 150ms;
}

.dialkit-preset-create:hover,
.dialkit-preset-create:focus-visible {
  background: var(--dial-surface-hover);
}
`;
