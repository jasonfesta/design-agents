// Core API
export { createDialKit, createDialKitController } from './createDialKit.svelte.js';
export type { CreateDialOptions, DialKitController, DialKitValues } from './createDialKit.svelte.js';

// Timeline
export { createDialTimeline } from './createDialTimeline.svelte.js';
export type { CreateDialTimelineOptions } from './createDialTimeline.svelte.js';
export type {
  DialTimelineValues,
  TimelineClipConfig,
  TimelineClipCss,
  TimelineClipLoop,
  TimelineClipValues,
  TimelineConfig,
  TimelineGroupConfig,
  TimelineGroupValues,
  TimelinePropConfig,
  TimelinePropStepConfig,
  TimelineStepConfig,
  TimelineStepValues,
} from 'dialkit/timeline';

// Root component
export { default as DialRoot } from './components/DialRoot.svelte';
export type { DialPosition, DialMode, DialTheme } from './components/DialRoot.svelte';

// Shortcut components
export { default as ShortcutListener } from './components/ShortcutListener.svelte';
export { SHORTCUT_CTX } from './components/ShortcutListener.svelte';
export type { ShortcutContextValue } from './components/ShortcutListener.svelte';
export { default as ShortcutsMenu } from './components/ShortcutsMenu.svelte';

// Component exports
export { default as Slider } from './components/Slider.svelte';
export { default as Toggle } from './components/Toggle.svelte';
export { default as Folder } from './components/Folder.svelte';
export { default as ButtonGroup } from './components/ButtonGroup.svelte';
export { default as SpringControl } from './components/SpringControl.svelte';
export { default as SpringVisualization } from './components/SpringVisualization.svelte';
export { default as TransitionControl } from './components/TransitionControl.svelte';
export { default as EasingVisualization } from './components/EasingVisualization.svelte';
export { default as TextControl } from './components/TextControl.svelte';
export { default as SelectControl } from './components/SelectControl.svelte';
export { default as ColorControl } from './components/ColorControl.svelte';
export { default as ImageControl } from './components/ImageControl.svelte';
export { default as DialPad } from './components/DialPad.svelte';
export type { DialPadProps } from '../dial-pad-control';
export { default as PresetManager } from './components/PresetManager.svelte';
export { default as DialTimeline } from './components/Timeline/DialTimeline.svelte';

// Store exports (via dialkit/store subpath — svelte-package doesn't bundle, so relative paths to src/store would break in dist)
export { DialStore } from 'dialkit/store';
export type {
  SpringConfig,
  EasingConfig,
  TransitionConfig,
  ActionConfig,
  SelectConfig,
  ColorConfig,
  ImageConfig,
  ImageOption,
  DialPadAxis,
  DialPadConfig,
  DialPadValue,
  TextConfig,
  ShortcutConfig,
  Preset,
  DialValue,
  DialConfig,
  DialKitPersistOptions,
  DialKitValueUpdates,
  ResolvedValues,
  ControlMeta,
  PanelConfig,
} from 'dialkit/store';
