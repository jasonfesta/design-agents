# Local tools

Local installations live here:

- `dialkit/`
- `screenshot-to-code/`
- `open-ai-design-agent/`
- `superdesign-skill/`

The parent GitHub repository includes this README, not the installed checkouts and dependencies. The personal [DialKit source archive](../resources/history/sources/dialkit-source.zip) preserves source, working files, attribution, and committed history. Extract it into an empty `tools/` folder when needed and read its `PERSONAL.md`.

[Setup records](../resources/tooling/local-tools.md) describe the other local installations. [MCP records](../mcps/README.md) describe server connections. These are local tools used by the kit, not additional current agent versions.
