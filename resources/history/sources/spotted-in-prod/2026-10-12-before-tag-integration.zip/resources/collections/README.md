# Source collections

Browse all destinations in the [master resource list](../catalogue.md). These files retain the detailed observations and source memberships behind that index.

- [Detailed resource records](source-records.md): 144 primary records, with source IDs, URLs, dates, review status, and licensing notes.
- [Reviewed references](reviewed.md): the research shortlist and Jason's source feedback.
- [Nero](nero.md): links and source posts from Nero's collection.
- [DesEngs](desengs/README.md): captured resources, website references, and public designer profiles.

Keep differing observations and original names attached to their source records. Update the relevant record and regenerate the master list; do not replace source evidence with a merged summary.
