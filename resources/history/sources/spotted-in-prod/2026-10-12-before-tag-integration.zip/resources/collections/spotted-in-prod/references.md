# Spotted in Prod app and style references

Captured October 12, 2026 · [Study](README.md) · [Source snapshot](../../history/sources/spotted-in-prod/2026-10-12-taxonomy.json)

## Source selected design language examples

The homepage associates each design-language tag with a representative editorial clip. These are source selections for study, not Jason’s endorsements or completed visual reviews. App-plus-activeClip URLs use the detail route observed in the browser.

| Language | App | Clip title | Source clip ID |
| --- | --- | --- | --- |
| System | [Bevel](https://www.spottedinprod.com/apps/bevel?activeClip=746) | App tour | `editorial:746` |
| Minimal | [Kurzgedacht](https://www.spottedinprod.com/apps/kurzgedacht?activeClip=797) | Onboarding | `editorial:797` |
| Skeuomorphism | [Focus Flight](https://www.spottedinprod.com/apps/focusflight?activeClip=561) | Book your flight | `editorial:561` |
| Colorful | [Phantom](https://www.spottedinprod.com/apps/phantom?activeClip=769) | Phantom cash | `editorial:769` |
| Monochrome | [222](https://www.spottedinprod.com/apps/twotwotwo?activeClip=743) | Curate my night | `editorial:743` |
| Collage | [Selleb](https://www.spottedinprod.com/apps/selleb?activeClip=421) | Tabs | `editorial:421` |
| Loud | [Yapster](https://www.spottedinprod.com/apps/yapster?activeClip=430) | Round results | `editorial:430` |
| Friendly | [Cusp](https://www.spottedinprod.com/apps/cusp?activeClip=723) | Constellation swipe | `editorial:723` |
| Silly | [grug](https://www.spottedinprod.com/apps/grug?activeClip=528) | Onboarding | `editorial:528` |
| Retro | [Retro MP3](https://www.spottedinprod.com/apps/retrompthree?activeClip=823) | Cover flow | `editorial:823` |
| Grayscale | [Dropset](https://www.spottedinprod.com/apps/dropset?activeClip=62) | RPE | `editorial:62` |
| Flat | [Coinbase](https://www.spottedinprod.com/apps/coinbase?activeClip=50) | Bottom pills | `editorial:50` |
| Typographic | [Sunflower](https://www.spottedinprod.com/apps/sunflower?activeClip=618) | Swipe | `editorial:618` |
| Cyberpunk | [Carbon](https://www.spottedinprod.com/apps/carbon?activeClip=39) | Launch screen | `editorial:39` |
| Dense UI | [Co–Star](https://www.spottedinprod.com/apps/costar?activeClip=494) | Chart | `editorial:494` |
| Pixel Art | [Stash](https://www.spottedinprod.com/apps/stash?activeClip=9) | Happy 4/20 | `editorial:9` |
| Warm | [Acme Weather](https://www.spottedinprod.com/apps/acmeweather?activeClip=782) | Onboarding | `editorial:782` |
| Brutalist | [Co–Star](https://www.spottedinprod.com/apps/costar?activeClip=855) | Know the signs | `editorial:855` |
| Geometric | [Endel](https://www.spottedinprod.com/apps/endel?activeClip=79) | Soundpad | `editorial:79` |
| Technical | [Are.na](https://www.spottedinprod.com/apps/arena?activeClip=713) | Rabbit holes | `editorial:713` |

## Homepage app inventory

These 100 app records came from the captured public homepage payload. The visible icon grid shows a shuffled subset depending on the view. This is not an exhaustive app directory. Counts are source metadata, not a tally of individually reviewed clips.

| App | Source app ID | Source slug | Clips |
| --- | --- | --- | ---: |
| [2006](https://www.spottedinprod.com/apps/2006cam) | 1 | `2006cam` | 4 |
| [222](https://www.spottedinprod.com/apps/twotwotwo) | 263 | `twotwotwo` | 10 |
| [[untitled]](https://www.spottedinprod.com/apps/untitled) | 82 | `untitled` | 5 |
| [Aave](https://www.spottedinprod.com/apps/aave) | 265 | `aave` | 8 |
| [Abode](https://www.spottedinprod.com/apps/abode) | 154 | `abode` | 10 |
| [Actions](https://www.spottedinprod.com/apps/actions) | 162 | `actions` | 7 |
| [Airbnb](https://www.spottedinprod.com/apps/airbnb) | 97 | `airbnb` | 12 |
| [AllTrails](https://www.spottedinprod.com/apps/alltrails) | 100 | `alltrails` | 5 |
| [Alma](https://www.spottedinprod.com/apps/alma) | 101 | `alma` | 4 |
| [Alyx](https://www.spottedinprod.com/apps/alyx) | 262 | `alyx` | 5 |
| [Amie](https://www.spottedinprod.com/apps/amie) | 102 | `amie` | 5 |
| [Andante](https://www.spottedinprod.com/apps/andante) | 103 | `andante` | 4 |
| [Arc Search](https://www.spottedinprod.com/apps/arcsearch) | 105 | `arcsearch` | 6 |
| [Are:na](https://www.spottedinprod.com/apps/arenatf) | 155 | `arenatf` | 7 |
| [Avec](https://www.spottedinprod.com/apps/avec) | 189 | `avec` | 8 |
| [Believe](https://www.spottedinprod.com/apps/believe) | 164 | `believe` | 7 |
| [Ben](https://www.spottedinprod.com/apps/ben) | 327 | `ben` | 1 |
| [Bevel](https://www.spottedinprod.com/apps/bevel) | 281 | `bevel` | 5 |
| [Bins](https://www.spottedinprod.com/apps/bins) | 260 | `bins` | 7 |
| [Binsoo](https://www.spottedinprod.com/apps/binsoo) | 106 | `binsoo` | 5 |
| [Blackbird](https://www.spottedinprod.com/apps/blackbird) | 107 | `blackbird` | 10 |
| [BlueNote](https://www.spottedinprod.com/apps/bluenote) | 195 | `bluenote` | 4 |
| [Bop](https://www.spottedinprod.com/apps/bop) | 269 | `bop` | 3 |
| [Bump](https://www.spottedinprod.com/apps/bump) | 108 | `bump` | 21 |
| [Capwords](https://www.spottedinprod.com/apps/capwords) | 199 | `capwords` | 4 |
| [Carbon](https://www.spottedinprod.com/apps/carbon) | 111 | `carbon` | 3 |
| [Cash App](https://www.spottedinprod.com/apps/cashapp) | 112 | `cashapp` | 6 |
| [Cassette](https://www.spottedinprod.com/apps/cassette) | 238 | `cassette` | 1 |
| [ChatGPT](https://www.spottedinprod.com/apps/chatgpt) | 114 | `chatgpt` | 10 |
| [Checker](https://www.spottedinprod.com/apps/checker) | 200 | `checker` | 4 |
| [Claude](https://www.spottedinprod.com/apps/claude) | 251 | `claude` | 4 |
| [Clocks](https://www.spottedinprod.com/apps/clocks) | 201 | `clocks` | 3 |
| [Cobot](https://www.spottedinprod.com/apps/cobot) | 243 | `cobot` | 4 |
| [corner](https://www.spottedinprod.com/apps/corner) | 116 | `corner` | 4 |
| [Cosmos](https://www.spottedinprod.com/apps/cosmos) | 117 | `cosmos` | 15 |
| [Co–Star](https://www.spottedinprod.com/apps/costar) | 118 | `costar` | 10 |
| [Craft](https://www.spottedinprod.com/apps/craft) | 120 | `craft` | 12 |
| [Creme](https://www.spottedinprod.com/apps/creme) | 216 | `creme` | 4 |
| [Deco](https://www.spottedinprod.com/apps/deco) | 122 | `deco` | 6 |
| [Ditto](https://www.spottedinprod.com/apps/ditto) | 286 | `ditto` | 5 |
| [Doji](https://www.spottedinprod.com/apps/doji) | 171 | `doji` | 6 |
| [Dot](https://www.spottedinprod.com/apps/dot) | 127 | `dot` | 4 |
| [Dropset](https://www.spottedinprod.com/apps/dropset) | 129 | `dropset` | 3 |
| [DS Clock](https://www.spottedinprod.com/apps/dsclock) | 157 | `dsclock` | 1 |
| [Family](https://www.spottedinprod.com/apps/family) | 135 | `family` | 13 |
| [Find your Faith](https://www.spottedinprod.com/apps/fyf) | 233 | `fyf` | 4 |
| [Focus Flight](https://www.spottedinprod.com/apps/focusflight) | 244 | `focusflight` | 9 |
| [FotMob](https://www.spottedinprod.com/apps/fotmob) | 141 | `fotmob` | 10 |
| [Genie](https://www.spottedinprod.com/apps/genie) | 275 | `genie` | 5 |
| [Gentler Streak](https://www.spottedinprod.com/apps/gentlerstreak) | 258 | `gentlerstreak` | 2 |
| [GitHub](https://www.spottedinprod.com/apps/github) | 173 | `github` | 5 |
| [GO Club](https://www.spottedinprod.com/apps/goclub) | 143 | `goclub` | 3 |
| [GOAT](https://www.spottedinprod.com/apps/goat) | 144 | `goat` | 11 |
| [Grok](https://www.spottedinprod.com/apps/grok) | 147 | `grok` | 3 |
| [grug](https://www.spottedinprod.com/apps/grug) | 242 | `grug` | 4 |
| [How We Feel](https://www.spottedinprod.com/apps/howwefeel) | 151 | `howwefeel` | 1 |
| [Interlude](https://www.spottedinprod.com/apps/interlude) | 331 | `interlude` | 1 |
| [Introspect](https://www.spottedinprod.com/apps/introspect) | 323 | `introspect` | 5 |
| [Ivy](https://www.spottedinprod.com/apps/ivy) | 223 | `ivy` | 6 |
| [Lost Post](https://www.spottedinprod.com/apps/lostpost) | 304 | `lostpost` | 1 |
| [Luma](https://www.spottedinprod.com/apps/luma) | 7 | `luma` | 7 |
| [Lumy](https://www.spottedinprod.com/apps/lumy) | 192 | `lumy` | 8 |
| [Mercury](https://www.spottedinprod.com/apps/mercury) | 9 | `mercury` | 11 |
| [Miles](https://www.spottedinprod.com/apps/miles) | 10 | `miles` | 3 |
| [MIST](https://www.spottedinprod.com/apps/mist) | 11 | `mist` | 5 |
| [Moods Faster](https://www.spottedinprod.com/apps/moodsfaster) | 324 | `moodsfaster` | 2 |
| [Numbies](https://www.spottedinprod.com/apps/numbies) | 19 | `numbies` | 4 |
| [Opal](https://www.spottedinprod.com/apps/opal) | 23 | `opal` | 2 |
| [Ora](https://www.spottedinprod.com/apps/ora) | 26 | `ora` | 3 |
| [Particle](https://www.spottedinprod.com/apps/particle) | 28 | `particle` | 7 |
| [Perplexity](https://www.spottedinprod.com/apps/perplexity) | 30 | `perplexity` | 6 |
| [Phantom](https://www.spottedinprod.com/apps/phantom) | 32 | `phantom` | 4 |
| [Photo Restore](https://www.spottedinprod.com/apps/photorestore) | 222 | `photorestore` | 5 |
| [Placify](https://www.spottedinprod.com/apps/placify) | 35 | `placify` | 2 |
| [Polymarket](https://www.spottedinprod.com/apps/polymarket) | 288 | `polymarket` | 2 |
| [Pool](https://www.spottedinprod.com/apps/pool) | 290 | `pool` | 3 |
| [Poolsuite FM](https://www.spottedinprod.com/apps/poolsuite) | 39 | `poolsuite` | 4 |
| [Posts](https://www.spottedinprod.com/apps/posts) | 40 | `posts` | 5 |
| [Raycast](https://www.spottedinprod.com/apps/raycast) | 204 | `raycast` | 4 |
| [Remind Me Faster](https://www.spottedinprod.com/apps/remindmefaster) | 194 | `remindmefaster` | 3 |
| [Retro](https://www.spottedinprod.com/apps/retro) | 47 | `retro` | 16 |
| [Robinhood](https://www.spottedinprod.com/apps/robinhood) | 50 | `robinhood` | 13 |
| [Roze](https://www.spottedinprod.com/apps/roze) | 53 | `roze` | 2 |
| [Run Receipt](https://www.spottedinprod.com/apps/runreceipt) | 325 | `runreceipt` | 1 |
| [Schema](https://www.spottedinprod.com/apps/schema) | 206 | `schema` | 2 |
| [Shop](https://www.spottedinprod.com/apps/shop) | 57 | `shop` | 5 |
| [Showcase](https://www.spottedinprod.com/apps/showcase) | 221 | `showcase` | 4 |
| [Sonder](https://www.spottedinprod.com/apps/sonder) | 315 | `sonder` | 1 |
| [Spark](https://www.spottedinprod.com/apps/spark) | 292 | `spark` | 2 |
| [Stupido](https://www.spottedinprod.com/apps/stupido) | 226 | `stupido` | 2 |
| [Sudoku](https://www.spottedinprod.com/apps/sudoku) | 69 | `sudoku` | 10 |
| [Supersonic Run](https://www.spottedinprod.com/apps/supersonic) | 218 | `supersonic` | 4 |
| [Things](https://www.spottedinprod.com/apps/things) | 75 | `things` | 9 |
| [Timepage](https://www.spottedinprod.com/apps/timepage) | 77 | `timepage` | 2 |
| [Trackables](https://www.spottedinprod.com/apps/trackables) | 328 | `trackables` | 1 |
| [Tripsy](https://www.spottedinprod.com/apps/tripsy) | 198 | `tripsy` | 1 |
| [Vinyls](https://www.spottedinprod.com/apps/vinyls) | 225 | `vinyls` | 3 |
| [Wabi](https://www.spottedinprod.com/apps/wabi) | 287 | `wabi` | 1 |
| [Waymo](https://www.spottedinprod.com/apps/waymo) | 89 | `waymo` | 2 |
| [Yapster](https://www.spottedinprod.com/apps/yapster) | 94 | `yapster` | 7 |
