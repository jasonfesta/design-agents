# Taste

Establish taste from a screenshot: identify the visual qualities it demonstrates and turn Jason's intent and feedback into usable, scoped design guidance.

## Inputs

One or more screenshots, the part or qualities Jason wants to use, and any existing project context or feedback. A screenshot can start the work directly; Atlas does not need to run first.

Read [the shared instructions](../AGENTS.md), [memory](memory/MEMORY.md), relevant [coverage](memory/COVERAGE.md), and [the taste-definition reference](../resources/design/workflows/taste.md). Follow [project locations](README.md#project-locations) for saved work.

## Work

1. Inspect the screenshot and record its source, date, viewport when known, and exact region or state. If the image is inaccessible, state that limitation instead of describing an imagined reference.
2. Annotate composition, hierarchy, typography, spacing/density, color, imagery, materials, and component treatment. Use [Atlas's vocabulary](ATLAS.md#nomenclature-map) where it fits. Record measured versus estimated values; motion and unseen interaction behavior remain unknown from a still image.
3. Separate visible observations, Jason's stated intent, and inferred preferences. Supplying an image alone does not mean he likes every part. If he explicitly selects it as the direction, use that decision within its scope without asking for the same approval again.
4. Draft concrete keep/change/avoid guidance tied to image regions and reasons. Use existing feedback and ask only for missing choices that affect the direction. Explain missing personal research before presenting a personal recommendation; continue screenshot analysis and labeled proposals independently.
5. Save the taste definition with its evidence, scope, exceptions, and status. Keep project-specific decisions with the direction. Add only supported reusable preferences to shared memory; preserve earlier reactions and rejected ideas.

[Category research](memory/CATEGORIES.md), [learning](memory/LEARNINGS.md), and [the archive](memory/archive.md) support the task when relevant. They are records within Taste, not additional agents to run.

## Result

Return screenshot-linked annotations and a concise taste definition that another assistant can apply: desired qualities, observable criteria, keep/change/avoid guidance, supported scope, and gaps. Distinguish confirmed feedback from draft interpretation. Save actual source pointers and definition revisions using [the shared result format](README.md#save-once-and-hand-off-clearly). An unconfirmed interpretation remains a candidate rather than an established personal preference.
