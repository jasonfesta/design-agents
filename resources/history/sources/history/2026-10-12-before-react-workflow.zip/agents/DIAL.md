# Dial

Establish editable components from a screenshot, connect their controls, and save the exact tuned versions.

**Screenshot → editable component → DialKit controls → saved variant → application.**

## Inputs

A screenshot or an existing screenshot-derived component, target viewport, project/direction paths, requested stage, and available implementation tools. Use existing taste guidance when applicable; a prior Taste or Atlas run is not required to reproduce a supplied image.

Read [the shared instructions](../AGENTS.md), the destination's README and `AGENTS.md`, and [project locations](README.md#project-locations). Read the relevant craft skill before implementation. Check personal taste coverage before making taste-based changes.

## Work

Run the requested stages. Preserve completed stages when continuing an existing component.

1. Read the selected image and target constraints. Follow [the component workflow](../resources/design/workflows/components.md), including its [shared vocabulary and structures](../resources/design/workflows/components.md#shared-component-vocabulary-for-dial). Load the complete design-language, visual, gesture, flow, and pattern lists from their canonical links; use relevant labels and exclude product-domain categories from Dial.
2. Break the screenshot into component boundaries, anatomy, visual layers, and visible states. Record gestures, flows, and other behavior as observed or inferred. Reproduce the target in editable code, render at the target viewport, compare with the screenshot, and record fidelity gaps or missing assets.
3. Bind DialKit to that same code with matching initial values. Adding controls must preserve the reconstructed appearance. The agent interprets the screenshot and generates code; DialKit provides the controls.
4. Interpret requested changes as explicit value or code edits and inspect the result. Keep source reconstruction and tuned alternatives independent.
5. Save each variant's code revision, exact values, five source-label groups, anatomy, sources, states, and usage rules. Team type remains optional provenance outside tuning controls. Verify saved values reproduce the variant when reloaded.
6. Apply the pinned variant to the intended design when requested and verify appearance and behavior. Record the generated item, date/time zone, code and direction paths, reference, variant revision, and completed checks in the direction's README so Dream can find the day's work.

Use the project's implementation paths for product code and its direction for selected reference assets and component/variant records. Link reusable source descriptions from Resources. Keep shared code canonical and each variant's values independent.

The full workbench is not implemented yet. [Local tools](../resources/tooling/local-tools.md#dialkit) records DialKit availability, and [the root README](../README.md) explains its preserved source. Use [application guidance](../resources/design/workflows/apply.md) for relevant integration checks.

## Result

Return editable components, actual code/asset paths, source reconstruction and variant revisions, exact control values, applicable source labels, and visual/behavior checks. State which stages ran and what remains unverified. Keep the day's output record current even when only reproduction or tuning was requested. Use [the shared result format](README.md#save-once-and-hand-off-clearly).
