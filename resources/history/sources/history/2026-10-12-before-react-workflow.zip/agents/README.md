# Using the design kit

[Setup](SETUP.md) prepares the kit after you grab it. **Atlas, Taste, Dial, and Dream** are independent work roles. Start with whichever one fits the task; none requires another role to run first.

```text
agents/
  SETUP.md      Prepare a cloned or copied kit
  ATLAS.md      Nomenclature across apps, websites, and games
  TASTE.md      Taste from screenshots
  DIAL.md       Components from screenshots; controls and variants
  DREAM.md      Nightly three-hour cleanup using Taste and Dial
  memory/       Shared taste evidence and coverage
```

## Prepare the kit

Copy the complete kit, including hidden `.agents/skills/`, and keep its relative paths intact. Open it in your IDE and say:

> Read `<kit-path>/agents/SETUP.md` and prepare this kit for use here.

Setup checks the supplied folders and instructions. Run it again after a transfer when needed. Resources, MCP records, and supporting references travel with the kit; account connections and machine-local installations need to be checked separately.

## Use any role

Replace the paths, role, and request below. Explicit file loading works even when the IDE does not discover instructions automatically.

```text
Read <kit-path>/AGENTS.md, <kit-path>/agents/README.md,
and <kit-path>/agents/<ATLAS|TASTE|DIAL|DREAM>.md.
Use that role for: <request>.
Project, if applicable: <existing project path or new project description>.
Read the role's required references and the destination's instructions.
Follow the shared project-location rules before creating project files.
```

Load only the chosen role and the references its task needs. If moving a role outside the kit, include its linked context and assets with attribution; an isolated Markdown file cannot supply missing evidence. Each role has the same **Inputs → Work → Result** structure for later conversion into a skill. For now, these are portable instructions; native skill registration and background execution are not part of this package.

| Role | Use it for | Result |
| --- | --- | --- |
| [Atlas](ATLAS.md) | Own nomenclature for directions across apps, websites, and games | Names, definitions, mappings, source evidence, and gaps |
| [Taste](TASTE.md) | Establish taste from screenshots and your feedback | Annotated visual qualities and a scoped taste definition |
| [Dial](DIAL.md) | Establish components from screenshots, tune controls, and save variants | Editable components, exact versions, and visual checks |
| [Dream](DREAM.md) | Clean up the day's work during a nightly three-hour window, using Taste and Dial | Verified revisions, a morning report, and unfinished work to carry forward |

A screenshot can go straight to Taste or Dial, depending on the task. Atlas maintains the shared vocabulary. Dream reads the day's saved work and decisions without requiring the other roles to run again. Use available evidence directly and report missing context when it affects the task.

## Project locations

These rules apply to all four roles, independently of Setup.

1. **One new build chat owns one app, website, or game.** Continue its project on follow-up messages. Explicit shared research, kit maintenance, or a request to resume an existing project keeps its stated scope.
2. **Ask where to save a new project or direction unless the destination is already supplied.** Confirm its absolute path and inspect existing instructions before writing. A suggested path or silence is not an answer; read-only work can continue while waiting. Never silently use this kit or another chat's project as the output folder.
3. Create only the selected design layers, with one README per created layer. Use the [type and category menus](../resources/design/categories/README.md), [viewport profiles](../resources/design/viewports/README.md), and [styles](../resources/styles/README.md). Leave unknown choices in the project record instead of creating placeholder branches. Exact dimensions, motion, tools, and screen details are fields inside the record.
4. Add a **Design project** section to the project's README: name/type, owning chat when known, implementation and asset locations, direction path, references/variants, current state, and unresolved choices. Store paths relative to the confirmed project root so it can move. Follow the stack's normal code layout.
5. Add a **Design file routing** section to the project's `AGENTS.md`, preserving existing rules. Point to the README's actual paths; instruct the IDE to save product code in implementation locations and design notes/assets/variants in the direction. Explicitly load both files in IDEs without instruction discovery. Use an explicit command working directory and resolved file destinations.

```text
<chosen-project>/
  README.md                         Project and actual file destinations
  AGENTS.md                         Instructions to use those destinations
  <implementation folders>/        Code and assets for the chosen stack
  <apps|websites|games>/<viewport>/<category>/<style>/
    README.md                       Direction, references, decisions, state
    references/                     Selected assets, when needed
    components/                     Components and variants, when needed
```

Angle brackets are placeholders. Use lowercase folders for our records, retaining required stack conventions. Keep independent named variants when two directions share a style. Reuse saved destinations for follow-up edits; switching roles does not create a new project. Ask again for a new project, direction, or relocation. Each project owns its paths; there is no shared active-project pointer. Instructions guide the assistant and do not change IDE permissions automatically.

## Save once and hand off clearly

Keep project decisions in the direction's README, selected research with the project, reusable source descriptions in Resources, and supported reusable preferences in Taste memory. Link component records and versions from the direction instead of creating a new report for every role switch. For generated work, record the date/time zone, item ID and paths, reference, component/variant revisions, and checks. Dream uses these entries to review the whole day within the project scope.

Return the actual project/direction paths, source or version IDs, saved work, decisions versus proposals, checks performed, unresolved gaps, and next action. No handoff is required to finish a self-contained task. If file writes or visual checks are unavailable, state what remains unsaved or unverified.

The [master resource list](../resources/catalogue.md) owns navigation. [MCPs](../mcps/README.md), [local tools](../tools/README.md), and [agent resources](../resources/agents/README.md) supply supporting records. [History](../resources/history/README.md) preserves prior versions. The full image-to-component workbench still needs implementation; Dream's [nightly operating design](../resources/design/workflows/dream.md) specifies the three-hour window; scheduling and its execution host are not configured.
