# websites

Within the project folder chosen using [the shared location rules](../agents/README.md#project-locations), save design records as `websites/<viewport>/<category>/<style>/`. Product code uses the project's recorded implementation locations. Each created design layer has one README; create folders when needed.

- **Viewports:** mobile, tablet, desktop. Use [viewport profiles](../resources/design/viewports/README.md) and record the actual dimensions, units, input, and support.
- **Categories:** [18 website uses](../resources/design/categories/WEBSITE-CATEGORIES.md).
- **Styles:** [websites styles](../resources/styles/websites.md), with [motion](../resources/motion/techniques.md) described inside the style record.
- **References:** [Resources](../resources/README.md).
- **Preferences:** [Taste memory and coverage](../agents/memory/MEMORY.md); no branch-specific personal style is defined yet.

A branch README records the task, references, supported feedback, current state, and next action. Components, variants, and supporting assets live with the actual style work. Use [the style template](../resources/styles/template.md) when useful.

Earlier viewport/category placeholders are preserved in [History](../resources/history/README.md). Their existence did not establish research or compatibility. [Atlas](../agents/ATLAS.md) owns the nomenclature, [Taste](../agents/TASTE.md) establishes taste from screenshots, [Dial](../agents/DIAL.md) builds components from screenshots, and [Dream](../agents/DREAM.md) checks the day's generated work.
