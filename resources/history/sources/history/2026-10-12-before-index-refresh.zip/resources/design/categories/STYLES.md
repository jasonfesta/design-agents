# Style matching

Layer 4 is **style**. Use the separate proposed lists for [apps](../../styles/apps.md), [websites](../../styles/websites.md), and [games](../../styles/games.md).

[The style contract](../../styles/README.md) owns fit, naming, and record rules. The [style template](../../styles/template.md) is used for an actual style folder. The [earlier vocabulary](../../history/style-vocabulary.md) preserves historical IDs and family/treatment definitions.

Style lists are organizing proposals. Each branch stays unfilled until real exploration or evidence supports a match. Run [TASTE.md](../workflows/taste.md) before claiming a style as Jason's preference. A DialKit-tuned component variant belongs to a style through an explicit mapping and verification, as described in [COMPONENTS.md](../workflows/components.md).

## Working style vocabulary

Use the type-specific files linked above. The [preferred-name registry](../../styles/README.md) separates aesthetic terms and aliases; the [motion vocabulary](../../motion/techniques.md) supplies named techniques, timing concepts, and tool distinctions. Store these as fields within the style record. Do not copy every style into every category.
