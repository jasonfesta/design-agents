# Chrome viewport starting points

Verified October 12, 2026 · Browser profiles for websites and browser-based apps/games

Chrome DevTools documents these responsive width presets in CSS pixels. Heights are adjustable, so a width preset is not a complete screenshot size. Device Mode approximates a device; it does not verify native execution. [Chrome Device Mode documentation](https://developer.chrome.com/docs/devtools/device-mode)

| Profile ID | Chrome label | Width in CSS px | Our viewport folder |
| --- | --- | --- | --- |
| chrome-mobile-s | Mobile S | 320 | mobile |
| chrome-mobile-m | Mobile M | 375 | mobile |
| chrome-mobile-l | Mobile L | 425 | mobile |
| chrome-tablet | Tablet | 768 | tablet |
| chrome-laptop | Laptop | 1024 | desktop |
| chrome-laptop-l | Laptop L | 1440 | desktop |
| chrome-wide | 4K | 2560 | desktop |

“4K” above is Chrome's preset label; its viewport width is 2560 CSS px. Do not substitute a 3840px physical display width. Our folder assignments are local conventions, not device detection rules.

## Device-sized reference profiles

These portrait dimensions and DPR values were inspected in the [Chromium DevTools preset source](https://github.com/ChromeDevTools/devtools-frontend/blob/main/front_end/models/emulation/EmulatedDevices.ts). Source main can change; record the actual browser preset when using it. Only factual preset data is retained here; no upstream implementation is copied.

| Profile | Width × height in CSS px | DPR | Viewport folder |
| --- | --- | --- | --- |
| iPhone SE | 375 × 667 | 2 | mobile |
| iPhone 12 Pro | 390 × 844 | 3 | mobile |
| Pixel 7 | 412 × 915 | 2.625 | mobile |
| Samsung Galaxy A55 | 360 × 800 | 2.25 | mobile |
| iPad Mini | 768 × 1024 | 2 | tablet |
| iPad Pro 13 | 1032 × 1376 | 2 | tablet |
| Surface Pro 10 | 960 × 1440 | 2 | tablet |

For a reproducible comparison, save orientation, input mode, safe-area behavior, and the exact observed viewport. Device presets can include cutouts and insets; the width/height pair alone is not the full emulation configuration. Rotated references are separate profiles of the same viewport folder.

## Project-specific desktop profiles

Choose the actual window height from the design or test target and record it. A project may adopt 1440 × 900 CSS px as a working canvas, for example; that height would be our project choice, not a Chrome standard. Avoid one fixed artboard becoming a rule for every browser size.
