# History

Past material is preserved here. These are historical records, not additional current agent instructions. Start active work with [the current kit and work roles](../../agents/README.md).

| Material | Location |
| --- | --- |
| Corner clip before the circular anchor and horizontal menu | [Original component, styles, and records](sources/history/2026-10-13-before-circular-jig.zip) |
| Chrome reference before the complete preset capture | [Original viewport documents and hashes](sources/history/2026-10-13-before-complete-chrome-profiles.zip) |
| Complete pinned DevTools viewport source and license | [October 13 capture](sources/chrome/2026-10-13/README.md) |
| Instructions and framed jig before Benchmark and the corner-overlay revision | [Original documents, prototype sources, and hashes](sources/history/2026-10-13-before-benchmark-and-jig.zip) |
| Instructions before regrouping related efforts and clarifying Taste-to-Dial ownership | [Original documents and hashes](sources/history/2026-10-13-before-effort-regroup.zip) |
| Role instructions before the Atlas library and Taste dialogue correction | [Original documents and hashes](sources/history/2026-10-13-before-atlas-library-correction.zip) |
| Setup and export naming before the portable Jason workspace | [Original nine files and hashes](sources/history/2026-10-13-before-jason-setup.zip) |
| Setup before the standalone GitHub installation entry | [Original eight documents and hashes](sources/history/2026-10-12-before-github-setup.zip) |
| Navigation before the folder-map and resource-filing organization pass | [Original seven documents and hashes](sources/history/2026-10-12-before-navigation-organization.zip) |
| Instructions before reference-rich React workflow and separate Dream review versions | [Original 25 documents and hashes](sources/history/2026-10-12-before-react-workflow.zip) |
| Dream instructions before the nightly three-hour operating design | [Original 10 documents and hashes](sources/history/2026-10-12-before-three-hour-dream.zip) |
| Instructions before simplifying Setup and independent roles | [Original 20 documents and hashes](sources/history/2026-10-12-before-bootstrap-simplification.zip) |
| Supporting workflows before the screenshot and daily-review clarification | [Original three documents and hashes](sources/history/2026-10-12-before-role-clarification.zip) |
| Agent files before the Markdown walkthrough | [Original eight documents and hashes](sources/history/2026-10-12-before-agent-walkthrough.zip) |
| Instructions before per-chat project setup | [Original 12 documents and hashes](sources/history/2026-10-12-before-chat-setup.zip) |
| Records before incorporating the new style menu into the index | [Original four files and hashes](sources/history/2026-10-12-before-index-refresh.zip) |
| Resource consolidation and original files | [Move and preservation receipt](resource-consolidation.md) |
| Retired current plan | [Agent plan](plans/2026-10-12-agent-plan.md) |
| Earlier agent contracts | [Taste](agents/taste.md), [Dream](agents/dream.md) |
| Previous setup and build plan | [Setup](2026-10-12-before-simplification/instructions/SETUP.md), [plan](2026-10-12-before-simplification/instructions/PLAN.md), [prior README](2026-10-12-before-simplification/README.md) |
| Earlier three-file starter | [START.md](starter/START.md) and [portability research](portability-research.md) |
| Original workspace research | [Source index](workspace-sources/README.md) and [provenance](workspace-sources/manifest.md) |
| Earlier team research | [Team watch](team-watch/README.md) |
| Empty viewport/category scaffold | `scaffolding/apps/`, `scaffolding/websites/`, `scaffolding/games/` |
| Changed documents before this cleanup | `2026-10-12-before-simplification/` |
| Original paths and hashes | [Preservation map](PRESERVATION.md) |

The 12 viewport records and 324 category placeholders moved here without changing their contents. All previously captured sources and collections remain available. Source links and relative paths inside archived bodies retain their original meaning; use the preservation map to locate a moved file instead of treating old instructions as active.

The full [pre-cleanup snapshot](sources/history/2026-10-12-before-simplification.zip) preserves all 1,009 files in the prior portable kit, including original non-Markdown files and licensed sources, with a SHA-256 manifest. It is history, not an alternative current setup. Existing local tool installations and old exports are also retained on this computer.

The subsequent resource consolidation replaced `shared/` with the themed resource folders, moved current instructions into `agents/`, and created top-level `mcps/`. Its receipt accounts for every file in that 851-file kit and preserves the originals of edited files. Historical bodies may contain old paths; use the receipt to find their current locations.

[Spotted in Prod source history](sources/spotted-in-prod/README.md) preserves the dated tag snapshot and prior records before its integration into the app/web vocabulary.
