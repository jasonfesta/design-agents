# Design agents

Five agents, one master resource list, and folders for actual design work.

```text
agents/       Setup, Atlas, Taste, Dial, Dream; working memory
resources/    Master list, design, styles, motion, tooling, agents, jigs, history
mcps/         MCP research and connection records
apps/         App entry guide
websites/     Website entry guide
games/        Game entry guide
tools/        Local tools
```

## Start

[Using the five design agents](agents/README.md) explains the portable Markdown setup, each role's inputs and outputs, and example requests.

Clone this repository, open it in your assistant, and say:

> Read README.md and agents/SETUP.md. Set up this kit for my task: [task].

The Markdown kit needs no runtime installation. For use inside another repository, copy the complete folder as `design-agents/` and point the assistant to its README. Preserve the destination's own instructions.

Each new build chat starts one **app, website, or game**. [Setup](agents/SETUP.md) asks where to save the project and each new direction, unless you already supplied the location. It creates the selected folders and records file destinations in the project's README and `AGENTS.md`. Follow-up work stays with that chat's project. Explicit shared research, kit maintenance, and requests to resume existing projects keep their requested scope.

| Agent | Job |
| --- | --- |
| [Setup](agents/SETUP.md) | Prepare the kit and selected design branch. |
| [Atlas](agents/ATLAS.md) | Organize and find design references. |
| [Taste](agents/TASTE.md) | Annotate research and remember your feedback. |
| [Dial](agents/DIAL.md) | Build editable components, tune them, and save variants. |
| [Dream](agents/DREAM.md) | Revisit selected work and develop improvements. |

## Resources and work

[The master resource list](resources/catalogue.md) indexes our resource records, collections, styles, motion terms, tooling, agent references, design jigs, and [MCPs](mcps/README.md). [Resources](resources/README.md) shows the folders. [History](resources/history/README.md) preserves previous work; only the five agent files above govern current work.

Inside the chosen project, use **apps / websites / games → viewport → category → style** for design records. Product code follows the project's recorded stack layout. Create branches when work begins; each created layer has a README, and reusable component variants stay inside the style. Start from [apps](apps/README.md), [websites](websites/README.md), or [games](games/README.md).

Folder names use lowercase. The installed skills remain in `.agents/skills/`; source/dependency internals retain their upstream names. Local tools and `.tools/` stay on this machine; their dependencies and credentials are excluded from GitHub. The personal [DialKit source archive](resources/history/sources/dialkit-source.zip) preserves source and committed history for reuse. Extract it into an empty `tools/` folder when needed and read its `PERSONAL.md`.

## Maintenance

```sh
python3 scripts/workspace.py catalogue
python3 scripts/workspace.py check
python3 scripts/workspace.py export
```

The master list is generated from the detailed records; edit those records and rebuild it. `export` creates `.exports/design-agent-portable.zip`; run `verify` in an extracted copy to check its hashes. Exports are snapshots, not separate agent versions.

The complete image-to-component workbench still needs implementation. Dream scheduling is not configured. Writing or reading these files does not start services.
