# Setup

Set up one app, website, or game for this chat, establish its save location, and give the IDE clear file destinations. Jason requested this workflow on October 12, 2026.

**Inputs:** The product or direction request, any supplied destination, and the destination's existing instructions. Ask for missing location information before creating its files.

## Start a project or direction

1. Read [README.md](../README.md), the current request, and any existing project instructions. A new build chat starts a separate project by default. Follow-up messages continue that chat's project. An explicit request to resume an existing project or maintain/research the shared kit takes precedence.
2. Establish the project name and type: **app, website, or game**. Use information already supplied; ask only for what is missing. One chat owns one product even when it has several viewports or directions. Do not create a separate chat automatically.
3. **Ask where to save before creating a new project or direction.** For a new project, ask for its project folder. For a new direction, propose its exact destination within the current project and ask whether to use it or another location. A path explicitly supplied in the current request is already an answer. Do not silently choose the current working directory, the shared kit, or another chat's folder. Wait for the location answer before destination-dependent writes; read-only research can continue.
4. For a new project, resolve the answer to an absolute project root. For a new direction, keep the existing project root and resolve its separate destination; record any explicitly chosen location outside the project. Inspect the destination and its instructions before writing. If it belongs to different work, explain the collision and obtain the intended location or explicit continuation choice. Preserve existing files.
5. Create the project record and IDE routing described below. Confirm the resolved root and active direction in a short setup receipt. Use them for later edits without asking again on every save. Ask again when starting a new project/direction or relocating existing work.

Use concise questions such as “Where should I save this app project?” or “Where should I save this new direction? Suggested location: `<resolved path>`.” If the type is also missing, combine that with the location question. Do not treat a suggested default or silence as an answer.

## Create the folders and records

The user-selected project folder contains the product's code and its design records. The reusable kit supplies instructions and resources; its folders do not become the default destination for every chat.

```text
<chosen-project>/
  README.md                         Project record and file destinations
  AGENTS.md                         IDE instructions for this project
  <implementation folders>/        The chosen stack's normal code and assets
  <apps|websites|games>/
    <viewport>/
      <category>/
        <style>/
          README.md                 Direction, references, decisions, and state
          references/               Selected reference assets when needed
          components/               Reusable components and saved variants when needed
```

Names in angle brackets are placeholders, not folders to create. The project name identifies the save root; the classification remains **type → viewport → category → style**. Use lowercase folder names for our records and preserve required stack/engine conventions.

Apps use [interface types](../resources/design/categories/APP-INTERFACES.md); websites use [website uses](../resources/design/categories/WEBSITE-CATEGORIES.md); games use [game genres](../resources/design/categories/GAME-GENRES.md). Use the shared [viewport profiles](../resources/design/viewports/README.md) and current [style menus](../resources/styles/README.md). Exact dimensions, motion, tools, and finer screen details stay inside the branch record.

Create only the selected type and known layers, with one README at each created layer. Record unknown viewport, category, or style choices in the project README; do not create `unset/` branches or invent personal taste. Use [the style template](../resources/styles/template.md) when a direction is explored. Two directions using the same style must have independent named versions/variants and explicit destinations; a new direction must not overwrite the earlier one.

Add a **Design project** section to the project README, retaining its other contents:

| Field | Record |
| --- | --- |
| Project and type | Name and `apps`, `websites`, or `games` |
| Owning chat | Chat title and ID when available; never invent an ID |
| Implementation | Exact code, asset, and build-output locations for the chosen stack |
| Active direction | Direction name and relative viewport/category/style path, or not selected |
| References and variants | Actual relative destinations and source/version pointers |
| State | Current task, unresolved choices, and next action |

Record paths relative to the project root so the project can move. Resolve them against the confirmed absolute root while executing commands. Never use one global “current project” file in the shared kit: simultaneous chats need independent project records.

## Tell the IDE where to write

Create or update a **Design file routing** section in the destination's `AGENTS.md`. Preserve the destination's existing rules. Fill in the actual project name and paths; leave no unresolved path placeholders in a claimed-ready routing section.

```md
## Design file routing

- This chat builds <project name>, a <type>. Read the Design project section of README.md for the current paths and direction.
- Save product code and assets in the recorded implementation locations. Run project commands from this project root or an explicit recorded subdirectory.
- Save direction notes, selected references, reusable component variants, and design checks under the recorded active direction. Keep one canonical implementation; link shared code by path and revision.
- Keep project feedback with the project. Promote a reusable resource or personal preference to the shared kit only when its scope supports that change.
- Ask Jason where to save a new project or direction before creating it, unless the request already gives the destination. Follow-up edits use the recorded locations.
- Preserve earlier directions and other projects. If a destination is missing, ambiguous, or outside the recorded locations, resolve the intended path before writing there.
```

Ensure the IDE assistant has read the project instructions and opens or targets the confirmed project folder. If the IDE does not discover `AGENTS.md`, explicitly load it through its supported instruction mechanism. If changing the active workspace is unavailable, use absolute file destinations and an explicit command working directory. These are assistant instructions; they do not change IDE permissions or editor settings automatically.

## Finish setup

Use the five agents and [the master resource list](../resources/catalogue.md). Check relevant [taste coverage](memory/COVERAGE.md); missing research remains missing. Read [MCP records](../mcps/README.md) only when a server is needed. Reuse the destination's stack and available tools; reading Setup does not install every service or start Dream.

Verify the created folders, README links, and every recorded file destination. Confirm that they belong to this project and preserve any existing work. Report the project/type, absolute save root, active direction or unresolved selection, implementation locations, and next action. When editing the shared kit, also rebuild the catalogue and run `python3 scripts/workspace.py check` from the kit's root; that checker does not validate an external project's implementation.

## Copy and refresh rules

Clone or copy the whole kit to reuse it, including its bundled Resources and local skills. Within that copy, link to the canonical source instead of duplicating it into every branch. For a self-contained handoff outside the kit, include the selected branch's required context and assets with their source IDs and attribution.

Preserve existing files, local edits, source identity, dates, and licenses. Keep earlier kit work in [History](../resources/history/README.md) and earlier product directions with their owning project. Never replace an existing record solely because its filename matches. Re-running setup in the same chat opens and updates the recorded project.

[The root README](../README.md) describes GitHub reuse, exports, and the preserved DialKit source. Automated installation of every external service is outside this simple setup.

## Result

Return the confirmed project/type, absolute save root, active direction or unresolved selection, implementation locations, created records, and readiness gaps. The project's README and `AGENTS.md` must contain the actual routing; a proposed folder tree alone is not completed setup. Use [the shared handoff format](README.md#save-once-and-hand-off-clearly) when passing work to another role.
