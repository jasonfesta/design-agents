# Dial

**Reference image → editable component → controls → saved variant → application.**

**Inputs:** The reference image or selected component, target viewport, confirmed project/direction paths, applicable Taste guidance, and available implementation tools.

Read the owning project's README and `AGENTS.md` before creating files. Follow [Setup's file routing](SETUP.md#tell-the-ide-where-to-write); a new project or direction needs a save-location answer before destination-dependent writes. Follow-up edits use the recorded paths.

1. Read the target repository's constraints, selected reference, and applicable Taste guidance. Follow [the component workflow](../resources/design/workflows/components.md), including its [shared vocabulary and component structures](../resources/design/workflows/components.md#shared-component-vocabulary-for-dial). Load the complete design-language, visual, gesture, flow, and pattern lists from their canonical source links; exclude product-domain categories from Dial.
2. Break the selected reference into component anatomy, visual layers, gestures, flow steps, patterns, and states using the shared component record. Preserve exact source labels and mark inferred behavior. Reproduce the selected component or screen in editable code. Render at the target viewport, compare with the reference, and record gaps or inferred states.
3. Bind DialKit controls to that same code with matching initial values. Adding controls must preserve its appearance.
4. Interpret prompts as explicit value or code changes; inspect the result.
5. Save each variant's code revision, exact values, five source-label groups, component structure, sources, states, and usage rules independently. Keep team type as optional provenance, outside the tuning controls.
6. Apply a pinned variant to the intended design and verify its appearance and behavior.

Keep selected reference assets, scoped feedback, and component variants in the project's actual direction. Link reusable source descriptions from Resources and applicable personal guidance from Taste. Apply product code in the recorded implementation locations, keeping shared code canonical and variants independent. DialKit provides controls; the agent provides image interpretation and code generation.

The full workbench is not implemented yet. [Local tools](../resources/tooling/local-tools.md#dialkit) records the DialKit installation; [the root README](../README.md) explains reusing its preserved source. [Application guidance](../resources/design/workflows/apply.md) supplies detailed checks when needed.

## Result

Return the actual code and asset locations, reconstruction and variant revisions, exact control values, relevant source labels and component structure, and the checks performed. Preserve the original reconstruction and independent variants. State which stages actually ran—reproduction, control binding, save/reload, and application—and leave unfinished stages explicit. Use [the shared handoff format](README.md#save-once-and-hand-off-clearly).
