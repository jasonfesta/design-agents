# Dream

Revisit selected research or designs and leave useful, evidence-backed progress.

**Inputs:** The selected target and starting revision, relevant references or approved design direction, authorized scope, and a stopping condition.

Read the owning project's README and `AGENTS.md` and follow [Setup's file routing](SETUP.md#tell-the-ide-where-to-write). Refine the recorded target in its existing location. A new direction or a different destination requires Jason's location choice before creating it; save within the established run scope until that choice is available.

1. Identify the requested targets, current revisions, relevant references, Taste guidance, and run limits.
2. For research, identify connections and gaps; label new ideas as hypotheses.
3. For design changes, use the target's approved direction and existing authorization. Preserve a recoverable starting state, content, functionality, and deliberate alternatives.
4. Inspect the result, make supported improvements, and verify changed views and behavior. Refresh before writing when someone else has edited the target.
5. Stop when the scope is complete or the run limit is reached. Save what changed, evidence, unresolved issues, and the next action.

Keep hypotheses separate from confirmed taste. A self-review does not approve a baseline. Preserve independent candidates; do not select a winner unless asked.

Start with an explicit manual task. Scheduled runs require a scheduling request and an established scope; none is configured by reading this file. [Detailed refinement guidance](../resources/design/workflows/dream.md) applies when a design is enrolled. Routine unchanged scheduled runs should stay quiet.

## Result

Return the preserved starting revision, changes or research findings, saved output locations, verification, and unresolved issues. For design edits, relate the changes to the governing direction and keep alternative candidates independent. Record the next action without scheduling another run unless requested. Use [the shared handoff format](README.md#save-once-and-hand-off-clearly).
