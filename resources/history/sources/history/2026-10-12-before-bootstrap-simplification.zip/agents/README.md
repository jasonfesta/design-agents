# Using the five design agents

The portable package is five Markdown role instructions and their supporting resources. An assistant reads the role needed for the task. One build chat owns one app, website, or game and can use all five roles as the work develops.

```text
agents/
  README.md     This walkthrough
  SETUP.md      Project, folders, and save locations
  ATLAS.md      Research, categories, and names
  TASTE.md      Reference annotation and your feedback
  DIAL.md       Editable components, controls, and versions
  DREAM.md      Review and refinement of existing work
  memory/       Shared taste evidence and coverage
```

## Put the kit to work

1. Clone, copy, or extract the complete kit into a folder your assistant can read. Keep its relative paths, Resources, MCP records, and bundled skills together. Read the kit's [README](../README.md).
2. Give the assistant the startup prompt below, replacing the kit path and product description. Explicitly reading the files makes the instructions usable even when the IDE does not discover them automatically.
3. Answer Setup's project-type and save-location questions when that information is missing. Setup creates the selected folders and writes the project's README and `AGENTS.md` with actual file destinations.
4. Continue in that chat. Ask for the appropriate role when you need research, feedback, implementation, or refinement. Load its Markdown and required references; do not load the whole archive for every task.

```text
Read <kit-path>/AGENTS.md, <kit-path>/agents/README.md,
and <kit-path>/agents/SETUP.md.
Set up a new [app, website, or game] for [product description].
Ask me where to save it if I have not supplied a destination.
Use that project's recorded locations for subsequent work.
```

This version uses portable Markdown only. It does not register native IDE agents, commands, or background workers. The role files can guide an assistant with suitable tools; MCP access, local runtimes, and account connections are checked separately when a task needs them. The complete image-to-component workbench still needs implementation, and Dream has no configured schedule.

## Each agent's job

| Agent | Starts with | Produces | Saves to |
| --- | --- | --- | --- |
| [Setup](SETUP.md) | Product or direction request and your chosen destination | Project/type, selected folders, implementation paths, and IDE file-routing instructions | Project README and `AGENTS.md`; README at each created design layer |
| [Atlas](ATLAS.md) | Research question, sources, and the current category/style menus | Relevant references, consistent names, source labels, classifications, and gaps | Project direction for its selected research; shared Resources for reusable source records |
| [Taste](TASTE.md) | Inspected references, your reactions, and existing taste evidence | Annotated observations and scoped keep/change/avoid guidance, with decisions separated from proposals | Project direction for local decisions; `memory/` only for supported reusable preferences |
| [Dial](DIAL.md) | Reference image, target viewport, project paths, and applicable Taste guidance | Editable code, control bindings, exact saved variants, and application checks | Recorded implementation paths and the direction's component/variant locations |
| [Dream](DREAM.md) | Selected existing work, its revision, applicable guidance, and a bounded request | A preserved starting point, refinement or research findings, verification, and remaining issues | The selected project's existing direction and recorded output locations |

## How the work moves between them

**Setup → Atlas → Taste → Dial**, then **Dream** when you want existing work revisited. This is a usual sequence, not a requirement to run every role for every edit. A supplied screenshot may go directly to Dial once its destination and research context are clear; further feedback returns to Taste.

Atlas identifies what a reference is and where it fits. Taste records which qualities you value and why. Dial makes those choices editable in code and saves their exact versions. Dream refines the selected work within its scope; it does not approve its own baseline or choose a different direction without instruction.

Switching roles does not create a new project or change its destination. A new project or direction goes through Setup's save-location question. Follow-up edits use the recorded locations without repeatedly asking. Shared research and kit-maintenance requests keep their stated scope.

## Example requests

| Role | What to say |
| --- | --- |
| Setup | “Set up a new website for my photography portfolio. Ask where to save it.” |
| Atlas | “Find production references for this booking flow and classify their styles and interaction patterns.” |
| Taste | “Annotate these references. I like the typography in the first and the spacing in the second; record that scope.” |
| Dial | “Reproduce this card from the screenshot, connect controls without changing its starting appearance, and save a separate variant after tuning.” |
| Dream | “Review this saved direction against the approved brief, improve the selected screen, and preserve the starting version.” |

The examples do not select a style or establish a personal preference. Use actual references and your feedback for those decisions.

## Save once and hand off clearly

Keep the product's file destinations in its README and `AGENTS.md`. Keep direction decisions and current work in that direction's README. Link growing component records or version files from there; do not create a new report for every role switch.

At a handoff, record only what the next role needs:

- Project and direction, with their actual paths.
- References or component/version IDs used.
- Work completed and files actually saved.
- Your decisions, observed evidence, and remaining proposals.
- Verification performed, unresolved gaps, and the next action.

When the assistant cannot write files, it must say the result is unsaved and provide the Markdown for you to save. Reading a role file alone does not create any outputs.

The [master resource list](../resources/catalogue.md) owns resource navigation. [MCPs](../mcps/README.md) holds connection research; [local tools](../tools/README.md) identifies installed checkouts. [Agent resources](../resources/agents/README.md) holds craft guidance. [History](../resources/history/README.md) preserves earlier plans and agent versions.
