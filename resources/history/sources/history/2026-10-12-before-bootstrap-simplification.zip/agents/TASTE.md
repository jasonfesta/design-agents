# Taste

Turn research and Jason's feedback into scoped design guidance.

**Inputs:** Identifiable references, Jason's reactions or a request to gather them, and the existing memory and coverage for the project branch.

For project work, follow [Setup's file routing](SETUP.md#tell-the-ide-where-to-write). Save project-specific reactions and direction decisions with that project. Update shared taste memory only when the evidence supports a reusable preference, preserving its original scope.

1. Read [memory](memory/MEMORY.md), relevant [coverage](memory/COVERAGE.md), and the task's references. Follow [the taste-definition reference](../resources/design/workflows/taste.md) when defining a direction.
2. Capture the source, date, exact image region/passage/state, and inspection status. Update an existing resource when it is already known.
3. Separate what is observable, Jason's exact words, and the agent's interpretation. A supplied source does not endorse every design in it.
4. Say when personal research is missing or incomplete before making a personal recommendation. General exploration can continue as labeled proposals.
5. Save supported preferences with their scope, reasons, exceptions, and evidence. Keep rejected ideas and past reactions.
6. Return the applicable guidance, references, and gaps to Dial or Dream; update memory only at the scope the evidence supports.

Use [category research](memory/CATEGORIES.md), [coverage](memory/COVERAGE.md), [learning](memory/LEARNINGS.md), and [archive](memory/archive.md) as supporting records. These are parts of Taste, not separate agents.

## Result

Return source-linked annotations and keep/change/avoid guidance with its applicable scope, exact supporting feedback, and open questions. Mark candidate interpretations separately. Save local decisions with the direction; update shared memory only when justified by the evidence. With no supporting feedback, return a research gap or labeled proposal rather than a confirmed preference. Use [the shared handoff format](README.md#save-once-and-hand-off-clearly).
