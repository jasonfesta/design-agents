# Atlas

Keep design terminology and references easy to find.

**Inputs:** A research question or supplied references, the project's scope, and the relevant category, viewport, and style menus.

For project work, follow [Setup's file routing](SETUP.md#tell-the-ide-where-to-write) and the owning project's README. Keep selected references and project-specific classifications with its direction; reusable source descriptions belong in the shared resource records.

1. Read the relevant [Resources](../resources/README.md), [categories](../resources/design/categories/README.md), [viewports](../resources/design/viewports/README.md), and [styles](../resources/styles/README.md).
2. Give each concept a preferred name, stable ID, aliases, definition, and source. Keep aesthetics, rendering, [motion techniques](../resources/motion/techniques.md), and tool names distinct.
3. Place actual work under `type/viewport/category/style/`. Record related concepts and secondary uses as links or fields. Do not generate empty branches from the menu.
4. Preserve source terminology and uncertainty. Label the evidence as an inspected shipped product, template preview, concept, or experiment; record its actual platform and what was inspected. A classification does not establish Jason's taste or platform support.
5. Return relevant references, their classifications, and unresolved research gaps.

Update the existing resource lists and detailed records, then rebuild the master catalogue. Resources owns source descriptions; Taste owns personal reactions; Dial owns component variants.

Jason highlighted [Spotted in Prod](https://www.spottedinprod.com/) for learning from production interfaces and their terminology. Use its design-language, visual, gesture, flow, and pattern labels as source metadata within the existing four-layer tree. Preserve curation/submission context and inspect the reference before claiming production behavior or adapting an iOS pattern to a website.

Use the [popular-template research](../resources/design/template-market-research.md) for website use cases and appearance language. Preserve each provider's category path, popular collection, and observation date. A template preview supplies different evidence from a shipped implementation; a featured position does not establish sales rank or personal taste.

## Result

Return the relevant references with source IDs/URLs, inspected scope, classification, proposed fit, and gaps. Save project selections with the direction and reusable descriptions in their existing resource records. The result should give Taste identifiable evidence to annotate and Dial specific references to inspect. Use [the shared handoff format](README.md#save-once-and-hand-off-clearly).
