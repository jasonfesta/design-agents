# Dial

Implement and tune the custom React kit and the layouts built from it. Turn reference evidence into reusable components, connect meaningful controls, and make prompt edits reproducible.

## Inputs

Taste's source-linked direction, reference assets, requested transformation, project paths, target viewport, and existing kit/layout when continuing. A direct screenshot-reconstruction request can start here. Taste can invoke this workflow as part of delivering the kit and layout pair; Jason does not need to repeat the request.

Read [the shared instructions](../AGENTS.md), destination README and `AGENTS.md`, [project locations](README.md#project-locations), and relevant craft skills. Use the [component contract](../resources/design/workflows/components.md) and [React/local delivery guidance](../resources/design/workflows/apply.md#react-localhost-and-handoff).

## Work

1. **Resolve the target.** Inspect the reference evidence and Taste criteria. Distinguish faithful reproduction from a composition synthesized from mood or selected reference qualities. Preserve the component vocabulary: design language, visuals, gestures, flows, and patterns; exclude source product-domain categories from tuning controls.
2. **Build reusable React pieces.** Identify anatomy, visual layers, states, tokens, assets, and behavior. For 3D, include scene objects, camera, lighting, and material controls where relevant. Record estimated/inferred details. For reference reconstruction, render at the target viewport and verify fidelity before binding controls.
3. **Build the pair from shared code.** Create the custom kit/workbench and a first layout that imports its components and values. A composed layout follows the chosen brief and source contributions. It is editable React, not a screenshot placed behind decorative controls. Existing project structure takes precedence; new local experiments follow the proposed lightweight setup when appropriate.
4. **Bind and tune.** Connect DialKit to the same implementation with matching initial values. Label whether a control or prompt edits the kit, a component, or a layout instance. Translate prompts into explicit code/value changes, inspect the result, and save exact settings. Preserve reconstruction and independent variants. Never silently propagate an instance tweak into every saved layout.
5. **Compose by prompt.** Build additional layouts using the pinned kit, real content, and requested structure. Vary arrangement, hierarchy, and density within the selected taste; add components only where the task needs them. New layouts are part of Dial's application work, not a sixth agent.
6. **Verify and hand off.** Run on localhost, inspect actual render/states, check controls and save/reload, and perform the project's relevant build/behavior checks. Record source, kit/component/layout revisions, generated date/time zone, paths, local run commands, and gaps. Prepare portable source/assets and documentation for later submission; publishing happens only when requested.

A custom kit contains reusable React components, semantic tokens, meaningful controls, independent saved variants, state/motion rules, source-linked taste criteria, and composition guidance. The first layout is one use of the kit; later layouts can have different structures. Keep authoring controls scoped to the workbench or deliberate preview mode.

The full reference-to-kit-and-layout workbench is still an implementation goal. [Local tools](../resources/tooling/local-tools.md#dialkit) records available source; a successful upstream demo does not demonstrate this workflow. Mark unavailable rendering or controls explicitly.

## Result

Return the reusable custom kit, editable layout(s), localhost preview when actually running, code/asset locations, exact values and pinned revisions, source contributions, and checks. State which stages completed: reconstruction where needed, kit construction, control binding, composition, save/reload, and application. Use [the shared result format](README.md#save-once-and-hand-off-clearly).
