# Agents

The five current instructions are [Setup](SETUP.md), [Atlas](ATLAS.md), [Taste](TASTE.md), [Dial](DIAL.md), and [Dream](DREAM.md).

One build chat owns one app, website, or game. Setup asks for each new project/direction's save location and records the file destinations in that project's README and `AGENTS.md`. All five agents read those records before writing; follow-up work uses the same project.

Start from [README](../README.md). Taste's working records live in [memory](memory/MEMORY.md). General agent references and craft guidance live in [Resources](../resources/agents/README.md). The earlier plan and agent versions are preserved in [History](../resources/history/README.md).
