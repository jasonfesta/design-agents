# apps

```text
ATLAS / APPS
────────────────────────────────────────────
layer 01    design type       apps
layer 02    device type       mobile / tablet / desktop / tv
layer 03    viewport size     width × height
layer 04    category          interface
layer 05    style             visual treatment
```

This is a reusable definition resource. Product code and working directions live in the [project destination](../../agents/README.md#project-locations) chosen for the build.

## Full branch skeleton

```text
apps/
├── mobile/
│   └── <width>x<height>/
│       └── <category>/
│           └── <style>/
│               └── README.md
├── tablet/
│   └── <width>x<height>/
│       └── <category>/
│           └── <style>/
│               └── README.md
├── desktop/
│   └── <width>x<height>/
│       └── <category>/
│           └── <style>/
│               └── README.md
└── tv/
    └── <width>x<height>/
        └── <category>/
            └── <style>/
                └── README.md
```

Every created layer receives a README describing its settings and links. This skeleton shows the available route; it does not require creating every possible combination. Device support is verified for the actual runtime.

## Category menu

```text
category / 20 app interface families
├── dashboards
├── feeds
├── messaging
├── search-discovery
├── content-libraries
├── detail-views
├── editors
├── canvas-builders
├── media-players
├── calendars
├── booking-flows
├── task-boards
├── data-management
├── maps-navigation
├── checkout-payments
├── onboarding
├── account-settings
├── notifications
├── progress-tracking
└── assistants
```

[Category definitions](categories.md) own the boundaries. [Style interpretation](styles.md) describes how visual vocabulary applies to apps. Device types, sizes, categories, and styles are independent selections.

## Example direction

Illustrative path; no project or personal style selection is implied:

```text
apps
└── mobile
    └── 390x844
        └── dashboards
            └── minimal
                └── README.md
```

```text
direction.type      apps
direction.device    mobile
direction.viewport  390x844 CSS px
direction.category  dashboards
direction.style     minimal
reference.status    illustrative
```

## Design notes

Task hierarchy, information density, state coverage, and interaction feedback.

Use [device definitions](../devices/README.md), [Chrome sizes and names](../viewports/CHROME.md), and [the style template](../styles/template.md). Record references, exact settings, component revisions, states, feedback, and checks with the real direction. Keep meaningful motion in the [motion vocabulary](../motion/techniques.md).

> By the way — changing the viewport changes the available space. Changing the category changes the task. Changing the style changes the visual language.
