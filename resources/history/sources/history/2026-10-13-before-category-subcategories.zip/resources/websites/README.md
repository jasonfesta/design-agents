# websites

```text
ATLAS / WEBSITES
────────────────────────────────────────────
layer 01    design type       websites
layer 02    device type       mobile / tablet / desktop / tv
layer 03    viewport size     width × height
layer 04    category          website use
layer 05    style             visual treatment
```

This is a reusable definition resource. Product code and working directions live in the [project destination](../../agents/README.md#project-locations) chosen for the build.

## Full branch skeleton

```text
websites/
├── mobile/
│   └── <width>x<height>/
│       └── <category>/
│           └── <style>/
│               └── README.md
├── tablet/
│   └── <width>x<height>/
│       └── <category>/
│           └── <style>/
│               └── README.md
├── desktop/
│   └── <width>x<height>/
│       └── <category>/
│           └── <style>/
│               └── README.md
└── tv/
    └── <width>x<height>/
        └── <category>/
            └── <style>/
                └── README.md
```

Every created layer receives a README describing its settings and links. This skeleton shows the available route; it does not require creating every possible combination. Device support is verified for the actual runtime.

## Category menu

```text
category / 18 website uses
├── landing-pages
├── saas-marketing
├── app-launches
├── ecommerce
├── marketplaces
├── portfolios
├── agency-studio
├── business-services
├── editorial-blogs
├── directories
├── documentation
├── community-membership
├── courses-education
├── events-conferences
├── booking-reservations
├── careers-job-boards
├── nonprofit-fundraising
└── interactive-stories
```

[Category definitions](categories.md) own the boundaries. [Style interpretation](styles.md) describes how visual vocabulary applies to websites. Device types, sizes, categories, and styles are independent selections.

## Example direction

Illustrative path; no project or personal style selection is implied:

```text
websites
└── desktop
    └── 1440x900
        └── saas-marketing
            └── typographic
                └── README.md
```

```text
direction.type      websites
direction.device    desktop
direction.viewport  1440x900 CSS px
direction.category  saas-marketing
direction.style     typographic
reference.status    illustrative
```

## Design notes

Page hierarchy, reading rhythm, typography, conversion paths, and responsive composition.

Use [device definitions](../devices/README.md), [Chrome sizes and names](../viewports/CHROME.md), and [the style template](../styles/template.md). Record references, exact settings, component revisions, states, feedback, and checks with the real direction. Keep meaningful motion in the [motion vocabulary](../motion/techniques.md).

> By the way — changing the viewport changes the available space. Changing the category changes the task. Changing the style changes the visual language.
