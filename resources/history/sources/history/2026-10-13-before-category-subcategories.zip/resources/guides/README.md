# Design guides

Use these records for naming, reference research, and the Taste/Dial workflow. The [master list](../README.md) connects them with styles, motion, tools, and source collections.

## Choose the design branch

| Decision | Record |
| --- | --- |
| Apps, websites, or games; then category | [Categories and folder structure](../structure.md) |
| Device type and viewport dimensions | [Viewport profiles](../viewports/README.md) |
| Matching aesthetic | [Styles](../styles/README.md) |

The hierarchy is **type → device type → viewport size → category → style**. Create project folders only when work begins. The earlier app-store menu remains labeled legacy context; app interface types and website uses are the current menus.

## Work from references

| Task | Record |
| --- | --- |
| Separate layout from mood; choose Reconstruct, Adapt, or Explore | [Reference-to-layout research](reference-to-layout-research.md) |
| Ingest references, define taste, build/tune components, and run layouts | [Detailed workflows](workflows/README.md) |
| Find the current role and project-saving rules | [Agent guide](../../agents/README.md) |

## Supporting research

These retain research context and attribution. Use the current role and workflow instructions for execution.

- [Category and style research](category-and-style-research.md)
- [Popular templates, subcategories, and AI creation](template-market-research.md)
- [Direction research](direction-research.md)
- [Reference intake](reference-intake.md)
- [Design-system research](systems-research.md)
- [Application research](application-research.md)
