# Page and screen details

Updated October 12, 2026 · Follow the corrected design-category model

A major website use or app interface can occupy the category layer: [website categories](../websites/categories.md), [app interfaces](../apps/categories.md). Jason explicitly selected landing pages/SaaS for website exploration and dashboards, feeds, editors, players, and booking flows for apps. Do not force these back beneath a store industry category.

Use finer details inside the chosen branch:

| Category example | Details within the record |
| --- | --- |
| SaaS marketing site | Homepage, feature page, pricing, integrations, about, changelog |
| Landing page | Offer, campaign audience, conversion goal, sections |
| Dashboard | Overview/report, data scope, filters, drill-down, empty/loading/error states |
| Editor | Content medium, editing mode, toolbar, inspector, version/history state |
| Booking flow | Availability, selection, participant details, review, confirmation |
| Game genre | Play screen, menu, inventory, HUD, settings, result screen |

Record industry, subject, business model, and audience separately. A finance dashboard is `apps/<viewport>/dashboards/<style>/` with finance context; an ecommerce fashion site records fashion as its subject. These are illustrative candidate paths, not populated or approved designs.

A site's page kind and a product's interface can overlap several research collections. Choose the primary home for the actual deliverable and cross-link the other relevant categories. The [research note](category-and-style-research.md) explains the proposed boundary rules. Exact page/screen detail remains necessary: research for one view does not establish taste for all others.

## Source subcategories

Use the full [Spotted in Prod Flows](../sources/spotted-in-prod/taxonomy.md#flows) and [Patterns](../sources/spotted-in-prod/taxonomy.md#patterns) lists to tag finer details for apps and websites. Onboarding can map to our `onboarding` category; Feed to `feeds`; Search and Discovery to `search-discovery`; Settings to `account-settings`; Detail View and Profile to `detail-views`. Choose the primary task after inspecting the reference. Loading, Empty State, Error State, and Confirmation are states; Modal, Bottom Sheet, and Morph are patterns, not new folder layers. A source product category such as Finance does not replace these interface categories.
