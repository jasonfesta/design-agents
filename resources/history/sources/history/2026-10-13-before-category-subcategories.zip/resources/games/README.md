# games

```text
ATLAS / GAMES
────────────────────────────────────────────
layer 01    design type       games
layer 02    device type       mobile / tablet / desktop / tv
layer 03    viewport size     width × height
layer 04    category          genre
layer 05    style             visual treatment
```

This is a reusable definition resource. Product code and working directions live in the [project destination](../../agents/README.md#project-locations) chosen for the build.

## Full branch skeleton

```text
games/
├── mobile/
│   └── <width>x<height>/
│       └── <category>/
│           └── <style>/
│               └── README.md
├── tablet/
│   └── <width>x<height>/
│       └── <category>/
│           └── <style>/
│               └── README.md
├── desktop/
│   └── <width>x<height>/
│       └── <category>/
│           └── <style>/
│               └── README.md
└── tv/
    └── <width>x<height>/
        └── <category>/
            └── <style>/
                └── README.md
```

Every created layer receives a README describing its settings and links. This skeleton shows the available route; it does not require creating every possible combination. Device support is verified for the actual runtime.

## Category menu

```text
category / 17 game genres
├── action
├── adventure
├── arcade
├── board
├── card
├── casino
├── casual
├── educational
├── music
├── puzzle
├── racing
├── role-playing
├── simulation
├── sports
├── strategy
├── trivia
└── word
```

[Category definitions](categories.md) own the boundaries. [Style interpretation](styles.md) describes how visual vocabulary applies to games. Device types, sizes, categories, and styles are independent selections.

## Example direction

Illustrative path; no project or personal style selection is implied:

```text
games
└── tablet
    └── 768x1024
        └── puzzle
            └── pixel-art
                └── README.md
```

```text
direction.type      games
direction.device    tablet
direction.viewport  768x1024 CSS px
direction.category  puzzle
direction.style     pixel-art
reference.status    illustrative
```

## Design notes

Gameplay legibility, world/HUD relationship, input feedback, camera, and rendering.

Use [device definitions](../devices/README.md), [Chrome sizes and names](../viewports/CHROME.md), and [the style template](../styles/template.md). Record references, exact settings, component revisions, states, feedback, and checks with the real direction. Keep meaningful motion in the [motion vocabulary](../motion/techniques.md).

> By the way — changing the viewport changes the available space. Changing the category changes the task. Changing the style changes the visual language.
