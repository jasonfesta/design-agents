# Design structure

```text
JASON / ATLAS SCHEMA
────────────────────────────────────────────
version     1.0 · October 13, 2026
status      five layers confirmed by Jason
scope       apps / games / websites
```

## The five layers

```text
design type
└── device type
    └── viewport size
        └── category
            └── style
```

| Layer | Meaning | Canonical resource |
| --- | --- | --- |
| 01 · design type | What kind of thing are we making? | [Apps](apps/README.md) · [Games](games/README.md) · [Websites](websites/README.md) |
| 02 · device type | Mobile, tablet, desktop, or TV | [Devices](devices/README.md) |
| 03 · viewport size | Exact width × height, with units | [Viewports](viewports/README.md) · [Chrome device names](viewports/CHROME.md) |
| 04 · category | App interface, game genre, or website use | [App categories](apps/categories.md) · [Game categories](games/categories.md) · [Website categories](websites/categories.md) |
| 05 · style | The visual treatment and its explicit recipe | [Style vocabulary](styles/README.md) · [Record template](styles/template.md) |

Chrome preset names, pixel ratio, safe areas, input, runtime, orientation, motion, and finer screen details belong in the relevant layer's MD. Each selected layer has its own README. Keep the five identities distinct.

## Full skeleton

Within a chosen project's design records:

```text
<project>/
├── apps/
│   ├── mobile/
│   │   └── <width>x<height>/
│   │       └── <category>/
│   │           └── <style>/
│   │               └── README.md
│   ├── tablet/
│   │   └── <width>x<height>/
│   │       └── <category>/
│   │           └── <style>/
│   │               └── README.md
│   ├── desktop/
│   │   └── <width>x<height>/
│   │       └── <category>/
│   │           └── <style>/
│   │               └── README.md
│   └── tv/
│       └── <width>x<height>/
│           └── <category>/
│               └── <style>/
│                   └── README.md
├── games/
│   ├── mobile/
│   │   └── <width>x<height>/
│   │       └── <category>/
│   │           └── <style>/
│   │               └── README.md
│   ├── tablet/
│   │   └── <width>x<height>/
│   │       └── <category>/
│   │           └── <style>/
│   │               └── README.md
│   ├── desktop/
│   │   └── <width>x<height>/
│   │       └── <category>/
│   │           └── <style>/
│   │               └── README.md
│   └── tv/
│       └── <width>x<height>/
│           └── <category>/
│               └── <style>/
│                   └── README.md
└── websites/
    ├── mobile/
    │   └── <width>x<height>/
    │       └── <category>/
    │           └── <style>/
    │               └── README.md
    ├── tablet/
    │   └── <width>x<height>/
    │       └── <category>/
    │           └── <style>/
    │               └── README.md
    ├── desktop/
    │   └── <width>x<height>/
    │       └── <category>/
    │           └── <style>/
    │               └── README.md
    └── tv/
        └── <width>x<height>/
            └── <category>/
                └── <style>/
                    └── README.md
```

The skeleton enumerates routes; actual folders are created for work. Shared definitions are linked from Resources. Product code follows the project's stack and can be shared across multiple sizes. Do not duplicate a React app for every category or viewport.

## Category and style menus

| Design type | Category menu | Style interpretation |
| --- | --- | --- |
| apps | [20 interface families](apps/categories.md) | [App styles](apps/styles.md) |
| games | [17 game genres](games/categories.md) | [Game art and HUD styles](games/styles.md) |
| websites | [18 website uses](websites/categories.md) | [Website styles](websites/styles.md) |

The previously suggested extra app categories remain proposals and have not been added. The shared app/web style vocabulary and game terms stay in their existing menus; no category automatically selects a style.

## Read a path

```text
websites / desktop / 1440x900 / saas-marketing / typographic
│          │         │          │                └─ visual language
│          │         │          └─ website use
│          │         └─ width × height; units recorded in MD
│          └─ device type
└─ design type
```

This example explains the schema, not a selected personal design direction. Industry, audience, product scope, component patterns, and source tags remain descriptive fields. Sources and styles do not become extra category layers.

## Markdown treatment

Use compact monospaced specification blocks, generous tree diagrams, precise design language, and occasional short “By the way” notes. Keep normal prose readable and links functional. This is the documentation treatment; it does not prescribe the font or visual style of every generated layout.

Earlier four-layer records are preserved in [History](history/README.md). The current five-layer schema supersedes their device/viewport conflation. Historical paths need deliberate mapping before use; no personal taste is inferred from a renamed field.

## Control “go wide”

Before generating candidates, write a matrix with one row per candidate. Each row needs: candidate ID; design type; device type and viewport size; consumer category; product scope; family/treatment; task and content set; fixed requirements; axes allowed to change; reference IDs; intended output; and baseline/version if one governs it.

| Breadth | What changes | What stays fixed |
| --- | --- | --- |
| Across categories | Domain, user task, and category-specific evidence | A common deliverable format; assess within each domain rather than declaring a universal winner. |
| Across style families | Visual premise, composition, type and material within declared constraints | Category, product scope, task, content and viewports. |
| Within a treatment | Named controls, layout strategies and approved variations | Treatment identity, product task and locked rules. |
| Refine one direction | Requested rules or values | Remaining state and lineage. |

For requested exploration, default to three candidates within one category and product scope. First run TASTE.md and disclose missing coverage; an empty branch is not an instruction to generate personal taste recommendations. When general exploration is authorized, label unsupported candidates as provisional proposals. Honor a requested count. Do not generate an exhaustive combination of every category, style, density and platform.

For a two-scope by three-style experiment, create six explicit rows and compare the three styles within each scope. Reuse relevant content within each comparison group. Changing the task between candidates cannot demonstrate that one style is better.

Vary no more than two named control axes when tuning within a treatment unless Jason asks for broader change. Across families, several visual properties may change together as a coherent premise. Candidates must differ in hierarchy, composition, or behavior in a way the reviewer can name; recolors alone do not establish breadth.

## Baseline inheritance

A category baseline can define shared standards such as image honesty, readable product information, and accessible operation. A style-branch baseline defines the visual identity. A particular direction adds its resolved values. Each rule states its scope and whether it is required, a default that a child can override, or a permitted range.

Approved child rules may override declared defaults. They cannot silently waive a required parent rule. A conflict needs Jason's recorded exception or a revised baseline. Resolve the effective rules before Dream Mode starts, and pin the versions used. Do not apply one subject-specific font, density, or composition to every branch merely because it is the category's most recently used style.

Use a registry row per activated branch:

```md
| Branch ID | Design type and viewport | Product scope | Research state and definition | Parent baseline | Branch baseline | Approval record | Enrolled targets | Dream on/off |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| websites/desktop/1440x900/ecommerce/editorial | websites / desktop / 1440x900 CSS px | fashion resale; commerce page; archive-catalogue treatment | not researched; none | unset | unset | none | none | off |
```

This example is a proposed row, not enrollment. Stable branch IDs and exact baseline mappings let daytime exploration and Dream Mode operate on the same design vocabulary.
