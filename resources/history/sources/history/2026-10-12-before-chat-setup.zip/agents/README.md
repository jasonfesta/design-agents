# Agents

The five current instructions are [Setup](SETUP.md), [Atlas](ATLAS.md), [Taste](TASTE.md), [Dial](DIAL.md), and [Dream](DREAM.md).

Start from [README](../README.md). Taste's working records live in [memory](memory/MEMORY.md). General agent references and craft guidance live in [Resources](../resources/agents/README.md). The earlier plan and agent versions are preserved in [History](../resources/history/README.md).
