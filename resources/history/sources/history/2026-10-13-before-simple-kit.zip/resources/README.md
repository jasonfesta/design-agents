# Resources

[The master list](catalogue.md) is the single place to browse resources. This page explains where to save them; the root [folder map](../README.md#folder-map) shows the kit. Detailed records retain URLs, attribution, dates, observations, and review limits.

## Where to save

| Material | Canonical home |
| --- | --- |
| Categories, viewport definitions, design research, and workflow methods | [design/](design/README.md) |
| Visual aesthetics and their app/website/game interpretations | [styles/](styles/README.md) |
| Motion names, techniques, and motion-tool references | [motion/](motion/README.md) |
| Tool capabilities, installation research, and local setup receipts | [tooling/](tooling/README.md) |
| Supporting agent research and craft guidance | [agents/](agents/README.md) |
| Interactive design experiments and adjustable jigs | [jigs/](jigs/README.md) |
| Supplied websites, libraries, directories, and their source records | [collections/](collections/README.md) |
| Previous versions, retired structures, original source snapshots | [history/](history/README.md) |
| MCP provider research and connection records | Top-level [mcps/](../mcps/README.md) |

Current role instructions belong in the root [agents/](../agents/README.md) folder. Personal taste evidence and decisions belong in [agents/memory/](../agents/memory/MEMORY.md). Installed checkouts belong in [tools/](../tools/README.md); their documentation belongs in `tooling/`.

## Add a reference

1. Search the [master list](catalogue.md) and [detailed source records](collections/source-records.md) for the URL or source ID. Update the existing record when it is already present, preserving earlier observations.
2. For a new source, add its primary record in `collections/source-records.md`. Keep source identity, URL, origin, date, relevant labels, what was inspected, and known license/status limits. A larger collection can have one linked Markdown detail file or folder under `collections/`; small references do not need a separate file.
3. Link that canonical record from relevant design/style/motion/tool notes instead of copying it into each category. Run `python3 scripts/workspace.py catalogue` and `python3 scripts/workspace.py check` from the kit root.

[DesEngs](collections/desengs/README.md) owns its captured directory indexes. [Fancy Components](collections/fancy-components.md) owns its component links and supplied marquee reference. [Spotted in Prod](collections/spotted-in-prod/README.md) owns its source tags; [styles](styles/README.md) owns our mappings. Keep source terms and our interpretation distinguishable.

## Project references and history

Save project-specific screenshots, videos, selected source contributions, custom kits, layouts, and versions at that project's recorded destinations. Put reusable source descriptions here and link the project evidence where appropriate. Source inclusion does not establish personal taste or tool readiness.

Preserve earlier material in History before replacing it. Historical instructions are evidence; current role files govern new work. Keep original ownership, licenses, and differing notes with each source.

Copy the complete kit to retain working links, MCP documentation, and bundled skills. Resources can also travel alone as a research collection; links to other kit folders then remain context requiring the rest of the kit.
