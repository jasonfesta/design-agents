# Agent resources

[Craft foundation](craft-foundation.md) documents the attributed starting guidance and source context. [Installed skills](../../.agents/skills/design-catalogue/SKILL.md) provide task-specific guidance; catalogue pointers and complete installed skills remain distinct.

The bootstrap guide and four independent work roles are in [agents](../../agents/README.md). Earlier agent research and versions are preserved in [History](../history/README.md). This folder contains supporting resources, not another agent set.
