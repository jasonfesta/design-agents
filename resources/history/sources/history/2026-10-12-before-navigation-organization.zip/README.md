# Design agents

One setup guide, four design roles, and one master resource list. Portable Markdown for use in any IDE that can read the kit.

```text
agents/       Setup; Atlas, Taste, Dial, Dream; working memory
resources/    Master list, design, styles, motion, tooling, agents, jigs, history
mcps/         MCP research and connection records
apps/         App entry guide
websites/     Website entry guide
games/        Game entry guide
tools/        Local tools
```

## Start

Clone, copy, or extract the complete kit, including its hidden `.agents/skills/` folder. Open it in your assistant and say:

> Read agents/SETUP.md and prepare this kit for use here.

[Setup](agents/SETUP.md) checks that the supplied folders and instructions are ready. The Markdown kit needs no runtime installation. To use it inside another repository, copy the complete folder as `design-agents/`, preserve the destination's instructions, and point the assistant to the kit's README.

Then use any role directly. [The role guide](agents/README.md) provides a portable loading prompt and shared file-saving rules.

| Role | Job |
| --- | --- |
| [Atlas](agents/ATLAS.md) | Research concepts and own nomenclature across apps, websites, and games. |
| [Taste](agents/TASTE.md) | Absorb references and deliver a custom DialKit plus a first React layout. |
| [Dial](agents/DIAL.md) | Build and tune React components, controls, variants, and layouts. |
| [Dream](agents/DREAM.md) | Refine the day's work in a nightly three-hour window; save a separate morning-review version. |

These four Markdown guides can become skills later. Each works independently with its required references. The normal [design workflow](agents/README.md#the-design-workflow) is idea → research → references → custom kit and layout → prompt iteration → Dream review. React projects run on localhost; submission or GitHub delivery comes later.

## Resources and work

[The master resource list](resources/catalogue.md) indexes design, styles, motion, tooling, agent references, jigs, collections, and [MCPs](mcps/README.md). [Resources](resources/README.md) shows the folders. [History](resources/history/README.md) preserves prior material; the current instructions are in [AGENTS.md](AGENTS.md) and [agents](agents/README.md).

Each new build chat owns one **app, website, or game**. The working role asks where to save a new project or direction unless you already supplied the destination, then records it in that project's README and `AGENTS.md`. Follow-up edits reuse those locations. Shared research and kit maintenance keep their requested scope.

Inside that project, design records follow **apps / websites / games → viewport → category → style**. Create folders only for actual work; product code follows the recorded stack layout. Start from [apps](apps/README.md), [websites](websites/README.md), or [games](games/README.md).

Our folder names use lowercase; upstream source/dependency names stay intact. Bundled skills remain in `.agents/skills/`. Local tools, dependencies, and credentials stay outside the parent GitHub commit. The personal [DialKit source archive](resources/history/sources/dialkit-source.zip) preserves source and committed history; extract it into an empty `tools/` folder when needed and read its `PERSONAL.md`.

## Maintenance

```sh
python3 scripts/workspace.py catalogue
python3 scripts/workspace.py check
python3 scripts/workspace.py export
```

The master list is generated from detailed records; edit those records and rebuild it. `export` creates `.exports/design-agent-portable.zip`; run `python3 scripts/workspace.py verify` from an extracted kit root to check its hashes. Exports are transfer snapshots.

The full image-to-component workbench still needs implementation. Dream's [nightly operating design](resources/design/workflows/dream.md) is specified; its scheduler and execution host are not configured. Reading these files does not start services or register native IDE skills.
