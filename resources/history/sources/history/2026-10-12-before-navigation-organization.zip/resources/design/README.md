# Design

- [Category and style research](category-and-style-research.md)
- [Popular templates, subcategories, and AI creation](template-market-research.md)
- [Categories and folder structure](categories/README.md)
- [Viewport profiles](viewports/README.md)
- [Direction research](direction-research.md)
- [Reference intake](reference-intake.md)
- [Layout versus mood: research and the custom kit/layout workflow](reference-to-layout-research.md)
- [Design-system research](systems-research.md)
- [Application research](application-research.md)
- [Detailed workflows](workflows/README.md)

These are design references used by Atlas, Taste, Dial, and Dream. [The master list](../catalogue.md) connects them to styles, motion, tools, MCPs, and source collections.
