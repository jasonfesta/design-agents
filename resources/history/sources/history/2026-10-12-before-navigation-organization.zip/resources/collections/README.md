# Source collections

Browse all destinations in the [master resource list](../catalogue.md). These files retain the detailed observations and source memberships behind that index.

- [Detailed resource records](source-records.md): 147 primary records, with source IDs, URLs, dates, review status, and licensing notes.
- [Reviewed references](reviewed.md): the research shortlist and Jason's source feedback.
- [Nero](nero.md): links and source posts from Nero's collection.
- [DesEngs](desengs/README.md): captured resources, website references, and public designer profiles.
- [Fancy Components](fancy-components.md): 40 official component links, with notes on the supplied SVG-path marquee.
- [Spotted in Prod](spotted-in-prod/README.md): all seven expanded homepage tag groups, mapped to app and website style records.

Keep differing observations and original names attached to their source records. Update the relevant record and regenerate the master list; do not replace source evidence with a merged summary.
