# Resources

Use [catalogue.md](catalogue.md) as the single master list. It indexes local design documents and terminology together with the collected external references. Detailed records keep the source URLs, dates, observations, and review status.

```text
resources/
  catalogue.md   Master list
  design/        Design research, categories, viewports, and workflows
  styles/        Website, app, and game aesthetics
  motion/        Motion terminology, Remotion, and Jitter
  tooling/       Tool research and local setup records
  agents/        Agent resources and craft guidance
  jigs/          Interactive design jigs and adjustable experiments
  collections/   Detailed source records, DesEngs, and Nero
  history/       Previous work, original sources, and preservation records
```

[MCPs](../mcps/README.md) have their own top-level folder and are included in the master list.

Keep one detailed record per source and retain original labels, aliases, membership, and differing notes. The master list is a generated index; add observations to the linked record, then run `python3 scripts/workspace.py catalogue` from the repository root. Directory inclusion is not a personal preference or proof of tool readiness.

Preserve all past work in History. Current agent instructions live in the root `agents/` folder. Original licensed sources and structured evidence travel under `history/sources/`. Copy the full repository to retain working links, MCP documentation, and installed skills; Resources can also travel alone as a research collection with external kit links identified as context.
