# Setup

Prepare this kit for use after it is cloned, copied, or extracted into a different IDE.

## Inputs

The complete kit and its local folder path. No product brief or style selection is needed.

## Work

1. Locate the kit root and read [README.md](../README.md), [AGENTS.md](../AGENTS.md), and [the role guide](README.md). Preserve any destination repository's existing instructions.
2. Check the folder map against the supplied copy, including the four role files, resources, top-level `mcps/`, type guides, memory, and bundled `.agents/skills/`. Retain relative paths, source attribution, and history. Restore missing files and their folders from the complete source copy; do not replace local edits or invent missing research.
3. Run the command below from the kit root when Python 3 is available. It uses the standard library. If an export includes `EXPORT-MANIFEST.json`, also run `python3 scripts/workspace.py verify` before changing its contents. Report any failures and repair only from known source material.
4. Make sure the assistant has read the shared instructions. If the IDE does not discover Markdown instructions automatically, use the explicit loading prompt in [the role guide](README.md#use-any-role). Check tools and account connections when the selected task needs them; the Markdown kit itself needs no runtime installation.

```sh
python3 scripts/workspace.py check
```

If Python is unavailable, inspect the folder map and required files manually and state that the automated check was not run. Reading a pointer does not install its upstream skill, and credentials or machine-local tools do not travel with a clone.

Re-running Setup verifies the same kit and preserves projects, memory, and local changes. Starting a design project belongs to whichever role is doing the work, using the shared [project locations](README.md#project-locations) rules.

## Result

Report the kit's location, checks performed, files restored if any, and remaining gaps. Point to Atlas, Taste, Dial, and Dream for the next task. Setup is complete when the supplied kit is intact and its instructions can be read in the current IDE.
