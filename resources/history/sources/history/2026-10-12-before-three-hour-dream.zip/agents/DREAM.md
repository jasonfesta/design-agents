# Dream

Go back through the day's generated work and make sure each item is dialed correctly.

## Inputs

The project or explicitly included projects, review date and time zone, generated-item records, screenshots, saved component variants, and applicable design decisions. Use the current project and local day when those are clear; state the review window. Dream reads saved work directly and does not require another role to run first.

Read [the shared instructions](../AGENTS.md), the project's README and `AGENTS.md`, and [project locations](README.md#project-locations). Use existing authorized destinations for fixes. A new direction still follows the shared location rule.

## Work

1. Inventory everything generated for the requested day within the included project scope: screens, compositions, components, and variants. Use dated direction records and available history; modification time alone does not prove generation date. Record uncertain or missing items and review coverage. Do not expand into unrelated projects.
2. Load each item's screenshot, reference reconstruction, saved code/values, chosen variant, relevant Taste evidence, and explicit changes Jason requested. Read the records directly. Preserve a recoverable starting revision and each direction's identity; refresh if another chat has changed the work.
3. Check that each item is **dialed correctly**: appearance matches its reference plus intended changes; controls address the right properties with correct defaults; saved variants reload the exact intended values; applied screens use the intended revision; layout, states, and behavior meet the project's requirements. Check responsive and accessibility behavior where relevant. Use [the component contract](../resources/design/workflows/components.md) for the details.
4. Fix mismatches and unfinished execution within the authorized direction. Use supported taste criteria for aesthetic refinement; report missing criteria and keep unsupported visual choices provisional. Independent fidelity, control, save/reload, and functional checks can continue. Preserve alternatives and do not select a winner or approve a new baseline yourself.
5. Render and verify changed items in the relevant viewport/states, save the new revision and exact values, and recheck any authorized consumers affected by shared changes. Mark unavailable visual or runtime checks explicitly.
6. Update the existing direction record with the day's inventory, per-item outcome, changes, verification, and unresolved work. Finish when every discovered item has a recorded outcome; a missing reference or inaccessible item cannot be counted as verified.

For enrolled autonomous refinement, also follow [the detailed Dream workflow](../resources/design/workflows/dream.md) and its approved standards and run limits. A manual daily review uses the current request and saved project decisions. Reading this guide does not schedule a nightly run; scheduling requires an explicit request.

## Result

Return a daily review with the date/time zone and project scope, all discovered generated items, preserved starting revisions, fixes and new saved versions, and verification evidence. Label each item **verified**, **fixed and verified**, **changed but unverified**, **needs a decision**, or **not inspected**. Report inventory gaps separately. Save this in the existing project/direction records and use [the shared result format](README.md#save-once-and-hand-off-clearly).
