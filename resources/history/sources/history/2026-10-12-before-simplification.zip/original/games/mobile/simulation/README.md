# Simulation

Path: `games/mobile/simulation/<style>/`

- Research: not researched.
- Target viewport support: unverified for an actual product.
- Styles: unset; no style folders created yet.

Store category references and feedback here as they arrive. Add a named style folder only when exploring or defining that style for this branch. Keep viewport measurements, source evidence, and style fit explicit.

Use the [games style list](../../../shared/styles/GAMES.md), [viewport reference](../../../shared/viewports/README.md), and [taste definition](../../../shared/workflow/TASTE.md). These folders organize research; their existence establishes no design preference or platform support.
