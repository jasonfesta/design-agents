# Instances — source record

Portable Markdown rendering of the recorded structured source. Its dated contents are evidence, not current instructions or capability claims. The original is preserved in the workspace source archive.

```json
[
  {
    "id": "x:2098080850164281394",
    "platform": "X",
    "url": "https://x.com/PaulJun_/status/2098080850164281394",
    "author": "Paul Jun",
    "company": "Ramp",
    "types": [
      "team_showcase",
      "culture",
      "process"
    ],
    "discipline": "brand/product design",
    "summary": "Introduces the team's public site and individual designer expression.",
    "published_at": null,
    "observed_at": "2026-09-23",
    "verification": "indexed_only",
    "supporting_urls": [
      "https://m.twstalker.com/PaulJun_",
      "https://ramp.design/blog/behind-ramp-design"
    ],
    "notes": "Primary X post not retrieved; official team article corroborates the theme, not the exact post date."
  },
  {
    "id": "x:2102860064864502190",
    "platform": "X",
    "url": "https://x.com/laurenloprete/status/2102860064864502190",
    "author": "Lauren LoPrete",
    "company": "Mercury",
    "types": [
      "completed_hires",
      "team_growth"
    ],
    "discipline": "design foundations",
    "summary": "Reports four signed offers in two weeks.",
    "published_at": null,
    "observed_at": "2026-09-23",
    "verification": "primary_post_read",
    "supporting_urls": [
      "https://x.com/laurenloprete"
    ],
    "notes": "Company inferred from profile identifying head of design foundations at Mercury. Individual roles and remaining openings unknown."
  },
  {
    "id": "x:2102919488299745319",
    "platform": "X",
    "url": "https://x.com/adrianmg/status/2102919488299745319",
    "author": "Adrián Mato",
    "company": "Xbox",
    "types": [
      "team_formation",
      "recruiting"
    ],
    "discipline": "cross-disciplinary product building",
    "summary": "Building a team spanning 3D, rich interfaces, platforms, CLIs and creator tools; invites interested builders.",
    "published_at": null,
    "observed_at": "2026-09-23",
    "verification": "primary_post_read",
    "supporting_urls": [],
    "notes": "Full text expanded. No specific requisition or location established."
  },
  {
    "id": "linkedin:7179574986158874624",
    "platform": "LinkedIn",
    "url": "https://www.linkedin.com/posts/vercel_design-engineering-at-vercel-what-we-do-activity-7179574986158874624-GybD",
    "author": "Vercel",
    "company": "Vercel",
    "types": [
      "process",
      "team_structure",
      "recruiting"
    ],
    "discipline": "design engineering/systems",
    "summary": "Explains design engineers' collaboration across product, design, brand and marketing, plus systems and accessibility work.",
    "published_at": null,
    "observed_at": "2026-09-23",
    "verification": "primary_post_read",
    "supporting_urls": [],
    "notes": "Historical example: source displays 2y. Hiring language does not establish a current opening."
  },
  {
    "id": "lead:shopify-designerfund",
    "platform": "X",
    "url": null,
    "author": "Designer Fund",
    "company": "Shopify",
    "types": [
      "process",
      "culture"
    ],
    "discipline": "product design/design engineering",
    "summary": "Case study describes evolving design workflows and apprenticeship.",
    "published_at": null,
    "observed_at": "2026-09-23",
    "verification": "indexed_only",
    "supporting_urls": [
      "https://w.twstalker.com/designerfund"
    ],
    "notes": "Third-party reference. Exact post permalink and underlying case study need verification."
  },
  {
    "id": "lead:linear-production-designer",
    "platform": "Web",
    "url": "https://jobs.ashbyhq.com/linear/b32de590-06ce-47d4-8994-66b936df908d",
    "author": "Linear",
    "company": "Linear",
    "types": [
      "role_lead"
    ],
    "discipline": "production design",
    "summary": "Search index lists a Production Designer role.",
    "published_at": null,
    "observed_at": "2026-09-23",
    "verification": "indexed_only",
    "supporting_urls": [],
    "notes": "Job page requires JavaScript. No current availability verified; supporting discovery lead, not a social post."
  }
]
```
