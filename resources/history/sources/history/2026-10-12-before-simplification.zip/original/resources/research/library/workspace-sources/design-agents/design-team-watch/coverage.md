# Coverage — source record

Portable Markdown rendering of the recorded structured source. Its dated contents are evidence, not current instructions or capability claims. The original is preserved in the workspace source archive.

```json
{
  "last_discovery_date": "2026-09-23",
  "successful_incremental_checkpoints": {
    "X": null,
    "LinkedIn": null
  },
  "backfill": {
    "target_days": 30,
    "status": "not_started",
    "completed_windows": []
  },
  "discovery_scope": "Initial loaded X deck sample, LinkedIn feed and search sample, targeted public web research. No exhaustive history.",
  "known_issues": [
    "Standalone X search returned errors",
    "Unattended browser access not yet tested",
    "Some leads have indexed text only"
  ],
  "next_work": [
    "Verify Ramp original post",
    "Find additional company-team posts across both platforms",
    "Begin bounded 30-day backfill",
    "Verify Shopify source and social permalink"
  ],
  "notified_ids": [
    "x:2098080850164281394",
    "x:2102860064864502190",
    "x:2102919488299745319",
    "linkedin:7179574986158874624",
    "lead:shopify-designerfund",
    "lead:linear-production-designer"
  ]
}
```
