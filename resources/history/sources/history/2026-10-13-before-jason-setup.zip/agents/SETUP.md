# Setup

Install the complete design-agent kit from its GitHub repository into the repository currently open in the IDE. **This one Markdown file is the entry point.** Give it to the assistant and say: “Install this design kit into the open repo.”

## Source

```text
github_repository: UNSET
source_ref: UNSET
install_folder: design-agents
```

Publishing step: fill in the actual GitHub repository URL and release tag or commit in this file before distributing it. GitHub publication is planned for the end of the kit review. While either source field is unset, explain that the download source is pending; do not invent a URL or claim installation. A user-supplied source/ref can override these fields for that run.

This file must work on its own before the rest of the kit exists. All paths below describe files to fetch or create; they are not prerequisites the user must manually copy.

## Inputs

This Setup file, the configured GitHub source/ref, and the currently open destination repository. Use its known repository root as the installation destination. Ask only if multiple open repositories make the destination ambiguous. A product brief, category, viewport, or style is unnecessary for installation.

## Work

1. **Locate the open repo.** Read its existing instructions and inspect whether `design-agents/` is already installed. Preserve the repository's code, Git history/remotes, README, and existing instruction files. Installing into the explicitly open repo does not require asking for a new project location.
2. **Fetch the published kit.** Retrieve the configured release/tag/commit into a temporary staging folder using available GitHub or Git/archive tools. Resolve and record the exact commit. Use existing account access for a private source. If the source cannot be fetched, report the missing access or source without claiming success. Never clone over the destination repo or copy the source's live `.git` directory into it.
3. **Create and populate the folders.** Install the full published file tree under `<open-repo>/design-agents/`, including hidden `.agents/skills/`, Markdown, source collections, licensed snapshots, and supporting scripts/configuration. Preserve relative paths and source filenames. Copy the kit's own `.gitignore` into its installed folder. Keep archives as archives unless a tool's setup specifically needs extraction; historical snapshots are evidence, not extra active installations. Verify the expected structure below against the fetched source; do not fabricate missing role files or research.
4. **Connect the IDE instructions.** After the files exist, read the installed `AGENTS.md`, `README.md`, and `agents/README.md`. Add or update one **Design kit** section in the destination's existing `AGENTS.md`, preserving its other rules. Use the instruction text below with the actual install path. Add one short section in its README linking the installed kit and recording source URL, ref, resolved commit, install path, and date. Create either file only if absent; repeating Setup updates these sections without duplicating them.
5. **Check the installation.** From the installed kit root, run `python3 scripts/workspace.py check` when Python 3 is available. If the fetched package includes `EXPORT-MANIFEST.json`, run `python3 scripts/workspace.py verify` before changing packaged files. Check that the destination's pointers resolve and the four working role files can be read. If Python is unavailable, check the fetched tree and required paths manually and report that automated verification was unavailable.
6. **Hand over the installed kit.** Report the destination, source revision, folders installed, instruction sections added/updated, verification, and any conflicts or unavailable capabilities. Point to Atlas, Taste, Dial, and Dream. Leave the current product and its implementation layout intact.

Expected installed layout:

```text
<open-repo>/
  AGENTS.md                   Existing rules plus a Design kit section
  README.md                   Existing content plus a kit link/source receipt
  design-agents/
    README.md
    AGENTS.md
    workspace.json
    .gitignore
    agents/                   SETUP, ATLAS, TASTE, DIAL, DREAM, and memory
    resources/                Design, styles, motion, tooling, collections, history
    mcps/                     Provider and connection records
    apps/                     App entry guide
    websites/                 Website entry guide
    games/                    Game entry guide
    tools/                    Published local-tool guidance and packaged material
    .agents/skills/           Bundled skills and catalogue pointers
    scripts/                  Verification and transfer utilities
```

Instruction text for the destination's **Design kit** section:

```md
For design work, read `design-agents/AGENTS.md`,
`design-agents/agents/README.md`, and the requested role's MD.
Follow this repository's existing instructions and recorded project paths.
Keep shared kit resources in `design-agents/`; save product code and
project-specific design records in this repository's chosen locations.
Read relevant bundled SKILL.md files explicitly when this IDE does not
discover skills nested under `design-agents/.agents/skills/`.
```

On a repeat run, retain identical files and restore missing files from the selected source. Compare differing files before changing them; preserve local edits and identify conflicts. A new source revision is an explicit update, not permission to reset local work. Reuse the recorded install path; do not create another kit beside it or copy skills globally by default.

“Install the kit” means install everything shipped in its published repository: instructions, resources, bundled skills, definitions, and supporting files. Source catalogue entries do not each become a software installation. Machine runtimes, authenticated MCP connections, credentials, and external tool dependencies follow their actual setup instructions when needed; report their state accurately. Setup creates the kit folders now; viewport/category/style branches are created later for actual design work.

## Result

The open repo contains the complete published kit in `design-agents/`, its IDE instructions point to the installed roles, and the source revision and checks are recorded. Installation is complete only when those files and pointers are present and verified to the extent reported. A Markdown file instructs a capable IDE assistant to perform these steps; merely reading or saving it does not execute an installer.
