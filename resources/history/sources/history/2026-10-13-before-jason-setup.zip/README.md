# Design agents

A portable design kit: **Setup, Atlas, Taste, Dial, Dream**, and one master resource list. Use the single Setup file to install the kit into an open repository.

## Folder map

```text
agents/
  SETUP.md           Install the kit from GitHub into an open repo
  ATLAS.md           Research and nomenclature
  TASTE.md           References to a custom kit and first layout
  DIAL.md            React components, controls, and layouts
  DREAM.md           Separate versions for morning review
  README.md          Workflow and project-saving rules
  memory/            Taste evidence, decisions, and coverage
resources/
  catalogue.md       Master resource list
  design/            Categories, viewports, research, and workflows
  styles/            App, website, and game aesthetics
  motion/            Motion terminology, Remotion, and Jitter
  tooling/           Tool research and setup records
  agents/            Supporting craft and agent research
  jigs/              Interactive design experiments
  collections/       DesEngs, Fancy Components, Spotted in Prod, and more
  history/           Preserved earlier work and original sources
mcps/                MCP research and connection records
apps/                App entry guide
websites/            Website entry guide
games/               Game entry guide
tools/               Local installations
.agents/skills/      Bundled skills and catalogue pointers
scripts/             Check, index, and export utilities
```

[AGENTS.md](AGENTS.md) contains shared IDE instructions; `workspace.json` defines what travels with the kit. Our folder names are lowercase. Upstream package names and active paths stay intact.

## Start

Take just [agents/SETUP.md](agents/SETUP.md), open the destination repository in your IDE, and ask:

> Read this Setup file and install the design kit into the open repo.

Setup fetches the published GitHub source, creates `design-agents/` with the full folder tree, and connects the destination's README and `AGENTS.md` to the installed roles. **The source URL/ref will be filled in when we publish to GitHub at the end of the kit review.** The one-file entry is specified here; a live GitHub install has not been tested yet.

An existing complete clone or transfer remains usable directly through [the role guide](agents/README.md#use-any-role). Setup's normal job is fetching and installing the folders, not requiring the whole kit to be copied first.

| I want to… | Start here |
| --- | --- |
| Research an idea or choose names/categories | [Atlas](agents/ATLAS.md) |
| Turn references into a custom kit and first layout | [Taste](agents/TASTE.md) |
| Tune components or compose another layout | [Dial](agents/DIAL.md) |
| Refine the day's work for morning review | [Dream](agents/DREAM.md) |
| Find a reference, style, tool, or MCP | [Master resource list](resources/catalogue.md) |
| Save new research in the correct place | [Resource filing rules](resources/README.md#where-to-save) |

The normal [workflow](agents/README.md#the-design-workflow) is **idea → research → references → custom DialKit + React layout → prompt iteration → Dream review**. Roles also work independently. Builds run on localhost; submission or GitHub delivery comes later.

## Project work

Each new build chat owns one app, website, or game. The working role asks where to save a new project or direction unless you supplied the destination. Its README and `AGENTS.md` record the actual paths; follow-up work reuses them. [The shared location rules](agents/README.md#project-locations) own this behavior.

Within that chosen project, design records follow **type → viewport → category → style**. Start with [apps](apps/README.md), [websites](websites/README.md), or [games](games/README.md). Create branches for actual work. React code follows the project's stack layout; reference assets, versions, and Dream candidates use the recorded project destinations.

## Maintenance and transfer

```sh
python3 scripts/workspace.py catalogue
python3 scripts/workspace.py check
python3 scripts/workspace.py export
```

Edit detailed resource records, then regenerate the master list. The export is `.exports/design-agent-portable.zip`; run `python3 scripts/workspace.py verify` from an extracted kit root to check its hashes. [History](resources/history/README.md) preserves earlier work.

Local installations, dependencies, and credentials stay outside the parent GitHub commit. The personal [DialKit source archive](resources/history/sources/dialkit-source.zip) preserves its source and committed history; extract it into an empty `tools/` folder when needed and read its `PERSONAL.md`.

These roles remain portable Markdown for later skill conversion. The full reference-to-kit workbench still needs implementation; Dream's scheduler and execution host are not configured.
