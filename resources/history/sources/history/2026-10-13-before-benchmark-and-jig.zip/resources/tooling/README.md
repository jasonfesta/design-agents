# Tooling

- [React, localhost, and later submission](../design/workflows/apply.md#react-localhost-and-handoff)
- [Local tool setup](local-tools.md) and [recorded source revisions](local-tools.json)
- [Antigravity/X research](antigravity-x-research.md)
- [Remotion](../motion/remotion.md) and [Jitter](../motion/jitter.md)
- [MCP research and setup](../../mcps/README.md)
- [Detailed collected tool/source records](../collections/source-records.md)

Installed checkouts live in the root `tools/` folder. Historical installation observations do not establish current runtime or account access. Use [the master list](../catalogue.md) to find tooling alongside design references.
