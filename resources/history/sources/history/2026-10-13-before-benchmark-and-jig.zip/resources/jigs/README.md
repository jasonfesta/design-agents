# Design jigs

Interactive design jigs are adjustable experiments for exploring a specific design question. Jason confirmed this meaning on October 12, 2026; Jitter belongs with motion tools.

- [Preserved DesignJigs reference](../history/workspace-sources/dxa/resources/designjigs.md)
- [Preserved jig workflow](../history/workspace-sources/dxa/workflows/README.md)
- [Current component workflow](../design/workflows/components.md)
- [Dial agent](../../agents/DIAL.md)
- [Local DialKit source](../history/sources/dialkit-source.zip)

For an actual jig, record the question, reference, adjustable controls, fixed constraints, code/values, and saved result. Keep it with the design branch it supports and link it from the master list. No live jig is created by this reference folder. Jigs remain a resource type, not a fourth top-level design type.
