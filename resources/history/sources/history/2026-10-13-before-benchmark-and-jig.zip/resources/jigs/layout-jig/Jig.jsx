import React, { useState } from 'react';
import './jig.css';

export const widths = [['Mobile S',320],['Mobile M',375],['Mobile L',425],['Tablet',768],['Laptop',1024],['Laptop L',1440],['4K',2560]];

export function downloadFile(name, content, type = 'text/plain') {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement('a'); a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** A review shell only. Supply an isolated layout iframe as children. */
export function Jig({ title, viewport, onViewport, theme, onTheme, onDownload, url, annotation = '', onAnnotation, variant = 'framed', children }) {
  const [annotating, setAnnotating] = useState(false);
  const [note, setNote] = useState(annotation);
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);
  const dimension = (key, value) => {
    const n = Number(value);
    if (Number.isInteger(n) && n >= 240 && n <= 3840) onViewport({ ...viewport, [key]: n });
  };
  async function saveNote() {
    setSaving(true);
    try { await onAnnotation(note); setMessage('Annotation saved.'); }
    catch { setMessage('Could not save. Your annotation is still here.'); }
    finally { setSaving(false); }
  }
  async function copy() {
    try { await navigator.clipboard.writeText(url); setMessage('Local URL copied.'); }
    catch { setMessage(`Copy this local URL: ${url}`); }
  }
  return <section className={`layout-jig jig-${variant}`} aria-label={`${title} review jig`}>
    <div className="jig-toolbar">
      <strong>{title}</strong>
      <div className="jig-actions">
        <label className="jig-sr">Viewport preset<select aria-label={`${title} viewport preset`} value={widths.some(([,w])=>w===viewport.width) ? viewport.width : ''} onChange={e=>dimension('width',e.target.value)}>
          <option value="" disabled>Custom</option>{widths.map(([name,w])=><option key={w} value={w}>{name} · {w}</option>)}
        </select></label>
        <label>W<input key={`w${viewport.width}`} aria-label={`${title} width`} type="number" min="240" max="3840" defaultValue={viewport.width} onBlur={e=>{dimension('width',e.target.value);e.target.value=viewport.width;}} /></label>
        <span aria-hidden="true">×</span>
        <label>H<input key={`h${viewport.height}`} aria-label={`${title} height`} type="number" min="240" max="3840" defaultValue={viewport.height} onBlur={e=>{dimension('height',e.target.value);e.target.value=viewport.height;}} /></label>
        <select aria-label={`${title} color mode`} value={theme} onChange={e=>onTheme(e.target.value)}><option value="light">Light</option><option value="dark">Dark</option></select>
        <button type="button" aria-pressed={annotating} onClick={()=>setAnnotating(!annotating)}>Annotate</button>
        <button type="button" onClick={onDownload} disabled={!onDownload}>Download React</button>
        <button type="button" onClick={copy}>Copy URL</button>
      </div>
    </div>
    {annotating && <div className="jig-annotation">
      <label>Annotation for this layout<textarea maxLength={10000} value={note} onChange={e=>setNote(e.target.value)} placeholder="Describe the element, what to change, and why…" /></label>
      <button type="button" disabled={saving} onClick={saveNote}>{saving ? 'Saving…' : 'Save annotation'}</button>
    </div>}
    <div className="jig-canvas">{children}</div>
    {message && <p className="jig-message" role="status">{message}</p>}
  </section>;
}
