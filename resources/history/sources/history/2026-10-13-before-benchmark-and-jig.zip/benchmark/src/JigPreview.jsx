import React, { useState } from 'react';
import { Jig, downloadFile } from '../../resources/jigs/layout-jig/Jig.jsx';

export default function JigPreview() {
  const variant='framed';
  const [viewport,setViewport]=useState({width:393,height:560});
  const [theme,setTheme]=useState('light');
  const [note]=useState(()=>{try{return localStorage.getItem('jason-jig-preview-note') || '';}catch{return '';}});
  const placeholder=`<!doctype html><html style="color-scheme:${theme}"><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;min-height:100vh;background:${theme==='dark'?'#171717':'#fff'}"></body></html>`;
  const sample="import React from 'react';\n\n// Placeholder canvas for reviewing the jig, not a generated Dial layout.\nexport default function Layout() { return <main style={{ minHeight: '100vh', background: '#fff' }} />; }\n";
  return <div className={`jig-preview-page mode-${variant}`}>
    <header className="jig-preview-header"><span>jason <span className="muted">/ jig</span></span><span className="preview-caption">Layout review</span></header>
    <main className="jig-preview-main">
      <Jig title="Layout" variant={variant} viewport={viewport} onViewport={setViewport} theme={theme} onTheme={setTheme} url={location.href} annotation={note} onAnnotation={text=>localStorage.setItem('jason-jig-preview-note',text)} onDownload={()=>downloadFile('layout.jsx',sample,'text/javascript')}>
        <iframe title="Layout viewport" sandbox="" srcDoc={placeholder} style={{width:viewport.width,height:viewport.height,border:0,boxShadow:'0 0 0 1px #e8e9eb',background:theme==='dark'?'#171717':'#fff',colorScheme:theme}}/>
      </Jig>
    </main>
    <p className="jig-preview-footer">{viewport.width} × {viewport.height} <span>·</span> Placeholder layout <span>·</span> {variant==='floating'?'Floating controls':'Framed controls'}</p>
  </div>;
}
