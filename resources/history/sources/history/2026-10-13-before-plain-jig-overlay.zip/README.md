# Jason

Jason's portable workspace: **Setup, Atlas, Taste, Dial, Dream, Benchmark**, and one master resource list. One Setup MD creates the `jason/` folder system on a new machine, inside an open repository or at a chosen location.

## Folder map

These folders live directly inside the installed `jason/` root.

```text
agents/
  SETUP.md           Fetch design-agents and create the jason workspace
  ATLAS.md           Ongoing nomenclature library
  TASTE.md           References and defined direction for Dial
  DIAL.md            React components, controls, and layouts
  DREAM.md           Separate versions for morning review
  BENCHMARK.md       Compare models against a selected Dial layout
  README.md          Workflow and project-saving rules
  memory/            Taste evidence, decisions, and coverage
resources/
  catalogue.md       Master resource list
  design/            Categories, viewports, research, and workflows
  styles/            App, website, and game aesthetics
  motion/            Motion terminology, Remotion, and Jitter
  tooling/           Tool research and setup records
  agents/            Supporting craft and agent research
  jigs/              Interactive design experiments
  collections/       DesEngs, Fancy Components, Spotted in Prod, and more
  history/           Preserved earlier work and original sources
mcps/                MCP research and connection records
apps/                App entry guide
websites/            Website entry guide
games/               Game entry guide
benchmark/           Local comparison workbench and jig preview
tools/               Local installations
.agents/skills/      Bundled skills and catalogue pointers
scripts/             Check, index, and export utilities
```

[AGENTS.md](AGENTS.md) contains shared IDE instructions; `workspace.json` defines what travels with the kit. Our folder names are lowercase. Upstream package names and active paths stay intact.

## Start

Take just [agents/SETUP.md](agents/SETUP.md), open the destination repository or choose a folder in your IDE, and ask:

> Read this Setup file and set up Jason here.

Setup fetches the GitHub repository **`jasonfesta/design-agents`**, creates **`jason/`**, populates the full tree, and connects the instructions. It detects the machine's tools, uses local paths, and records what is installed, working, or still needs a dependency/sign-in. Existing project files and local changes are preserved.

The source is **`https://github.com/jasonfesta/design-agents`** and the installed folder is **`jason/`**. `main` is provisional until publication at the end of this review. Live GitHub setup and separate macOS/Windows/Linux runs remain untested. An existing complete clone or transfer can be used directly through [the role guide](agents/README.md#use-any-role).

| I want to… | Start here |
| --- | --- |
| Look up or extend the design vocabulary | [Atlas](agents/ATLAS.md) |
| Interpret references and define a direction for Dial | [Taste](agents/TASTE.md) |
| Build or tune the custom kit and React layouts | [Dial](agents/DIAL.md) |
| Refine the day's work for morning review | [Dream](agents/DREAM.md) |
| Compare models against a Dial layout I like | [Benchmark](agents/BENCHMARK.md) |
| Preview the shared corner jig | [Local jig instructions](resources/jigs/layout-jig/README.md) |
| Find a reference, style, tool, or MCP | [Master resource list](resources/catalogue.md) |
| Save new research in the correct place | [Resource filing rules](resources/README.md#where-to-save) |

The normal [workflow](agents/README.md#the-design-workflow) is **references → Taste with Atlas suggestions and dialogue → selected type / viewport / category / style → custom DialKit + React layout → prompt iteration → Dream review**. Roles also work independently. Builds run on localhost; submission or GitHub delivery comes later.

The [current work and next steps](agents/README.md#current-work-and-next-steps) regroup the related chats, reference collections, role boundaries, and remaining implementation.

## Project work

Each new build chat owns one app, website, or game. The working role asks where to save a new project or direction unless you supplied the destination. Its README and `AGENTS.md` record the actual paths; follow-up work reuses them. [The shared location rules](agents/README.md#project-locations) own this behavior.

Within that chosen project, design records follow **type → viewport → category → style**. Start with [apps](apps/README.md), [websites](websites/README.md), or [games](games/README.md). Create branches for actual work. React code follows the project's stack layout; reference assets, versions, and Dream candidates use the recorded project destinations.

## Maintenance and transfer

```sh
python3 scripts/workspace.py catalogue
python3 scripts/workspace.py check
python3 scripts/workspace.py export
```

Edit detailed resource records, then regenerate the master list. The export is `.exports/jason.zip`, containing a `jason/` root; run `python3 scripts/workspace.py verify` from an extracted kit root to check its hashes. [History](resources/history/README.md) preserves earlier work.

Local installations, dependencies, and credentials stay outside the parent GitHub commit. The personal [DialKit source archive](resources/history/sources/dialkit-source.zip) preserves its source and committed history; extract it into an empty `tools/` folder when needed and read its `PERSONAL.md`.

These roles remain portable Markdown for later skill conversion. The full reference-to-kit workbench still needs implementation; Dream's scheduler and execution host are not configured.
