# games

Within the project folder chosen using [the shared location rules](../agents/README.md#project-locations), save design records as `games/<viewport>/<category>/<style>/`. Product code uses the project's recorded implementation locations. Each created design layer has one README; create folders when needed.

- **Viewports:** mobile, tablet, desktop, tv. Use [viewport profiles](../resources/design/viewports/README.md) and record the actual dimensions, units, input, and support.
- **Categories:** [17 game genres](../resources/design/categories/GAME-GENRES.md).
- **Styles:** [games styles](../resources/styles/games.md), with [motion](../resources/motion/techniques.md) described inside the style record.
- **References:** [Resources](../resources/README.md).
- **Preferences:** [Taste memory and coverage](../agents/memory/MEMORY.md); no branch-specific personal style is defined yet.

A branch README records the task, references, supported feedback, current state, and next action. Components, variants, and supporting assets live with the actual style work. Use [the style template](../resources/styles/template.md) when useful.

Earlier viewport/category placeholders are preserved in [History](../resources/history/README.md). Their existence did not establish research or compatibility. [Atlas](../agents/ATLAS.md) researches concepts and owns nomenclature. [Taste](../agents/TASTE.md) turns references into a custom kit and first React layout through [Dial](../agents/DIAL.md), which implements and tunes the shared components. [Dream](../agents/DREAM.md) refines a separate version for morning review.
