# Using Jason

[Setup](SETUP.md) is the single-file entry that fetches the GitHub repository `jasonfesta/design-agents` and creates the `jason/` workspace on a new machine. **Atlas, Taste, Dial, and Dream** are independent work roles. Start with whichever one fits the task; none requires another role to run first.

```text
agents/
  SETUP.md      Fetch design-agents and set up jason on this machine
  ATLAS.md      Discovery and nomenclature across the three types
  TASTE.md      References to a custom kit and first React layout
  DIAL.md       React components, controls, variants, and layouts
  DREAM.md      Nightly cleanup; separate version for morning review
  memory/       Shared taste evidence and coverage
```

## Prepare the kit

Give your IDE assistant just [SETUP.md](SETUP.md), with an open repository or a chosen destination, and say:

> Read this Setup file and set up Jason here.

Setup carries its own source configuration and pre-download instructions. It creates `jason/` with the complete tree, hidden bundled skills, and supporting files. It connects the IDE instructions, checks the local environment, and records dependency/authentication readiness in `jason/INSTALLATION.md`. Existing repositories retain their instructions; a standalone installation can be opened directly as a workspace.

The GitHub source is **jasonfesta/design-agents**; the installed folder is **jason/**. The account and repository name are confirmed. Confirm the provisional `main` branch or release revision when publishing. Cross-machine operation is the requirement; live source retrieval and target-OS installation tests are still pending.

Setup owns this folder system and machine setup. The working roles own project-specific code and design destinations using the rules below. Existing complete copies can load roles directly. Reuse the selected installation; avoid nested or duplicate Jason folders.

## Use any role

Replace the paths, role, and request below. Explicit file loading works even when the IDE does not discover instructions automatically.

```text
Read <kit-path>/AGENTS.md, <kit-path>/agents/README.md,
and <kit-path>/agents/<ATLAS|TASTE|DIAL|DREAM>.md.
Use that role for: <request>.
Project, if applicable: <existing project path or new project description>.
Read the role's required references and the destination's instructions.
Follow the shared project-location rules before creating project files.
```

Load only the chosen role and the references its task needs. If moving a role outside the kit, include its linked context and assets with attribution; an isolated Markdown file cannot supply missing evidence. Each role has the same **Inputs → Work → Result** structure for later conversion into a skill. For now, these are portable instructions; native skill registration and background execution are not part of this package.

| Role | Use it for | Result |
| --- | --- | --- |
| [Atlas](ATLAS.md) | Research what to build and maintain nomenclature | Source-linked concepts, names, mappings, and gaps |
| [Taste](TASTE.md) | Absorb videos, websites, links, screenshots, and inspiration | A custom DialKit plus a first React layout, grounded in a scoped taste definition |
| [Dial](DIAL.md) | Implement the kit, tune components, and compose layouts by prompt | Shared React code, controls, saved values, and local previews |
| [Dream](DREAM.md) | Refine the day's work within Taste and Dial standards | A separate morning-review version, evidence, and an unfinished queue |

## The design workflow

**Idea → Atlas research → Taste references → custom DialKit + first React layout through Dial → prompt edits and more layouts → Dream morning-review version.**

Atlas researches interesting, well-executed things to build and classifies the direction. Taste absorbs references gathered in the IDE or brought in from elsewhere: MP4s, websites, links, screenshots, screen grabs, and mood material. It records the useful qualities, resolves their contribution to the brief, and carries Dial's implementation workflow through to both outputs in the same task. Jason does not need to request the kit and layout separately.

The layout imports the kit's real React components and values. Prompt changes can target the kit, a component, or one layout; keep their scope explicit. Additional layouts reuse the visual system while varying structure and content. Work runs on localhost; prepare source and run instructions for a later submission tool or GitHub handoff. [Local delivery guidance](../resources/design/workflows/apply.md#react-localhost-and-handoff) covers implementation.

Label each reference **layout**, **mood/inspiration**, or **both**. Separately choose **Reconstruct**, **Adapt**, or **Explore** from the requested intent. Adapt is our research-informed proposal for a new product using existing references; an explicit request to match a layout uses Reconstruct. [The research note](../resources/design/reference-to-layout-research.md) explains these choices and their limits. These are fields in the direction record, not extra folder layers.

This is the normal build flow, not a requirement to repeat completed stages. Supplied references can start with Taste or Dial. Terminology work can stay in Atlas. Dream reads saved decisions directly and makes changes in a separate candidate before morning review; promotion to the working project is a later explicit choice. No schedule is active.

## Project locations

These rules apply to all four roles, independently of Setup.

1. **One new build chat owns one app, website, or game.** Continue its project on follow-up messages. Explicit shared research, kit maintenance, or a request to resume an existing project keeps its stated scope.
2. **Ask where to save a new project or direction unless the destination is already supplied.** Confirm its absolute path and inspect existing instructions before writing. A suggested path or silence is not an answer; read-only work can continue while waiting. Never silently use this kit or another chat's project as the output folder.
3. Create only the selected design layers, with one README per created layer. Use the [type and category menus](../resources/design/categories/README.md), [viewport profiles](../resources/design/viewports/README.md), and [styles](../resources/styles/README.md). Leave unknown choices in the project record instead of creating placeholder branches. Exact dimensions, motion, tools, and screen details are fields inside the record.
4. Add a **Design project** section to the project's README: name/type, owning chat when known, implementation and asset locations, direction path, references/variants, current state, and unresolved choices. Store paths relative to the confirmed project root so it can move. Follow the stack's normal code layout.
5. Add a **Design file routing** section to the project's `AGENTS.md`, preserving existing rules. Point to the README's actual paths; instruct the IDE to save product code in implementation locations and design notes/assets/variants in the direction. Explicitly load both files in IDEs without instruction discovery. Use an explicit command working directory and resolved file destinations.

```text
<chosen-project>/
  README.md                         Project and actual file destinations
  AGENTS.md                         Instructions to use those destinations
  <implementation folders>/        Code and assets for the chosen stack
  <apps|websites|games>/<viewport>/<category>/<style>/
    README.md                       Direction, references, decisions, state
    references/                     Selected assets, when needed
    components/                     Components and variants, when needed
```

Angle brackets are placeholders. Use lowercase folders for our records, retaining required stack conventions. Keep independent named variants when two directions share a style. Reuse saved destinations for follow-up edits; switching roles does not create a new project. Ask again for a new project, direction, or relocation. Each project owns its paths; there is no shared active-project pointer. Instructions guide the assistant and do not change IDE permissions automatically.

## Save once and hand off clearly

Keep project decisions in the direction's README, selected research with the project, reusable source descriptions in Resources, and supported reusable preferences in Taste memory. Link component records and versions from the direction instead of creating a new report for every role switch. For generated work, record the date/time zone, item ID and paths, source roles and inspected pages/regions/time ranges, Taste criteria, transformation, kit/component/layout revisions, exact values, and checks. Dream uses these entries to review the whole day within the project scope.

Return the actual project/direction paths, source or version IDs, saved work, decisions versus proposals, checks performed, unresolved gaps, and next action. No handoff is required to finish a self-contained task. If file writes or visual checks are unavailable, state what remains unsaved or unverified.

The [master resource list](../resources/catalogue.md) owns navigation. [MCPs](../mcps/README.md), [local tools](../tools/README.md), and [agent resources](../resources/agents/README.md) supply supporting records. [History](../resources/history/README.md) preserves prior versions. The full image-to-component workbench still needs implementation; Dream's [nightly operating design](../resources/design/workflows/dream.md) specifies the three-hour window; scheduling and its execution host are not configured.
