# Taste

Absorb the reference collection and deliver **a custom DialKit plus a first React layout built from it**. Establish the visual direction, preserve its source evidence, and make that direction usable for many later layouts.

## Inputs

Screenshots, screen grabs, MP4s or other videos, live websites, links, sketches, and inspiration/mood collected in the IDE or brought in from elsewhere. One layout can be enough to start. Use the intended product/content, selected reference contributions, and Jason's feedback when available. Atlas can supply research, but supplied references do not require repeating discovery.

Read [the shared instructions](../AGENTS.md), [memory](memory/MEMORY.md), relevant [coverage](memory/COVERAGE.md), [taste guidance](../resources/design/workflows/taste.md), and [project locations](README.md#project-locations). The [reference-to-layout research](../resources/design/reference-to-layout-research.md) explains the proposed starting modes.

## Work

1. **Ingest and track coverage.** Inventory all supplied material, preserving source identity, original assets or accessible pointers, dates, and feedback. Inspect in manageable batches and keep a cursor for large collections. Record actual pages, image regions, and video time ranges/keyframes inspected. Mark inaccessible or pending sources; a fetched URL or one sampled frame is not full inspection.
2. **Separate structure from mood.** Label each source contribution as **layout**, **mood/inspiration**, or **both**. Extract layout anatomy independently from typography, palette, materials, imagery, lighting, rhythm, and motion. Record observable facts, Jason's words, and interpretations separately. Still images do not establish unseen states, motion, or 3D geometry.
3. **Define the taste and transformation.** Record qualities to preserve, change, avoid, or leave open, with source links and scope. Use **Reconstruct** for a requested match; **Adapt** is the research-informed proposal for a new item using an existing reference; **Explore** develops a concept from the brief and inspiration. Infer the mode from explicit intent, and clarify only a material ambiguity. Collecting many references does not make every feature a preference; separate incompatible directions instead of averaging them together.
4. **Develop the composition.** For reconstruction, preserve the requested layout. When exploration is requested, compare a few rough, structurally different compositions before detailed polish. The proposed starting set is a close adaptation, a restructured option, and a more exploratory concept. Keep content/viewport comparable and preserve each option. Use known decisions; do not turn every step into another approval request.
5. **Deliver both outputs through Dial.** Read [Dial](DIAL.md) and carry its implementation workflow through in the same authorized task. Produce the custom React components, tokens, asset/motion rules, controls, saved variants, and a first editable layout that imports the same kit. A prose taste brief alone is not the requested finished output. Follow relevant craft skills and verify the local result when tools allow.
6. **Support iteration and memory.** Kit changes, component changes, and layout changes have explicit scope. Subsequent layouts reuse the kit's visual system while changing composition. Save exact versions, source contributions, and dated generated items for Dream. Keep local choices with the project; promote only supported reusable preferences to memory.

Disclose missing personal research before taste-based recommendations, then continue authorized analysis and labeled candidate design. Jason's explicit selections apply within their scope without being reapproved. Agent interpretations and generated examples do not establish confirmed personal taste.

## Result

Deliver **one custom, reusable DialKit and one working React layout**, linked by the same components and values, with the actual localhost preview when run. Include source coverage, taste criteria and status, selected transformation, kit/layout revisions, exact controls, actual code/assets, and checks. Preserve alternative compositions and reference reconstructions where created. State missing or unexecuted stages honestly. Use [the shared result format](README.md#save-once-and-hand-off-clearly).
